//"use strict";
(window.webpackJsonp = window.webpackJsonp || []).push([
  [0],
  {
    "+Nh4": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "+jE+": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "+ugO": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "/PjG": function (eta, lmbda, n) {},
    "/Wnl": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-regular.479970ffb74f2117317f9d24d9e317fe.woff2";
    },
    "08Mx": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/checkbox-off.efb5db132df40cbcbbe5ffa907685efe.png";
    },
    "0TsU": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-700.adcde98f1d584de52060ad7b16373da3.woff";
    },
    "1WW8": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen-blue.4c87b444c898b1340ea5b040db59488d.cur";
    },
    "1mBI": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-share.ff1b09390530b1fe58879833adfda9f0.png";
    },
    "1v75": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "2xYs": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-icon-stop-off.147653b1c214867c5b97c8bec6c86806.png";
    },
    3127: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "3vhr": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-blue.bd0624db42e16b713a6e7d1683d007b7.png";
    },
    "45L6": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-info.bc0d973100dac97ff4a73f9e937aed48.png";
    },
    "9jHf": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    C2c7: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-faceselect-bg-on.889bf5465943a7e1ac2e3fc2a2bacbaa.png";
    },
    CJ9Q: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-tab-run-on.7ec5263e8957c2b1f9bf555b88893ee1.png";
    },
    CgZc: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-on.c2a499f3d83371ab1979d72a67bce99d.png";
    },
    CmYf: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-700.2735a3a69b509faf3577afd25bdf552e.woff2";
    },
    DudV: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    FN4q: function (module, exports, require) {
      var initializer = require("JPst");
      var $ = require("HeW1");
      var _image = require("xBFG");
      var svg = require("MqCn");
      var word = require("i7eL");
      var identity = require("eofj");
      var value = require("66C5");
      var code = require("WAVf");
      var ts = require("Hni1");
      var h = require("KUtk");
      var d = require("Rah+");
      var button2 = require("/Wnl");
      var count = require("Iv4c");
      var v = require("qPnO");
      var _ = require("mLyz");
      var g = require("lILe");
      var rule = require("Xp3h");
      var m = require("CmYf");
      var b = require("0TsU");
      var qrcode = require("J8P3");
      var coords = require("08Mx");
      var button = require("o0vD");
      var verify = require("M9x/");
      var button1 = require("C2c7");
      var y = require("Q6Sk");
      var btnHtml = require("N69d");
      var input = require("O6Lu");
      var html = require("IZU+");
      var timeline = require("YLpD");
      var srvc = require("iMqz");
      var x = require("dCLE");
      var options = require("jhPy");
      var str = require("vDVt");
      var display = require("VikQ");
      var M = require("3vhr");
      var xml = require("xfvv");
      var url = require("m79l");
      var site = require("mVJv");
      var e = require("ulOs");
      var itemTemplate = require("1WW8");
      var transform = require("OX93");
      var Y = require("dCq+");
      var ID = require("aLGr");
      var obj = require("V6Ve");
      var search = require("Y9ik");
      var data = require("/PjG");
      var p = require("JY+c");
      var errors = require("YiJN");
      var Q = require("iY4r");
      var target = require("Va4Y");
      var pc = require("mpcN");
      var table = require("emzk");
      var sel = require("sMyz");
      var document = require("wBlU");
      var INPUT_TEMPLATE = require("gmkO");
      var i = require("aJT6");
      var complete = require("H1HQ");
      var iframe = require("CgZc");
      var searchList = require("wSdw");
      var type = require("cJUU");
      var h2 = require("dXac");
      var location = require("fGIB");
      var magnifier = require("xp4H");
      var token = require("Iu71");
      var People = require("yqsS");
      var param_text = require("sb+R");
      var youtube = require("1mBI");
      var message = require("45L6");
      exports = initializer(false);
      var img = $(_image);
      var cnvs = $(svg);
      var rs = $(word);
      var or = $(identity);
      var oldCondition = $(value);
      var codeEls = $(code);
      var threshold = $(ts);
      var noResults = $(h);
      var subs = $(d);
      var button2Component = $(button2);
      var countDiv = $(count);
      var ftype = $(v);
      var pseudoNames = $(_);
      var pencil = $(g);
      var current = $(rule);
      var markStart = $(m);
      var originalB = $(b);
      var el = $(qrcode);
      var tree = $(coords);
      var $buttonEl = $(button);
      var self = $(verify);
      var node = $(button1);
      var $origin = $(y);
      var btn = $(btnHtml);
      var $inputElem = $(input);
      var BROADCASTER = $(html);
      var timelineDiv = $(timeline);
      var item = $(srvc);
      var memoryx = $(x);
      var cloned_options = $(options);
      var nb = $(str);
      var actionsTemplate = $(display);
      var t = $(M);
      var jxml = $(xml);
      var time = $(url);
      var newItem = $(site);
      var this_area = $(e);
      var et = $(itemTemplate);
      var stationTable = $(transform);
      var ae = $(Y);
      var slideoutMenu = $(ID);
      var myRootLocation = $(obj);
      var searchIco = $(search);
      var compact = $(data);
      var $pElement = $(p);
      var retval = $(errors);
      var key = $(Q);
      var ngEl = $(target);
      var targets = $(pc);
      var tableBs = $(table);
      var willdisposes = $(sel);
      var $DOCUMENT = $(document);
      var element = $(INPUT_TEMPLATE);
      var slideDom = $(i);
      var menuItem = $(complete);
      var iframeList = $(iframe);
      var filterInput = $(searchList);
      var previewOnFunction = $(type);
      var categoryH2 = $(h2);
      var addLocation = $(location);
      var $magnifier = $(magnifier);
      var blockContent = $(token);
      var matches = $(People);
      //var $pText = $(param_text);
      var $vid = $(youtube);
      var messageField = $(message);
      exports.push([
        module.i,
        "button {\n  background: none;\n  outline: none;\n  padding: 0;\n  margin: 0;\n  border: 0;\n  color: inherit;\n  font: inherit;\n  line-height: normal;\n  overflow: visible;\n  cursor: pointer;\n}\n.hidden {\n  display: none;\n}\n.light-on-dark {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n.soft-shadow {\n  box-shadow: 0 0 300px rgba(0, 0, 0, 0.25);\n}\n.alpha-tag,\n.beta-tag {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  position: absolute;\n  top: 0.3em;\n  right: 0.3em;\n  padding: 0.2em 0.4em;\n  border-radius: 3px;\n  background-color: #551A8B;\n  color: #fff;\n  opacity: 0.75;\n  font-size: 1.35em;\n  font-weight: 600;\n  text-align: right;\n}\n.alpha-tag {\n  background-color: #551a8b;\n}\n.beta-tag {\n  background-color: #0273af;\n}\n/* -----\nToolbar\n----- */\n#toolbar.top .popup::after {\n  top: -24px;\n  background: url(" +
          img +
          ") no-repeat;\n  content: '';\n}\n#toolbar.top .popup .popup-body {\n  border-radius: 10px;\n}\n#toolbar.top .popup.tail-right .popup-body {\n  border-top-right-radius: 0;\n}\n#toolbar.top .popup.tail-right::after {\n  background-position: 24px 0;\n  right: 48px;\n}\n#toolbar.top .popup.tail-left .popup-body {\n  border-top-left-radius: 0;\n}\n#toolbar.top .popup.tail-left::after {\n  background-position: -24px 0;\n  left: 48px;\n}\n#toolbar .toolbar-spacer {\n  display: flex;\n  flex-grow: 1;\n}\n#toolbar .divider {\n  height: 48px;\n  -ms-flex: 0 0 16px;\n  flex: 0 0 16px;\n  background-image: url(" +
          cnvs +
          ");\n  background-repeat: no-repeat;\n  background-position: center;\n}\n#toolbar .button-group {\n  position: relative;\n  height: 48px;flex-direction: row;\n  justify-content: space-around;\n}\n#toolbar .popup {\n  bottom: 64px;\n}\n#toolbar .toolbar-button {\n  height: 51px;\n  width: 51px;\n  background-repeat: no-repeat;\n  background-position: center;\n}\n#toolbar .toolbar-button.narrow {\n  width: 40px;\n}\n#toolbar .toolbar-button.wide {\n  width: 96px;\n}\n#toolbar .toolbar-button.disabled,\n#toolbar .toolbar-button:active {\n  opacity: 0.5;\n}\n.text-button {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  background-color: #629d34;\n  color: white;\n  padding: 0.8em 0;\n  font-size: 0.825em;\n  border-radius: 3px;\n  font-weight: 600;\n  letter-spacing: 0.025em;\n  word-spacing: 0.1em;\n  white-space: nowrap;\n}\n.text-button:hover {\n  opacity: 0.8;\n}\n.text-button:active {\n  background-color: #4a7727;\n}\n.text-button:disabled {\n  background-color: #b2b2b2;\n  cursor: default;\n}\n.text-button:disabled:hover {\n  background-color: #b2b2b2;\n  opacity: 1;\n}\n.button-field {\n  display: flex;\n  flex-direction: row;\n}\n.button-field input {\n  border: 1px solid #CCC;\n  border-right: none;\n  border-radius: 3px 0 0 3px;\n  box-shadow: inset 2px 2px 5px #CCC;\n  padding: 5px;\n  font-size: 0.9em;\n  margin: 0;\n  flex-grow: 1;\n}\n.button-field button {\n  border-top-left-radius: 0;\n  border-bottom-left-radius: 0;\n}\n/* -----\nwinBox\n----- */\n/* jquery winBoxs */\n#winBox-base {\n  display: none;\n}\n/* background overlay */\n.ui-front {\n  z-index: 101;\n  /* same as toolbar or higher */\n}\n.ui-widget-overlay {\n  background: none repeat scroll 0 0 gray;\n  opacity: 0.6;\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n/* our app's generic winBox */\n.ui-winBox.msgBox {\n  padding: 0;\n  background-image: none;\n  background-color: #FFFFFF;\n  border-radius: 8px;\n  overflow: hidden;\n  outline: none;\n}\n.ui-winBox.msgBox .ui-winBox-titlebar {\n  padding-top: 20px;\n  font-family: Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  font-weight: bold;\n  color: #000000;\n  background: none;\n  border: none;\n  text-align: center;\n  font-size: 16px;\n}\n.ui-winBox.msgBox .ui-winBox-titlebar .ui-winBox-title.no-title {\n  /* Fix to JQuery UI 1.12 update where empty titles\n      are replaced with an nbsp;.\n Manually hiding to prevent extra padding.\n   */\n  display: none;\n}\n.ui-winBox.msgBox .ui-winBox-titlebar-close {\n  display: none;\n}\n.ui-winBox.msgBox .ui-winBox-content {\n  font-family: Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  font-size: 16px;\n  text-align: center;\n  padding: 5px 20px 20px;\n  line-height: 1.2em;\n}\n.ui-winBox.msgBox .ui-winBox-buttonpane {\n  margin: 0;\n  padding: 0;\n}\n.ui-winBox.msgBox .ui-winBox-buttonset {\n  margin: 0;\n  padding: 0;\n  width: 100%;\n  height: 100%;\n  border-top: solid 1px #BBB;\n}\n.ui-winBox.msgBox .ui-button {\n  margin: 0;\n  padding: 0;\n  width: 100%;\n  height: 35px;\n  background: none;\n  border: none;\n  color: #1C81C4;\n  /*font-size: 14px;*/\n  /*text-transform: uppercase;*/\n}\n.ui-winBox.msgBox.confirm .ui-button {\n  width: 50%;\n}\n.ui-winBox.msgBox.confirm .ui-button:first-child {\n  border-right: solid 1px #BBB;\n}\n.ui-winBox.msgBox .ui-button:hover {\n  background-color: #F7F7F7;\n}\n.ui-winBox.msgBox .ui-button:active {\n  background-color: #DDD;\n}\n.ui-winBox.msgBox.has-close button.ui-winBox-titlebar-close {\n  display: block;\n  position: absolute;\n  color: transparent;\n  top: 0;\n  right: 0;\n  border-radius: 18px;\n  margin: 5px;\n  width: 36px;\n  background: black url(" +
          rs +
          ") no-repeat center;\n}\n.ui-winBox.msgBox.has-close button.ui-winBox-titlebar-close:hover {\n  background-color: darkgrey;\n}\n#templates {\n  display: none;\n}\n/* -----\n  base styles\n----- */\n.base-background {\n  height: 100vh;\n  width: 100vw;\n  position: fixed;\n  top: 0;\n  left: 0;\n  z-index: -1;\n}\n@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {\n  .base-background {\n    height: 200vh;\n    width: 200vw;\n    transform: translateX(-50%), translateY(-50%);\n  }\n}\n.base {\n  z-index: 100;\n}\n.base.gray-background .base-background {\n  background-color: rgba(108, 118, 128, 0.7);\n}\n.base.popup {\n  position: absolute;\n}\n@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {\n  .base.popup {\n    transform: translateX(-50%);\n    left: 50%;\n  }\n}\n.base.popup.tail-right .popup-body {\n  transform: translateX(-50%);\n  border-bottom-right-radius: 0;\n}\n.base.popup.tail-right::after {\n  background-position: 0 0;\n  top: 0;\n  bottom: 0;\n  right: -36px;\n  left: auto;\n  margin-top: auto;\n  margin-bottom: auto;\n  transform: rotate(-90deg);\n}\n.base.popup.tail-left .popup-body {\n  transform: translateX(50%);\n  border-bottom-left-radius: 0;\n}\n.base.winBox {\n  display: flex;\n  flex-flow: row nowrap;\n  align-items: center;\n  justify-content: center;\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100vw;\n  height: 100vh;\n}\n.base.winBox.hidden {\n  display: none;\n}\n.base.winBox .base-box {\n  top: -24px;\n}\n.base-box {\n  position: relative;\n  overflow: hidden;\n  border-radius: 10px;\n}\n.base-box .content {\ncolor:#fff;\n}\n.base-box .header {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 0 0 15px;\n  background: #0081c6;\n  color: white;\n  height: 46px;\n  font-weight: 600;\n  font-size: 1.1em;\n}\n.base-box .header .close-button {\n  height: 46px;\n  width: 46px;\n  background: url(" +
          or +
          ") no-repeat center;\n  background-size: 40%;\n}\n.base-box .header .close-button.close-dark {\n  background-image: url(" +
          oldCondition +
          ");\n}\n.base-box .header .close-button:active {\n  opacity: 0.5;\n}\n.base.msgBox .base-box {\n  display: flex;\n  flex-flow: column nowrap;\n  width: 400px;\n  text-align: center;\n  position: relative;\n  top: -24px;\nbackground-color:#233239;\n}\n.base.msgBox .title {\n  margin: 20px 20px 0;\n  font-weight: 600;\n}\n.base.msgBox .message {\n  margin: 0.5em 20px 20px;\n}\n@keyframes pulse-msgBox-default {\n  0% {\n    background-color: #568995;\n  }\n  50% {\n    background-color: #5c757b;\n  }\n  100% {\n    background-color: #568995;\n  }\n}\n.base.popup {\n  user-select: text;\n  -moz-user-select: text;\n  -webkit-user-select: text;\n  -ms-user-select: text;\n  -webkit-user-drag: auto;\n}\n.base.popup .content {\n padding: 15px;\n  display: flex;\n  flex-direction: column;\n}\n.base.popup .description {\n  display: flex;\n  flex-flow: row nowrap;\n  align-items: center;\n  margin-bottom: 0.75em;\n}\n.base.popup .description .description-icon {\n  height: 24px;\n  width: 24px;\n  margin-right: 0.5em;\n}\n.base.popup .description .description-icon.short {\n  height: 20px;\n}\n.base.popup .text-button {\n  margin: 0 5px;\n  padding-left: 0;\n  padding-right: 0;\n  flex-basis: 0;\n  flex-grow: 1;\n}\n.base.popup input {\n  height: 100%;\n  padding: 0 0.5em;\n  border: 1px solid #CCC;\n  border-radius: 3px;\n  box-shadow: inset 2px 2px 5px #CCC;\n  margin: 0;\n}\n.base.popup .base-box {\n  position: relative;\n}\n.base.popup .popup-divider {\n  margin: 1em -15px;\n  flex-grow: 0;\n  flex-basis: 2px;\n  background: #CCC;\n}\n#save-popup {\n  width: 380px;\n}\n#save-popup .base-box {\n  right: 130px;\n}\n#save-popup #share-image-ui-container,\n#save-popup #share-activity-ui-container {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n}\n#save-popup .share-image-button-container {\n  display: flex;\n  flex-flow: row nowrap;\n  width: calc(100% + 10px);\n  margin: 0 -5px;\n}\n#save-popup #share-link-ui-container input {\n  width: 240px;\n}\n#save-popup #link-copy {\n  margin: 0;\n  padding-left: 1.5em;\n  padding-right: 1.5em;\n}\n#copy-container {\n  position: relative;\n  overflow: hidden;\n  padding: 0;\n}\n#copy-container #image-copy {\n  width: 100%;\n  height: 100%;\n}\nhtml.disable-copy-image #copy-container {\n  background-color: #b2b2b2;\n}\n#share-activity-ui-container {\n  display: flex;\n  flex-flow: row nowrap;\n  width: calc(100% + 10px);\n  margin: 0 -5px;\n}\n#share-activity-ui-container .input-container,\n#share-activity-ui-container .text-button {\n  margin: 0 5px;\n  flex: 1 0 0;\n}\n#share-activity-ui-container input {\n  font-family: Monaco, monospace;\n  font-size: 1em;\n  width: 100%;\n}\n.submit-container {\n  display: flex;\n  justify-content: space-between;\n}\n.submit-container .field-container {\n  width: 100%;\n}\n.submit-container .input-container {\n  margin: 0 5px;\n  padding-left: 0;\n  padding-right: 0;\n  position: relative;\n  overflow: hidden;\n}\n.submit-container .input-container input {\n  border: 1px solid #CCC;\n  border-radius: 3px;\n  box-shadow: inset 2px 2px 5px #CCC;\n  padding: 5px;\n  font-size: 4em;\n  font-weight: 400;\n  margin: 0;\n  flex-grow: 1;\n  letter-spacing: -0.01em;\n}\n.submit-container .text-button {\n  padding: 0.75em 1.2em;\n  font-size: 1.4em;\n}\n/* Default styling: show desktop instructions. */\n#copy-image-base .copy-image-instructions .mobile {\n  display: none;\n}\n/*\n * If touch is detected, hide desktop instructions and show mobileinstructions.\n */\n.touch #copy-image-base .desktop {\n  display: none;\n}\n.touch #copy-image-base .mobile {\n  display: block;\n}\n#copy-image-base {\n  z-index: 110;\n}\n#copy-image-base .base-box {\n  position: relative;\n  top: -24px;\n}\n#copy-image-base .content {\n  padding: 20px;\n  display: flex;\n  flex-flow: row nowrap;\n}\n#copy-image-base .content .copy-image-instructions {\n  width: 10em;\n  margin-right: 20px;\n}\n#copy-image-base .content .copy-image-instructions p:first-child {\n  margin-top: 0;\n}\n#copy-image-base .content .copy-image-instructions .sub-head {\n  font-size: 0.9em;\n}\n#copy-image-base .content .copy-image-source-container {\n  display: flex;\n  flex-flow: row nowrap;\n  align-items: center;\n  justify-content: center;\n}\n#copy-image-base .content .copy-image-source-container .copy-image-source {\n  max-width: 50vw;\n  max-height: 50vh;\n  box-shadow: 0 5px 10px 0 grey;\n}\n#activity-display .header {\n  border-bottom: solid 2px #CCC;\n  background-color: white;\n  color: #333;\n  justify-content: center;\n  padding: 0 15px;\n}\n#activity-display .header .close-button {\n  /* Give the title full width to center itself. */\n  position: absolute;\n  right: 0;\n  top: 0;\n}\n#activity-display .content {\n  padding: 5px 10px 10px 10px;\n}\n#activity-display .content .description {\n  font-size: 10pt;\n  font-weight: 500;\n  text-align: center;\n}\n#activity-display .content #activity-display-code {\n  padding: 15px 25px;\n  font-family: Monaco, monospace;\n  font-size: 6em;\n  text-align: center;\n  text-transform: uppercase;\n}\n#activity-display .submit-glyph-inline {\n  height: 1.2em;\n  width: 24px;\n  vertical-align: bottom;\n}\n#submit-activity-submit-box .header .error-text {\n  display: none;\n}\n#submit-activity-submit-box.show-error .header {\n  background: #ac312e;\n}\n#submit-activity-submit-box.show-error .header span {\n  display: none;\n}\n#submit-activity-submit-box.show-error .header .error-text {\n  display: inline;\n}\n#submit-activity-submit-box.show-error input {\n  color: #ac312e;\n}\n#submit-activity-ui-container {\n  padding: 15px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n#submit-activity-ui-container .submit-icon {\n  width: 48px;\n}\n#submit-activity-ui-container .input-container {\n  margin: 0 15px;\n}\n#submit-activity-ui-container .input-container input {\n  font-family: Monaco, monospace;\n  text-transform: uppercase;\n  padding-left: 15px;\n  padding-right: 15px;\n  width: 6em;\n}\n#submit-activity-ui-container #submit-activity-target-background {\n  box-shadow: none;\n  background: white;\n  color: grey;\n}\n#submit-activity-ui-container #submit-activity-target {\n  position: absolute;\n  top: 0;\n  right: 0;\n  bottom: 0;\n  left: 0;\n  background: transparent;\n}\n/* --- End base styles --- */\n.calculator-input input {\n  width: 414px;\n  height: 44px;\n  font: 300 32px Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  padding: 2px 4px;\n}\n.calculator-textarea textarea {\n  width: 414px;\n  height: 202px;\n  font: 300 30px Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  line-height: 1.1;\n  padding: 2px 4px;\n  resize: none;\n  overflow: auto;\n}\n.infopage {\n  display: none;\n  position: absolute;\n  left: 0;\n  top: 0;\n  height: 100%;\n  width: 100%;\n  z-index: 200;\n  background-color: #cce0ff;\n  /* hide about initially */\n}\n.infopage .titlebar {\n  display: flex;\n  position: absolute;\n  width: 100%;\n  z-index: 10;\n  height: 50px;\n  background-color: #0287cf;\n  color: white;\n  text-align: center;\n  font-weight: bold;\n  line-height: 50px;\n}\n.infopage .sectionwrapper {\n  display: flex;\n  justify-content: center;\n  text-align: center;\n  line-height: 13px;\n  margin: auto;\n}\n.infopage .title {\n  display: inline-block;\n  color: white;\n  font-size: 13px;\n  cursor: pointer;\n  margin: 5px 0;\n  padding: 6px 5px;\n  text-align: center;\n  width: 100px;\n  border: solid 1px white;\n}\n.infopage .title:first-child {\n  border-bottom-left-radius: 5px;\n  border-right: medium none;\n  border-top-left-radius: 5px;\n}\n.infopage .title:last-child {\n  border-bottom-right-radius: 5px;\n  border-right: 1px solid white;\n  border-top-right-radius: 5px;\n}\n.infopage .title.selected {\n  color: #0287CF;\n  background-color: white;\n}\n.infopage .close {\n  display: inline-block;\n}\n.infopage .close {\n  float: right;\n  cursor: pointer;\n  padding-right: 15px;\n  font-weight: normal;\n}\n.infopage .infowrapper {\n  height: 100%;\n}\n.infopage .contents-wrapper {\n  height: 100%;\n  background-color: #cce0ff;\n  overflow-y: scroll;\n  overflow-x: hidden;\n}\n.infopage .contents {\n  padding-top: 50px;\n  margin: 0 10px 10px;\n}\n.infopage .contents.about {\n  display: none;\n}\n.infopage .box {\n  background-color: white;\n  border-radius: 10px;\n  margin: 10px auto;\n  max-width: 810px;\n  min-width: 500px;\n  padding: 30px;\n}\n.infopage .infohead {\n  color: #0081c6;\n  font: bold 36px Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  margin: 0;\n  text-align: center;\n}\n.infopage .infohead.howto {\n  margin-bottom: 1em;\n}\n.infopage .infohead.rule-line {\n  border-top: 4px solid #a4dfff;\n  margin: 30px -30px 0;\n  padding-top: 30px;\n}\n.infopage .info-subhead {\n  color: #0081c6;\n  font: bold 28px Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  margin: 0 0 20px;\n  text-align: left;\n}\n.infopage .info-subhead-description {\n  color: #0081c6;\n  font: 18px Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n  line-height: 1.4em;\n  margin: -15px 0 30px;\n  text-align: left;\n}\n.infopage .infobody,\n.infopage .box ul,\n.infopage .info-buttons p {\n  color: #666;\n  font: 18px/1.4em Roboto, 'Helvetica Neue', Helvetica, Arial, sans-serif;\n}\n.infopage .infolink {\n  text-align: center;\n  font-size: 24px;\n  padding-bottom: 10px;\n}\n.infopage img {\n  text-decoration: none;\n  border: 0px;\n}\n.infopage .info_illus {\n  margin: 40px 0;\n  text-align: center;\n}\n.infopage .info_illus img {\n  max-width: 100%;\n}\n.infopage .infoversion {\n  font-size: 11pt;\n  text-align: center;\n  color: #666;\n}\n.infopage a.about-link {\n  color: #0287CF;\n  display: block;\n  font-weight: bold;\n  text-align: center;\n  transition: opacity 0.2s ease 0s;\n  width: 100%;\n}\n.infopage a.about-link:hover {\n  opacity: 0.5;\n}\n.flex {\n  display: -webkit-box;\n  display: -moz-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n}\n.two-column {\n  width: 50%;\n}\n.two-column-wide {\n  width: 55%;\n}\n.two-column-small {\n  width: 45%;\n}\n/* roboto-300 - latin */\n@font-face {\n  font-family: 'Roboto';\n  font-style: normal;\n  font-weight: 300;\n  src: url(" +
          codeEls +
          ") format('woff2'),  url(" +
          threshold +
          ") format('woff');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-300italic - latin */\n@font-face {\n  font-family: 'Roboto';\n  font-style: italic;\n  font-weight: 300;\n  src: url(" +
          noResults +
          ") format('woff2'),  url(" +
          subs +
          ") format('woff');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-regular - latin */\n@font-face {\n  font-family: 'Roboto';\n  font-style: normal;\n  font-weight: 400;\n  src: url(" +
          button2Component +
          ") format('woff2'),  url(" +
          countDiv +
          ") format('woff');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-italic - latin */\n@font-face {\n  font-family: 'Roboto';\n  font-style: italic;\n  font-weight: 400;\n  src: url(" +
          ftype +
          ") format('woff2'),  url(" +
          pseudoNames +
          ") format('woff');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-700italic - latin */\n@font-face {\n  font-family: 'Roboto';\n  font-style: italic;\n  font-weight: 700;\n  src: url(" +
          pencil +
          ") format('woff2'),  url(" +
          current +
          ") format('woff');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n/* roboto-700 - latin */\n@font-face {\n  font-family: 'Roboto';\n  font-style: normal;\n  font-weight: 700;\n  src: url(" +
          markStart +
          ") format('woff2'),  url(" +
          originalB +
          ") format('woff');\n  /* Chrome 6+, Firefox 3.6+, IE 9+, Safari 5.1+ */\n}\n@keyframes missing-feature {\n  0% {\n    background-color: red;\n  }\n  17% {\n    background-color: magenta;\n  }\n  33% {\n    background-color: blue;\n  }\n  50% {\n    background-color: cyan;\n  }\n  67% {\n    background-color: green;\n  }\n  83% {\n    background-color: yellow;\n  }\n  100% {\n    background-color: red;\n  }\n}\n.missing-feature {\n  animation: missing-feature 600s infinite linear;\n}\n.beta-tag::after {\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n  content: \"BETA\";\n  font-size: 1.5em;\n  background: #0273af;\n  opacity: 0.75;\n  position: absolute;\n  padding: 0.2em 0.4em;\n  top: 0.3em;\n  right: 0.3em;\n  color: #fff;\n  border-radius: 3px;\n  font-weight: 600;\n  pointer-events: none;\n}\n#toolbar .toolbar-button-container.narrow {\n  flex-basis: 32px;\n}\n#toolbar .toolbar-button-container.wide {\n  flex-basis: 32px;\n}\n#toolbar .toolbar-divider {\n  height: 48px;\n  flex: 0 0 2px;\n  margin: 0 7px;\n  border: none;\n  background: #4da7d7;\n}\n.input-feedback {\n  position: absolute;\n  background: url(" +
          el +
          ");\n  width: 400%;\n  height: 100%;\n  left: 0;\n  top: 0;\n  border-radius: 3px;\n  align-items: center;\n  justify-content: center;\n  display: none;\n  z-index: 10;\n  background-size: 48px;\n  opacity: 0;\n  color: #4a7727;\n  font-size: 1.2em;\n  letter-spacing: 0.025em;\n  user-select: none;\n}\n@keyframes pulse-feedback {\n  10% {\n    left: -150%;\n    background-size: 8px;\n    opacity: 1;\n  }\n  80% {\n    left: -150%;\n    background-size: 8px;\n    opacity: 1;\n  }\n}\n.input-feedback-pulse {\n  animation-duration: 2.5s;\n  animation-name: pulse-feedback;\n  display: flex;\n}\n.button-field {\n  position: relative;\n  width: 100%;\n}\n.button-field input {\n  width: calc(100% - 10px);\n  height: calc(100% - 12px);\n}\n.button-field .input-container {\n  position: relative;\n  flex-grow: 1;\n  overflow: hidden;\n}\n#base-stage {\n  display: none;\n}\n#save-popout {\n  width: 380px;\n}\n#save-popout .base-box {\n  position: relative;\n  right: 130px;\n}\n#save-popout {\n  user-select: text;\n  -moz-user-select: text;\n  -webkit-user-select: text;\n  -ms-user-select: text;\n  -webkit-user-drag: auto;\n}\n#save-popout .content {\n  background-color: white;\n  padding: 15px;\n  display: flex;\n  flex-direction: column;\n}\n#save-popout .content #share-image-ui-container {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n}\n#save-popout .content .description {\n  display: flex;\n  flex-flow: row nowrap;\n  align-items: center;\n  margin-bottom: 0.75em;\n}\n#save-popout .content .description .description-icon {\n  height: 18px;\n  margin-right: 0.5em;\n}\n#save-popout .content .share-image-button-container {\n  display: flex;\n  flex-flow: row nowrap;\n  width: calc(100% + 10px);\n  margin: 0 -5px;\n}\n#save-popout .content .share-image-button-container .text-button {\n  margin: 0 5px;\n  padding-left: 0;\n  padding-right: 0;\n  flex-basis: 0;\n  flex-grow: 1;\n}\n#save-popout .content .popout-divider {\n  margin: 1em -15px;\n  flex-grow: 0;\n  flex-basis: 2px;\n  background: #CCC;\n}\n#edit-clock-base {\n  left: 0;\n}\n#edit-clock-base .base-background {\n  /**\n     * Pass through pointer events on HTML palettes so Page can handle dismissal,\n     * and other workspace interactions can still occur.\n     */\n  pointer-events: none;\n}\n#edit-clock-box .checkboxes input[type='checkbox'] + label::before {\n  content: ' ';\n  display: inline-block;\n  background-image: url(" +
          tree +
          ");\n  width: 30px;\n  height: 30px;\n  margin-right: 10px;\n  margin-left: 8px;\n}\n#edit-clock-box .checkboxes input[type='checkbox']:checked + label::before {\n  background-image: url(" +
          $buttonEl +
          ");\n}\n#edit-clock-box input[type='radio'] {\n  display: none;\n}\n#edit-clock-box input[type='radio'] + .face-select-button {\n  width: 70px;\n  height: 70px;\n  margin: 1px;\n  background-image: url(" +
          self +
          ");\n}\n#edit-clock-box input[type='radio'] + .face-select-button .button-icon {\n  width: 70px;\n  height: 70px;\n}\n#edit-clock-box input[type='radio']:checked + .face-select-button {\n  background-image: url(" +
          node +
          ");\n}\nlabel[for='face-button-increments'] .button-icon {\n  background-image: url(" +
          $origin +
          ");\n}\nlabel[for='face-button-arabic'] .button-icon {\n  background-image: url(" +
          btn +
          ");\n}\nlabel[for='face-button-roman'] .button-icon {\n  background-image: url(" +
          $inputElem +
          ");\n}\nlabel[for='face-button-blank'] .button-icon {\n  background-image: url(" +
          BROADCASTER +
          ");\n}\n#new-clock-box {\n  padding: 12px;\n  background-color: #233239;\n}\n#new-clock-box .title {\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n  font-size: 26px;\n  color: #fff;\nbackground-color:#101519;padding: 8px;\nborder-radius: 5px;\n}\n#new-clock-box .content button {\n  display: flex;\n  align-items: center;\n  padding: 13px 12px;\n  margin: 2px 0;\n  background-color: #233239;\n  color: #fff;\n}\n#new-clock-box .content button img {\n  flex-shrink: 0;\n  margin-right: 10px;\n  height: 32px;\n  width: 32px;\n}\n#new-clock-box .content button .label {\n  width: 230px;\n  font-size: 19px;\n  text-align: left;\n}\n/* Removes default styling for generic framework bases. */\n#fraction-fill-base.popup {\n  bottom: 40px;\n}\n#fraction-fill-base.popup::after {\n  /* Remove default after styling for bases created with the Framework. */\n  display: none;\n}\n#fraction-fill-base.popup .base-background {\n  display: none;\n}\n.fraction-fill-palette {\n  box-sizing: content-box;\n  display: flex;\n  justify-content: space-between;\n  flex-direction: row;\n  width: 214px;\n  height: 24px;\n  padding: 12px 20px 22px 20px;\n  background-image: url(" +
          timelineDiv +
          ");\n}\n.fraction-fill-palette .fraction-fill-button {\n  width: 24px;\n  height: 24px;\n  background-repeat: no-repeat;\n}\n.fraction-fill-palette .fraction-fill-button .fraction-fill-active {\n  background-repeat: no-repeat;\n  background-position: center;\n  width: 24px;\n  height: 24px;\n  pointer-events: none;\n}\n.fraction-fill-palette[data-active-color='red'] #fraction-fill-red .fraction-fill-active {\n  background-image: url(" +
          item +
          ");\n}\n.fraction-fill-palette[data-active-color='orange'] #fraction-fill-orange .fraction-fill-active {\n  background-image: url(" +
          item +
          ");\n}\n.fraction-fill-palette[data-active-color='yellow'] #fraction-fill-yellow .fraction-fill-active {\n  background-image: url(" +
          item +
          ");\n}\n.fraction-fill-palette[data-active-color='green'] #fraction-fill-green .fraction-fill-active {\n  background-image: url(" +
          item +
          ");\n}\n.fraction-fill-palette[data-active-color='blue'] #fraction-fill-blue .fraction-fill-active {\n  background-image: url(" +
          item +
          ");\n}\n.fraction-fill-palette[data-active-color='purple'] #fraction-fill-purple .fraction-fill-active {\n  background-image: url(" +
          item +
          ");\n}\n#fraction-fill-red {\n  background-image: url(" +
          memoryx +
          ");\n}\n#fraction-fill-orange {\n  background-image: url(" +
          cloned_options +
          ");\n}\n#fraction-fill-yellow {\n  background-image: url(" +
          nb +
          ");\n}\n#fraction-fill-green {\n  background-image: url(" +
          actionsTemplate +
          ");\n}\n#fraction-fill-blue {\n  background-image: url(" +
          t +
          ");\n}\n#fraction-fill-purple {\n  background-image: url(" +
          jxml +
          ");\n}\n#canvas.draw-cursor:not(.pan-cursor) {\n  cursor: url(" +
          newItem +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.draw-cursor[data-draw-color='BLACK']:not(.pan-cursor) {\n  cursor: url(" +
          this_area +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.draw-cursor[data-draw-color='BLUE']:not(.pan-cursor) {\n  cursor: url(" +
          et +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.draw-cursor[data-draw-color='GREEN']:not(.pan-cursor) {\n  cursor: url(" +
          stationTable +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.draw-cursor[data-draw-color='YELLOW']:not(.pan-cursor) {\n  cursor: url(" +
          ae +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.draw-cursor[data-draw-color='ORANGE']:not(.pan-cursor) {\n  cursor: url(" +
          slideoutMenu +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.draw-cursor[data-draw-color='RED']:not(.pan-cursor) {\n  cursor: url(" +
          myRootLocation +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.erase-cursor:not(.pan-cursor) {\n  cursor: url(" +
          searchIco +
          "), crosshair !important;\n  /* !important gets around bugginess with EaselJS cursor setting and IE */\n}\n#canvas.pan-cursor {\n  cursor: grab;\n}\n#canvas.pan-cursor:active {\n  cursor: grabbing;\n}\n#loading-spinner {\n  position: fixed;\n  left: 50%;\n  top: 50%;\n}\n/* -----\nToolbar Buttons\n----- */\n#toolbar .button-group.tab {\n  background-color: inherit;\n  position: relative;\n  top: -12px;\n  align-items: center\n  box-sizing: content-box;\n}\ntoolbar-button {\n  background-size: auto 24px;\n}\n#restart {\n  background-image: url(images/reset.png);\n background-size: contain;\n}\n#new-clock {\n  background-image: url(images/add-clock.png);\nbackground-size:cover;\nwidth: 120px !important;\nheight: 120px !important;\n}\n#edit-clock.on {\n  /* @todo Needsa -down state image, like Equation/Text. */\n  opacity: 0.5;\n}\n#run-jump-mode.on {\n  background-image: url(" +
          tableBs +
          ");\n}\n#save {\n  background-image: url(" +
          $vid +
          ");\n}\n#info {\n  background-image: url(" +
          messageField +
          ");\n}\n/* How To Styling */\n/* To be moved to framework as part of Info page refactor */\n.infopage .infowrapper {\n  display: flex;\n  flex-flow: column nowrap;\n}\n.infopage .titlebar {\n  flex: 0 0 50px;\n  position: relative;\n  height: auto;\n}\n.infopage .contents-wrapper {\n  flex: 1 0 0;\n  height: auto;\n  overflow-y: hidden;\n}\n.infopage .contents {\n  width: 100%;\n  height: 100%;\n  border: none;\n  margin: 0;\n  padding: 0;\n}\nh1,\nh2 {\n  color: #0273af;\n}\n.infopage .titlebar {\n  background-color: #0273af;\n}\n.infopage .title.selected {\n  color: #0273af;\n}\n.infopage .info-subhead {\n  margin-bottom: 1em;\n}\n.howto-overview {\n  display: inline-flex;\n  flex-wrap: wrap;\n}\n.howto-overview .instructions {\n  font-size: 18px;\n  margin-bottom: 2.5em;\n  /*.flex;*/\n  display: flex;\n  box-sizing: border-box;\n  align-items: flex-start;\n}\n.howto-overview .instructions.left {\n  padding-right: 1.5em;\n}\n.howto-overview .instructions.right {\n  padding-left: 1.5em;\n}\n.howto-overview .instructions img {\n  max-height: fit-content;\n  height: 100%;\n}\n.howto-overview .instructions img.left-edge {\n  margin-right: 1em;\n}\n.howto-overview .instructions img.right-edge {\n  margin-left: 0.5em;\n}\n.howto-overview .instructions img.right-center {\n  margin-right: 1em;\n}\n.howto-overview .instructions img.left-center {\n  margin-left: 1em;\n}\n.howto-overview .instructions p {\n  line-height: 1.45em;\n  color: #444;\n  margin: 0;\n}\n.howto-toolbar table {\n  width: 100%;\n  border-collapse: collapse;\n  margin-bottom: 3em;\n}\n.howto-toolbar table td,\n.howto-toolbar table th {\n  border: 1px solid #ddd;\n  padding: 8px;\n  text-align: center;\n}\n.howto-toolbar table td.icon,\n.howto-toolbar table th.icon {\n  background-color: #0081c6;\n  text-align: center;\n}\n.howto-toolbar table td.tool,\n.howto-toolbar table th.tool {\n  font-weight: bold;\n}\n.howto-toolbar table td.description,\n.howto-toolbar table th.description {\n  text-align: left;\n  padding-left: 1em;\n}\n.howto-toolbar table th {\n  padding-top: 12px;\n  padding-bottom: 12px;\n  text-align: center;\n  background-color: #0273af;\n  color: white;\n}\n.howto-toolbar table th.left-align {\n  text-align: left;\n  padding-left: 1em;\n}\n.howto-toolbar table img {\n  margin: 0 0.2em;\n  vertical-align: middle;\n  height: 24px;\n}\n.howto-toolbar .keyboard-support-table {\n  margin-bottom: 1em;\n}\n.howto-toolbar .keyboard-support-table td.tool {\n  text-align: left;\n  padding-left: 1em;\n}\n.about a.about-link {\n  color: #0273af;\n}\n.about .privacy-terms,\n.about .infoversion {\n  text-align: center;\n  color: #444;\n}\n.about .privacy-terms a,\n.about .infoversion a {\n  font-weight: bold;\n  text-decoration: none;\n  color: #223087;\n}\n@media all and (max-width: 767px) {\n  .howto-overview .instructions.left,\n  .howto-overview .instructions.right {\n    padding-right: 0;\n    padding-left: 0;\n    width: 90%;\n  }\n}\n",
        "",
      ]);
      /** @type {(Object|string)} */
      module.exports = exports;
    },
    Fo0n: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NDkxMSwgMjAxMy8xMC8yOS0xMTo0NzoxNiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjM1RUQ2NDczMDQ4MTExRTRBN0ZGOEQwMUI0RkM4OTRDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjM1RUQ2NDc0MDQ4MTExRTRBN0ZGOEQwMUI0RkM4OTRDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MzVFRDY0NzEwNDgxMTFFNEE3RkY4RDAxQjRGQzg5NEMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MzVFRDY0NzIwNDgxMTFFNEE3RkY4RDAxQjRGQzg5NEMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5kTM7TAAAF+0lEQVR42uRaW0ijRxT+c/G2ppsm9ZKs3TYbY1DjWmO2QqGKoLCtD17xIaAoimW1CupLQUorFaUoCCpi7MM+SbNFvFQU7IMg7UpfqoE1Xqjp6m67GJMazWrXu+mZ3cn2929M/kmipvTAB06cf/755pw558yZn0P5T6IAbwFEACFAAAgDBOP/HwL2ALsAO2ALsAmw+OPlHB+flwBiMCRejmEGPMMwXzaRdwBygIy24r4K0tga4DHg6UUTQeajxOBTFyPHgF8xWJsdj+AFiYA7WBtc6uIEjR2JFw2J1V9E0KbVAN7Hm/eyJAwvGjLdbWx6XhMRYS0kUFcn0ZgUIrPvTo2eSCh8nYnRaKxSq9Vv+DCEAs9FREoEmZMacMsfS6pSqe7MzMx82dnZqfFhmFt4TgISr/UB4La/bMPhcPQ7/15cXJwtKSnRGwyGHS+Hmwf8zEYjif4k8a/BExM1PmrnNp6jW40gl5cBEHs7Ua1WG1NaWqpOSEhQRERESMLCwgQ8Hi/IVV8ftGMD/EiPM0wiH7piy0ZaWlqSKysrc6RSKdG+2tvb29HpdPrGxsZZwlcuAh46G3xG2qEkJaDRaK7r9frSuLi4ZK9yJA7H21RJiVOZp0wictK0o6ys7GZvb29deHi40BsSYFpzYFrfernx+XjOZ4hIcALIWioqKt7t6+trCA4OPhPtT0FWVlbmp6amZicmJlbn5ua219fXe+h99vf3d+DZB2BOv/joO2R47mYnkRiSLDYtLU3Y3d1dyyRhMpmMDQ0N342Pj1suSAtMCcZzP0OEtcCeKAdzuk4PFd+DFBYWToJCHK6e8aMWmILmPsvHLpf1oai9vV0tl8vPeDbgMJqfnz95SVpwdbiL4uCEMJ3tUxaL5fPIyMibzjbsh0dKpbKXulr5iesuEWNKVVWVjE4CzOikurr6AXX1IuLiQgErKS4ufo9hMgbwTpsBQETIPS+bdBmBlMozKT2QMFCBIQIuyakPcqdoehvixFqAEAnjksSP0NDQa/Q2BDt7gBAJJq2EnMmJIJbwNjc3j/wxE5lMFrq6utrlbJ+cnBzz+fxPSSoWh2w7HxwcvKC3U1NThf5a0pSUFCEjgL4gqYkhIntse8Pqb9DbGRkZb/uLCHMsm822QXIaQER22faGXOoxvZ2VlZXiLyLZ2dlqd+/yILuICOsNC8ngPL2dlJSUCisp8oM2RCqVSs3wiEaCIexEKQqXy+WAyr8SCoVR9DwKJtHvC5GlpaV78fHxr4nY7XaLWCz+4rwE9LwUhXVkRgMPDg5OMooJqcPDw3e9JTE6OvoRnQSSoaGhSQISL7ev053mss2AQ0JCuGtra59JJBIZrdxzChMahTT+BxISIyMjd/Py8go4+LyLxGw2PwFX/DV4yFOWw6CriDFnOegZgQs+hUTx/tHR0QHt3M0tKCgoBDO7l5OTE+VpDNRneXm5GlL/QjoJNGZNTc19AhKv5+6s/TpwJY9VdR4m8RePx/sdNqkGkXD+DpmxVKvVZhQVFUliY2M5YB6HVqv1EE6S3PT0dHFtbW1CR0fHx/X19Vroe4Nhtsetra39Op2OxFuhGIjyvV16pM4kraI0NzcnNTU1fRIUFBTiy2ZHmmhra/sGxjMSPoruUKYphgZO8WGe9d3H9PS0xWg0GjIzM+UCgeBNb0hsbGw8KS8v7ybUBBJ0ITTrDB90IuiHcOrVJQtrATPb7erqeiiVSm1gTjcgsQxn5fjtduvAwMAQBEL9wsLCrhdrsEy9qgO7rDT6VDIFE+PU1dUpcnNzkxUKRaxIJIrExBwod9ra2rJCxP5tbGzsUU9PjwlMyuGlNXosmb4MDdSr0mkgCyqVLtJ/cOWlrPiMEh2gJOaxp6I8EUGyjU+O4gAjYcIkDtkSOcRkrpFUWS5YVtGhFPDc1T/dBUB08Yg+swgJAM2YMImt8zp4iuT71D/33NFXvCeeu+vEJiVBZvYHPkkKqMu7a7fhgGdgcxwn+fIBaeZPnAGIqIv7+uEYBztkSqzLTf/bj2qY8p//zMmVXOmHZ38LMAA67Spla61j5wAAAABJRU5ErkJggg==";
    },
    GWf8: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    H1HQ: function (l, it, p) {
      l.exports = p.p;
    },
    Hni1: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-300.b00849e00f4c2331cddd8ffb44a6720b.woff";
    },
    HpR4: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "IZU+": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-faceselect-blank.41ae07b623a3bb42462771923ab13d71.png";
    },
    Ic0E: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    Iu71: function (l, it, p) {
      l.exports = p.p;
    },
    Iv4c: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-regular.60fa3c0614b8fb2f394fa29944c21540.woff";
    },
    J8P3: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/45stripe.9925a52084f7737cc3daa77635ef59f5.svg";
    },
    "JY+c": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-add-clock.c32c2de949472c6e98952496e396e1a1.png";
    },
    JhVI: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/widget-elapsed-cancel-icon.360923e307106f288fba21a9e85d4d74.png";
    },
    KUtk: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-300italic.14286f3ba79c6627433572dfa925202e.woff2";
    },
    "M9x/": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-faceselect-bg-off.35381b350adec9e44b1660646eecef41.png";
    },
    MuzD: function (vdwB, d, $) {
      /**
       * @param {?} immediate
       * @param {!Object} options
       * @return {undefined}
       */
      function filter(immediate, options) {
        //console.log("filter: ",immediate, options); //Vikas
        (options = options || {}).rotatable = {
          mousedown: true,
          pressmove: function () {
            //console.log("Drag clock hands..")//Vikas- Note: Drag clock hands
            /** @type {string} */
            var targetType = "";
            var prevXY = this.display.localToLocal(0, 0, this.topmostParent.t);
            var startPoint = this.interactionState.previousPosition;
            var currentXY = this.interactionState.currentPosition;
            /** @type {number} */
            var tstart = Math.atan2(prevXY.y - startPoint.y, prevXY.x - startPoint.x);
            /** @type {number} */
            var lat = Math.atan2(prevXY.y - currentXY.y, prevXY.x - currentXY.x) - tstart;
            /** @type {number} */
            var phi = 1 / 0;
            if ((lat = lat * _this.d.RADIANS_TO_DEGREES) < 0) {
              /** @type {number} */
              phi = lat + 360;
            }
            if (lat > 0) {
              /** @type {number} */
              phi = lat - 360;
            }
            if (Math.abs(phi) < Math.abs(lat)) {
              /** @type {number} */
              lat = phi;
            }
            (targetType = new doc.a.Event(data.Events.HAND_CHANGED)).set({
              id: this.id,
              newAngle: this.angle + lat,
            });
            _this.f.dispatchEvent(targetType);
          },
          pressup: true,
        };
        _this.c.call(this, immediate, options);
        _this.m.addInterfaces(this, this.display, {
          rotatable: options.rotatable,
        });
        this.labelOn = options.labelOn || false;
        this.handGraphics = options.handGraphics || new doc.a.Graphics();
        this.handLabel = options.handLabel || new doc.a.Graphics();
        this.handHitArea = options.handHitArea || null;
        this.angle = req.a.isNumber(options.initialAngle) ? options.initialAngle : 0;
        this.setupDisplayComponents(options);
      }
      /**
       * @param {?} casperInstance
       * @param {!Object} config
       * @return {undefined}
       */
      function CheckerToolkit(casperInstance, config) {
        //console.log("toolkit: ", casperInstance, config);//Vikas
        config = config || {};
        _this.c.call(this, casperInstance, config);
        this.angle = config.angle || 0;
        this.setupDisplayComponents(config);
      }
      /**
       * @param {?} value
       * @param {string} params
       * @return {undefined}
       */
      function test(value, params) {
        //console.log("Step 3 : test"); //Vikas Note: Step: 3
        var listeners;
        var wunderlist_list = this;
        params = req.a.clone(params) || {};
        req.a.defaults(params, {
          dimensions: {
            width: 160,
            height: 36,
          },
          readoutDisplayMode: readFunction,
          enabled: true,
          canToggle: false,
        });        
        
        listeners = {
          mousedown: function () {},
          pressup: function () {},
          click: function (event) {
            //console.log("DONE", event); //Vikas
            var c = new doc.a.Event(data.Events.DIGITAL_READOUT_TOGGLE_ACTIVE);
            if (!(_this.c.getFirstParentEntity(event.target) instanceof _this.b)) {
              c.set({
                ids: [wunderlist_list.id],
              });
              _this.f.dispatchEvent(c);
            }
          },
        };
        _this.c.call(this, value, params);
        _this.m.addInterfaces(this, this.display, {
          clickable: listeners,
        });
        this.readoutDisplayMode = params.readoutDisplayMode;
        this.readoutDisplayModeCanToggle = params.canToggle;
        /** @type {boolean} */
        this.active = false;
        this.enabled = params.enabled;
        this._setupDisplayComponents(params);
        this.setTime(params.hours, params.minutes);
        this.draw();
        this._bindDispatcherEvents();
      }

      function testTellTime(value, params) {
        //console.log("step 3: testTellTime", readFunction); //Vikas Step: 3
        var listeners;
        var wunderlist_list = this;
        params = req.a.clone(params) || {};
        params.tellTimeDisplayMode = readFunction;
        req.a.defaults(params, {
          dimensions: {
            width: 300,
            height: 150,
          },
          tellTimeDisplayMode: readFunction,
          enabled: true,
          canToggle: false,
          timeEnabled: false,
        });

        //console.log("testTELL TIME: ", params.hours, params.minutes);//Vikas
        listeners = {
          mousedown: function () {},
          pressup: function () {},
          click: function (event) {
            var c = new doc.a.Event(data.Events.TELL_TIME_TOGGLE_ACTIVE);
            if (!(_this.c.getFirstParentEntity(event.target) instanceof _this.b)) {
              c.set({
                ids: [wunderlist_list.id],
              });
              _this.f.dispatchEvent(c);
            }
          },
        };
        _this.c.call(this, value, params);
        _this.m.addInterfaces(this, this.display, {
          clickable: listeners,
        });
        this.tellTimeDisplayMode = params.tellTimeDisplayMode;
        this.tellTimeDisplayModeCanToggle = params.canToggle;
        /** @type {boolean} */
        this.active = false;
        this.enabled = params.enabled;
        this.timeEnabled = params.timeEnabled;
        this._setupDisplayComponents(params);
        this.setTime(params.hours, params.minutes);
        this.draw();
        this._bindDispatcherEvents();
      }

      /**
       * @param {?} casperInstance
       * @param {?} config
       * @return {undefined}
       */
      function M6CorpoChecker_HpPro(casperInstance, config) {
        //console.log("M6CorpoChecker_HpPro", casperInstance, config);//Vikas
        _this.c.call(this, casperInstance, config);
        this._setupDisplayComponents();
      }
      /**
       * @param {!Object} connection
       * @param {number} from
       * @return {undefined}
       */
      function getEvents(connection, from) {
        var deviceOrientationEvent;
        var $input;
        /** @type {number} */
        var smoothArcSteepness = 0;
        if (
          (function (pathToDestinationFile) {
            //console.log("Call test", pathToDestinationFile);
            return new RegExp(/^\d{1,2}$/).test(pathToDestinationFile);
          })(($input = debug()("input", connection.input.htmlElement)).val())
        ) {
          smoothArcSteepness = pipe()($input.val(), 10);
          (deviceOrientationEvent = new doc.a.Event(data.Events.JUMP_BY_AMOUNT)).set({
            ids: [connection.id],
            jumpAmount: smoothArcSteepness * from,
          });
          _this.f.dispatchEvent(deviceOrientationEvent);
        }
      }
      /**
       * @param {?} plot
       * @param {string} opts
       * @return {undefined}
       */
      function HtmlAxisLabel(plot, opts) {
        opts = req.a.clone(opts) || {};
        req.a.defaults(opts, {
          initialJumpStep: 20,
        });
        _this.c.call(this, plot, opts);
        this._setupDisplayComponents(opts);
      }
      /**
       * @param {?} target
       * @param {string} props
       * @return {undefined}
       */
      function Tween(target, props) {
        props = req.a.clone(props) || {};
        //console.log("TWEEN Props: ", props);//Vikas
        req.a.defaults(props, {
          dimensions: {
            width: 294,
            height: 72,
          },
          controlMode: toolsElement,
        });
        _this.c.call(this, target, props);
        this.controlMode = props.controlMode;
        this._setupDisplayComponents(props);
        this.draw();
        this._bindDispatcherEvents();
      }
      /**
       * @param {?} callback
       * @return {?}
       */
      function func(callback) {
        /** @type {!Array} */
        var t = [];
        return (
          req.a.each(callback, function (c, value) {
            var i = pipe()(value.split("_")[1], 10);
            i = refreshFunc()(i) ? 0 : i;
            if ("shape" === write()(value).call(value, 0, 5)) {
              !(function (options, delta, separator) {
                req.a.each(options.instructions, function (settings) {
                  req.a.each(settings, function (i, direction) {
                    switch (direction) {
                      case "x":
                      case "x0":
                      case "x1":
                      case "cpx":
                      case "cp1x":
                      case "cp2x":
                        settings[direction] += delta;
                        break;
                      case "y":
                      case "y0":
                      case "y1":
                      case "cpy":
                      case "cp1y":
                      case "cp2y":
                        settings[direction] += separator;
                    }
                  });
                });
              })(c.graphics, c.x, c.y);
              t[i] = c.graphics;
            }
          }),
          t
        );
      }
      /**
       * @param {!NodeList} order
       * @param {?} group
       * @return {?}
       */
      function insert(order, group) {
        var _stringBuilder = new doc.a.Graphics();
        return (
          req.a.each(val()(group).call(group), function (name) {
            req.a.each(order[name].instructions, function (e) {
              _stringBuilder.append(e);
            });
          }),
          _stringBuilder
        );
      }
      /**
       * @param {?} material
       * @param {string} config
       * @return {undefined}
       */
      function Particle(material, config) {
        //console.log("Part: ", Particle.caller);//Vikas-- Note: Particle object
        var params = req.a.clone(config || {});
        req.a.defaults(params, {
          active: false,
          radius: data.DEFAULT_CLOCK_RADIUS - data.GENERAL_CLOCK_FACE_PADDING,
          startAngle: 0,
          endAngle: 0,
        });
        _this.c.call(this, material, params);
        this.active = params.active;
        this.startAngle = params.startAngle;
        this.endAngle = params.endAngle;
        this.radius = params.radius;
        this._setupDisplayComponents(config);
      }
      /**
       * @param {?} venueId
       * @param {?} params
       * @return {undefined}
       */
      function start(venueId, params) {
        var options = req.a.defaults(params, {
          unitType: Bar,
          initialFragments: 1,
          fillMode: false,
        });
        var mouse = {
          mousedown: function () {
            var i;
            var shadow11;
            var object = this.display.globalToLocal(this.interactionState.currentPosition.x, this.interactionState.currentPosition.y);
            /** @type {string} */
            this.activeColor = Colors.Transparent;
            if (this.fillMode) {
              i = this.display.getObjectUnderPoint(object.x, object.y);
              if (
                (shadow11 = isLeftButton()(req.a).call(req.a, this.fragments, function (data) {
                  return i === data.shape;
                }))
              ) {
                if (shadow11.color !== this.fillColor) {
                  this.activeColor = this.fillColor;
                }
                shadow11.color = this.activeColor;
                this.draw();
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              }
            }
          },
          pressmove: function () {
            var methodsToOverwrite;
            if (this.fillMode) {
              methodsToOverwrite = this._getFragmentsAlongLine(this.interactionState.previousPosition, this.interactionState.currentPosition);
              req.a.each(
                methodsToOverwrite,
                function (consideration) {
                  consideration.color = this.activeColor;
                },
                this
              );
              this.draw();
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            }
          },
          pressup: function () {
            var i;
            var shadow11;
            var object = this.display.globalToLocal(this.interactionState.currentPosition.x, this.interactionState.currentPosition.y);
            if (this.fillMode) {
              i = this.display.getObjectUnderPoint(object.x, object.y);
              if (
                (shadow11 = isLeftButton()(req.a).call(req.a, this.fragments, function (data) {
                  return i === data.shape;
                }))
              ) {
                shadow11.color = this.activeColor;
                this.draw();
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              }
            }
          },
        };
        _this.c.call(this, venueId, options);
        _this.m.addInterfaces(this, this.display, {
          mouse: mouse,
        });
        this.fillMode = options.fillMode;
        this.unitType = options.unitType;
        if (req.a.isNumber(options.initialFragments)) {
          this.fragmentCount = options.initialFragments;
        } else {
          this.fragmentCount = options.initialFragments.length;
        }
        this._setupDisplayComponents(options);
        this._bindDispatcherEvents();
        /** @type {boolean} */
        this.display.snapToPixel = false;
        this.draw();
      }
      /**
       * @param {?} params
       * @param {number} args
       * @return {undefined}
       */
      function Circle(params, args) {
        var options = req.a.clone(args || {});
        req.a.defaults(options, {
          initialAngle: 0,
          initialFragments: 0,
          radius: data.DEFAULT_CLOCK_RADIUS - data.GENERAL_CLOCK_FACE_PADDING,
          fillMode: false,
          coverFillColor: spatialreference,
        });
        _this.c.call(this, params, options);
        this.angle = options.initialAngle;
        this.radius = options.radius;
        this.fillMode = options.fillMode;
        this.coverFillColor = options.coverFillColor;
        this._setupDisplayComponents(options);
        this._bindDispatcherEvents();
        this.setColorMode(this.fillMode);
      }
      /**
       * @param {?} fn
       * @param {!Object} self
       * @return {undefined}
       */
      function options(fn, self) {
        //console.log("YEEEee", fn , self);//Vikas-- Note: Set options here
        self = req.a.clone(self) || {};
        req.a.defaults(self, {
          activeMajorControl: modifiers,
          clockType: rulelength,
          gearedHands: true,
          digitalReadoutMode: false,
          runJumpMode: false,
          elapsedTimeMode: false,
          tellTimeMode: false,
          fractionMode: false,
          fractionFillMode: false,
          initialFillColor: Et,
          maxRadius: data.MAXIMUM_CLOCK_RADIUS,
          radius: options.LastRadius,
          minuteHandOn: true,
          hourHandOn: true,
          handLabelsOn: false,
          initialTime: {
            hour: 0,
            minute: 0,
            second: 0,
          },
        });
        self.movable = {
          selectable: true,
          mousedown: true,
          pressmove: function (event) {
            var deviceOrientationEvent;
            var entry = _this.c.getFirstParentEntity(event.target);
            /** @type {boolean} */
            var saw_f = entry instanceof _this.j;
            /** @type {boolean} */
            var saw_b = entry instanceof _this.b;
            /** @type {boolean} */
            var saw_u = entry instanceof LogEntry;
            /** @type {boolean} */
            var saw_r = entry instanceof DirSearchPathEntry;
            /** @type {boolean} */
            var adjustHeight = entry instanceof CatchEntry || entry instanceof FinallyEntry;
            var isLessThanMaxAttempts = entry instanceof Array && entry.fillMode;
            if (saw_u) {
              (deviceOrientationEvent = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT)).set({
                ids: [this.id],
                add: false,
              });
              _this.f.dispatchEvent(deviceOrientationEvent);
            }
            if (!(saw_f || saw_b || saw_u || saw_r || isLessThanMaxAttempts)) {
              _this.m.defaultSelectable.pressmove.call(this, event);
            }
            /** @type {boolean} */
            this.handleActive = !(saw_b || saw_u || saw_r || adjustHeight);
            this.draw();
          },
          pressup: function (event) {
            var entry = _this.c.getFirstParentEntity(event.target);
            /** @type {boolean} */
            var saw_f = entry instanceof _this.j;
            /** @type {boolean} */
            var saw_b = entry instanceof _this.b;
            /** @type {boolean} */
            var saw_u = entry instanceof LogEntry;
            /** @type {boolean} */
            var saw_r = entry instanceof DirSearchPathEntry;
            /** @type {boolean} */
            var adjustHeight = entry instanceof CatchEntry || entry instanceof FinallyEntry;
            if (saw_u) {
              this.snapHands();
            } else {
              if (!(saw_f || saw_b || saw_u || saw_r)) {
                _this.m.defaultSelectable.pressup.call(this, event);
              }
            }
            /** @type {boolean} */
            this.handleActive = !(saw_b || saw_u || saw_r || adjustHeight);
            this.draw();
          },
          moveentity: true,
        };
        /** @type {boolean} */
        self.focusable = true;
        /** @type {boolean} */
        self.constrained = true;
        _this.s.call(this, fn, self);
        this.activeMajorControl = self.activeMajorControl;
        /** @type {string} */
        this.runningState = CatchEntry.RunStates.STOP;
        this.clockType = self.clockType;
        this.gearedHands = self.gearedHands;
        /** @type {boolean} */
        this.handleActive = true;
        this.digitalReadoutMode = self.digitalReadoutMode;
        this.runJumpMode = self.runJumpMode;
        this.elapsedTimeMode = self.elapsedTimeMode;
        this.tellTimeMode = self.tellTimeMode;
        this.fractionMode = self.fractionMode;
        this.fractionFillMode = self.fractionFillMode;
        this.maxRadius = self.maxRadius;
        this.minuteHandOn = self.minuteHandOn;
        this.hourHandOn = self.hourHandOn;
        this.handLabelsOn = self.handLabelsOn;
        this.setupDisplayComponents(self);
        this.setRadius(self.radius);
        this.bindDispatcherEvents();
        this.bindDisplayEvents();
        this.setTime(self.initialTime.hour, self.initialTime.minute, self.initialTime.second);
        this.setColorMode(self.initialFillColor);
      }
      /**
       * @param {?} value
       * @return {undefined}
       */
      function update_nb_class(value) {
        doc.a.Tween.removeTweens(value.secondHand);
      }
      /**
       * @return {undefined}
       */
      function create_proxy_with_event_dispatch() {
        var deviceOrientationEvent;
        deviceOrientationEvent = isolatedNodeComponent.isOpen
          ? new doc.a.Event(data.Events.FRACTION_FILL_PALETTE_HIDE)
          : new doc.a.Event(data.Events.FRACTION_FILL_PALETTE_SHOW);
        _this.f.dispatchEvent(deviceOrientationEvent);
      }
      /**
       * @return {undefined}
       */
      function eventHandler() {
        var sig;
        var placeMidpointLine;
        apply();
        send(true);
        var MOVE =
          write()((sig = args.State.activeColor))
            .call(sig, 0, 1)
            .toUpperCase() + write()((placeMidpointLine = args.State.activeColor)).call(placeMidpointLine, 1);
        root.setBackgroundColor(EVENT[MOVE]);
        _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
      }
      /**
       * @param {?} options
       * @return {undefined}
       */
      function create(options) {
        var sig;
        var placeMidpointLine;
        switch ("#" + options.jQueryEvent.target.id) {
          case data.FRACTION_FILL_RED_SELECTOR:
            /** @type {string} */
            args.State.activeColor = "red";
            break;
          case data.FRACTION_FILL_ORANGE_SELECTOR:
            /** @type {string} */
            args.State.activeColor = "orange";
            break;
          case data.FRACTION_FILL_YELLOW_SELECTOR:
            /** @type {string} */
            args.State.activeColor = "yellow";
            break;
          case data.FRACTION_FILL_GREEN_SELECTOR:
            /** @type {string} */
            args.State.activeColor = "green";
            break;
          case data.FRACTION_FILL_BLUE_SELECTOR:
            /** @type {string} */
            args.State.activeColor = "blue";
            break;
          case data.FRACTION_FILL_PURPLE_SELECTOR:
            /** @type {string} */
            args.State.activeColor = "purple";
        }
        apply();
        send(true);
        var MOVE =
          write()((sig = args.State.activeColor))
            .call(sig, 0, 1)
            .toUpperCase() + write()((placeMidpointLine = args.State.activeColor)).call(placeMidpointLine, 1);
        root.setBackgroundColor(EVENT[MOVE]);
      }
      /**
       * @return {undefined}
       */
      function apply() {
        document.querySelector(data.FRACTION_FILL_PALETTE_SELECTOR).setAttribute("data-active-color", args.State.activeColor);
      }
      /**
       * @return {undefined}
       */
      function back() {
        root.setBackgroundColor(r);
        send(false);
      }
      /**
       * @param {string} longpoll
       * @return {undefined}
       */
      function send(longpoll) {
        var sig;
        var placeMidpointLine;
        var beat = new doc.a.Event(data.Events.TOGGLE_FRACTION_FILL_MODE);
        var key =
          write()((sig = args.State.activeColor))
            .call(sig, 0, 1)
            .toUpperCase() + write()((placeMidpointLine = args.State.activeColor)).call(placeMidpointLine, 1);
        var newColor = Array.FragmentColors[key];
        beat.set({
          setTo: longpoll,
          newColor: newColor,
        });
        _this.f.dispatchEvent(beat);
      }
      /**
       * @param {?} data
       * @param {number} gl
       * @return {undefined}
       */
      function View(data, gl) {
        /** @type {boolean} */
        (gl = gl || {}).movable = false;
        _this.q.call(this, data, gl);
        this._setupDisplay(gl);
        this._bindEvents();
      }
      /**
       * @param {?} options
       * @param {number} items
       * @return {undefined}
       */
      function Palette(options, items) {
        /** @type {boolean} */
        (items = items || {}).movable = false;
        _this.q.call(this, options, items);
        /** @type {number} */
        this.width = 272;
        /** @type {number} */
        this.height = 336;
        this._setupDisplay(items);
        this._bindEvents();
      }
      /**
       * @return {undefined}
       */
      function draw() {
        if (utils.isTargetEntity(_this.h)) {
          var rect = e.parent.getBounds();
          var o = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y,
          };
          var leftRenderRect = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y + bounds.height,
          };
          var rightRenderRect = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y + bounds.height / 2,
          };
          var that = bounds.topmostParent.t.localToLocal(rightRenderRect.x, rightRenderRect.y, e.topmostParent.t);
          /** @type {boolean} */
          var s = that.y > rect.height / 2;
          if (s) {
            that = bounds.topmostParent.t.localToLocal(o.x, o.y, e.topmostParent.t);
            /** @type {number} */
            e.x = that.x - e.width / 2;
            /** @type {number} */
            e.y = that.y - e.height - 25 - 12;
            e.y -= bounds._getVerticalPadding() + 1;
          } else {
            that = bounds.topmostParent.t.localToLocal(leftRenderRect.x, leftRenderRect.y, e.topmostParent.t);
            /** @type {number} */
            e.x = that.x - e.width / 2;
            e.y = that.y + 25;
            e.y += bounds._getVerticalPadding() + 1;
          }
          if (e.y < 0) {
            /** @type {number} */
            e.y = 0;
          }
          if (e.y + e.height > rect.height) {
            /** @type {number} */
            e.y = rect.height - e.height;
          }
          if (e.x < 0) {
            /** @type {number} */
            e.x = 0;
          }
          if (e.x + e.width > rect.width) {
            /** @type {number} */
            e.x = rect.width - e.width;
          }
          /** @type {number} */
          e.x = Math.round(e.x);
          /** @type {number} */
          e.y = Math.round(e.y);
          if (s) {
            e.indicator("bottom", that.x - e.x);
          } else {
            e.indicator("top", that.x - e.x);
          }
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
          });
          console.log("dispatch: ", beat);
          e.display.dispatchEvent(beat);
        }
      }
      /**
       * @return {undefined}
       */
      function checkBounds() {
        if (utils.isTargetEntity(_this.w)) {
          var containment = item.parent.getBounds();
          var o = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y,
          };
          var leftRenderRect = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y + bounds.height,
          };
          var rightRenderRect = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y + bounds.height / 2,
          };
          var c = bounds.topmostParent.t.localToLocal(rightRenderRect.x, rightRenderRect.y, item.topmostParent.t);
          /** @type {boolean} */
          var s = c.y > containment.height / 2;
          if (s) {
            c = bounds.topmostParent.t.localToLocal(o.x, o.y, item.topmostParent.t);
            /** @type {number} */
            item.x = c.x - item.width / 2;
            /** @type {number} */
            item.y = c.y - item.height - 25 - 12;
            item.y -= bounds._getVerticalPadding() + 1;
          } else {
            c = bounds.topmostParent.t.localToLocal(leftRenderRect.x, leftRenderRect.y, item.topmostParent.t);
            /** @type {number} */
            item.x = c.x - item.width / 2;
            item.y = c.y + 25;
            item.y += bounds._getVerticalPadding() + 1;
          }
          if (item.y < 0) {
            /** @type {number} */
            item.y = 0;
          }
          if (item.y + item.height > containment.height) {
            /** @type {number} */
            item.y = containment.height - item.height;
          }
          if (item.x < 0) {
            /** @type {number} */
            item.x = 0;
          }
          if (item.x + item.width > containment.width) {
            /** @type {number} */
            item.x = containment.width - item.width;
          }
          /** @type {number} */
          item.x = Math.round(item.x);
          /** @type {number} */
          item.y = Math.round(item.y);
          if (s) {
            item.indicator("bottom", c.x - item.x);
          } else {
            item.indicator("top", c.x - item.x);
          }
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
          });
          item.display.dispatchEvent(beat);
        }
      }
      /**
       * @return {undefined}
       */
      function load() {
        if (bounds instanceof selection) {
          var cc = c.parent.getBounds();
          var o = {
            x: bounds.x,
            y: bounds.y + bounds.height / 2,
          };
          var leftRenderRect = {
            x: bounds.x + bounds.width,
            y: bounds.y + bounds.height / 2,
          };
          var rightRenderRect = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y + bounds.height / 2,
          };
          var b = bounds.topmostParent.t.localToLocal(rightRenderRect.x, rightRenderRect.y, e.topmostParent.t);
          /** @type {boolean} */
          var s = b.x > cc.width / 2;
          if (s) {
            b = bounds.topmostParent.t.localToLocal(o.x, o.y, c.topmostParent.t);
            /** @type {number} */
            c.x = b.x - c.width - 25 - 1;
            /** @type {number} */
            c.y = b.y - c.height / 2;
          } else {
            b = bounds.topmostParent.t.localToLocal(leftRenderRect.x, leftRenderRect.y, c.topmostParent.t);
            c.x = b.x + 25 + 1;
            /** @type {number} */
            c.y = b.y - c.height / 2;
          }
          if (c.y < 0) {
            /** @type {number} */
            c.y = 0;
          }
          if (c.y + c.height > cc.height) {
            /** @type {number} */
            c.y = cc.height - c.height;
          }
          if (c.x < 0) {
            /** @type {number} */
            c.x = 0;
          }
          if (c.x + c.width > cc.width) {
            /** @type {number} */
            c.x = cc.width - c.width;
          }
          /** @type {number} */
          c.x = Math.round(c.x);
          /** @type {number} */
          c.y = Math.round(c.y);
          if (s) {
            c.indicator("right", b.y - c.y);
          } else {
            c.indicator("left", b.y - c.y);
          }
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
          });
          c.display.dispatchEvent(beat);
        }
      }
      /**
       * @return {undefined}
       */
      function initialize() {
        if (bounds instanceof selection) {
          var canvas = obj.parent.getBounds();
          var o = {
            x: bounds.x,
            y: bounds.y + bounds.height / 2,
          };
          var leftRenderRect = {
            x: bounds.x + bounds.width,
            y: bounds.y + bounds.height / 2,
          };
          var rightRenderRect = {
            x: bounds.x + bounds.width / 2,
            y: bounds.y + bounds.height / 2,
          };
          var rect = bounds.topmostParent.t.localToLocal(rightRenderRect.x, rightRenderRect.y, e.topmostParent.t);

          var s = rect.x > canvas.width / 2;
          if (s) {
            rect = bounds.topmostParent.t.localToLocal(o.x, o.y, obj.topmostParent.t);

            obj.x = rect.x - obj.width - 25 - 1;

            obj.y = rect.y - obj.height / 2;
          } else {
            rect = bounds.topmostParent.t.localToLocal(leftRenderRect.x, leftRenderRect.y, obj.topmostParent.t);
            obj.x = rect.x + 25 + 1;

            obj.y = rect.y - obj.height / 2;
          }
          if (obj.y < 0) {
            obj.y = 0;
          }
          if (obj.y + obj.height > canvas.height) {
            obj.y = canvas.height - obj.height;
          }
          if (obj.x < 0) {
            obj.x = 0;
          }
          if (obj.x + obj.width > canvas.width) {
            obj.x = canvas.width - obj.width;
          }

          obj.x = Math.round(obj.x);

          obj.y = Math.round(obj.y);
          if (s) {
            obj.indicator("right", rect.y - obj.y);
          } else {
            obj.indicator("left", rect.y - obj.y);
          }
          //console.log("initialize: ", obj);//Vikas
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
          });
          obj.display.dispatchEvent(beat);
        }
      }
      /**
       * @param {number} next
       * @return {?}
       */
      function onChange(next) {
        var result = t()(req.a).call(
          req.a,
          me.entities,
          function (cind, bounds) {
            /** @type {number} */
            var i = cind;
            return bounds instanceof selection && (i = cind + 1), i;
          },
          0
        );
        return next && (result = result + next), result > data.CLOCK_LIMIT;
      }
      /**
       * @return {undefined}
       */
      function onPause() {
        //console.log("On Pause.........1427", marketID, onPause.caller, onPause.callee);
        if (marketID) {
          me.endSpotlight(marketID);
          /** @type {null} */
          marketID = null;
        }
      }
      /**
       * @param {?} message
       * @return {undefined}
       */
      function pause(message) {
        if (req.a.isString(marketID)) {
          onPause();
        }
        marketID = me.spotlight(message.targetEntity);
      }
      /**
       * @return {undefined}
       */
      function tick() {
        var item;
        var options;
        var fx;
        var deviceOrientationEvent;
        var docLoadedEvent;
        var mEvt;
        if (self.tooManyTexts(1)) {
          _this.f.dispatchEvent(_this.d.SPAWN_ITEM_FAILURE_PROMPT_EVENT);
        } else {
          options = {
            zoom: 1,
            selectedBackingColor: data.TEXT_SELECTED_BACKING_COLOR,
            incDefault: _this.n.getResult("entities", props),
            incActive: _this.n.getResult("entities", wrapper),
            decDefault: _this.n.getResult("entities", srcNodeId),
            decActive: _this.n.getResult("entities", node),
          };
          fx = curve((item = new _this.h(null, options)), true);
          /** @type {number} */
          item.x = fx.x - item.width / 2;
          /** @type {number} */
          item.y = fx.y - item.height / 2;
          self.addText(item);
          (deviceOrientationEvent = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT)).set({
            ids: [item.id],
            add: false,
          });
          _this.f.dispatchEvent(deviceOrientationEvent);
          (docLoadedEvent = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT)).set({
            skipAnimation: true,
            selectionBounds: item.getConstraintBounds(),
          });
          item.display.dispatchEvent(docLoadedEvent);
          (mEvt = new doc.a.Event(_this.d.EQUATION_TOOLS_SHOW)).set({
            targetEntity: item,
          });
          _this.f.dispatchEvent(mEvt);
          _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
        }
      }
      /**
       * @return {undefined}
       */
      function loop() {
        var item;
        var ds;
        var fx;
        var deviceOrientationEvent;
        var docLoadedEvent;
        var mEvt;
        if (self.tooManyTexts(1)) {
          _this.f.dispatchEvent(_this.d.SPAWN_ITEM_FAILURE_PROMPT_EVENT);
        } else {
          ds = {
            startingText: "",
            zoom: 1,
            selectedBackingColor: data.TEXT_SELECTED_BACKING_COLOR,
            incDefault: _this.n.getResult("entities", props),
            incActive: _this.n.getResult("entities", wrapper),
            decDefault: _this.n.getResult("entities", srcNodeId),
            decActive: _this.n.getResult("entities", node),
          };
          fx = curve((item = new _this.w(null, ds)), true);
          /** @type {number} */
          item.x = fx.x - item.width / 2;
          /** @type {number} */
          item.y = fx.y - item.height / 2;
          self.addText(item);
          (deviceOrientationEvent = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT)).set({
            ids: [item.id],
            add: false,
          });
          _this.f.dispatchEvent(deviceOrientationEvent);
          (docLoadedEvent = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT)).set({
            skipAnimation: true,
            selectionBounds: item.getConstraintBounds(),
          });
          item.display.dispatchEvent(docLoadedEvent);
          (mEvt = new doc.a.Event(_this.d.TEXT_TOOLS_SHOW)).set({
            targetEntity: item,
          });
          _this.f.dispatchEvent(mEvt);
          _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
        }
      }
      /**
       * @return {undefined}
       */
      function callback() {
        var e;
        var stream;
        var fx;
        var deviceOrientationEvent;
        if (self.tooManyShades(1)) {
          _this.f.dispatchEvent(_this.d.SPAWN_ITEM_FAILURE_PROMPT_EVENT);
        } else {
          stream = {
            closeImage:
              "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAQO0lEQVRoga1aecxtVXX/rWGfc+/9pjfzGAQfcyujQ6lzIzZEYlpiUpUmYiJpYouxjbaN8k81bTokbdq0NTUxFIuxVBMbtYpChBhBS0UU9NW+8OAhyvB8A7xvuveePazVP84535u+74HI+uece885e//W2mutvYZNfiW2o4AwBCGDYSAYCINjfjsIFQgFDAc1BQwAUcEpQ5KBk4MAgByEEAgAcvefEhwAkJJ7dx8YFggeFKXKMACopZtNYIhwEBwMh8Iw7e4ZjoQCABC4vmDwGdIUcFRwAmRsYDQg0sATAhdtmWJWyQ7KDmrht6QE14G6WS4AIAU2JNi4SRIYpooSM6hiWA0AFQwRgAHIYAxgmHaDBQgUhgmgG4Iv4F7qTQRHa8FPIpQ08NQhRcFGqg3AxMrFQbG49KBJlADAS/ZuDVCxFiG4e7aoyEIwKbCho0w82ZCRY4JVBVYLDAJDgp3ERAZjCNOTwEfIsSrTFPAKQycFSh54ShDTIGP3YKTSuLOzSCJIASgWVwAoDiKnjgF26VSnEspC8MBVmZRSRqyFkYspZS4oiIlSQO6UBHUrcSB2IjiBCT1J8h34JkNihkQFTxI0S5AGQSfslRWRJKIrxbUxFxBrTK6FWIpDDCBiJutsgFnczZwBl4QibqViynDP40x5pq5zKkU1eJw24FkHZ09lyMgxo8wdVSk+kQldT2168KsCyQmyglCZqkRImELC0tTDhCxkcJUhITuHxC7JIGl20444mNnuONYCAAK8mq4eDKtHDgSWUjtlBaUGlsaNxdo5j1RkdqBpjMyVIyElJAUhA2tMpA5rx4SeEjxVugIP46ChFKmWMlcrsCoTV4mrelIsrM5t2jle2PGaVA0vzvXwMni70o7jqefG3SchNXtDnOwZPLf/gYXx8jPqlkdk02zcpEgyo8oDBeUIns0priqwxkQAjrUJ8lfhbBgIoWViOUF78EeiV+OgIbrU4yxhVbiORsMpuDq8sO2C8ZYzriv18HK4w+Ewd5Afhd7fUofeqXVMRNz5XIJOV++feW7/1zcvHnp0SDYdsE8H2eJsKM2AShzmHOc8JVWUGUOeUxQUlN7Fkl+Jc+AgCGQ5Q1YZeix4k7p+burVlGg4IR0+J/XmpbMvek+shq91d7gb4A63lgF4d12HiAhMBBCBub0SMYgI1WTpK5ue2vfVzRafC57Hc2bTE5kYAmlWUOoKud8n5GM7sblXnYlBokFXjKtppSFLPTg8sXqsYXbsMtp/2tmvO3LG+R8porvcHXCDFUMxg5mhWGmvpftdCtwd1j13AswNcMA7Jgmth7VqcOFkYdsVMcUnBnG6nMjBhZwZUCUnJ4cbucOFAA1wFEDX9N7AqwyJCBpVddWkXpl6NWUeTowGT59+7tXTTTveBzOYG7wDaW6wUmDdCtTDEc469/zj7KDX/327HwYTgZlBwmAzMDOYWxV0lrOWTz/3IwD++rTlQ48scgaSQCtyDXDN8FVP7R7RuuWiKOBYwKsCMQ8hqoapaTVJXK0wDRro8OD8tgsn89uu78Fb7iTthpILqsEQV/3m23Dp696IC6545brq09Peh76P3d+5F9/7xtcRJ2OwCsQd4g5TAMTDldPO+b16uvpXm9IEy1ycMkyCuhDZDJOtevSqwOsKRtMrcMFKgUyAcMRDnQeDesm4Plx41EBnnpndetFiK5VhDz6XAisFxQxv/d334m033HhK0OvReHkZd37mX3Hfl78AUYGyQJhBKmBiiJUntzy++y8358mhGeTVbRVPgjXT+ZzjLFIcAmlrhSR/ugPbpwqJFMI0aFguVC9FqqYko2dlsPXIWRf+kRFv9RPA7zhnFz74D5/EZa9/0y8MHgBCXeNXXvPrOPeSy/Gj+76FHCOICOQAmECi883c5jNnnt3/gIq4JyuVwOtAJiBnMQsGlw/vwPZo0CWTKmpVr7rUY/BwFTI6+LIL35Gr4avNDZ4LSgde6gH+5F8+jfktW18U+GNp687TcfZFv4rv3nVH55WojQKJAA07m1AdmV058hNilEBkFZOnlK028wAYJwVnCWK1yqS4jovrBFwtjhZOj6OFt5sZYI5irbfReoAP/O0/YTg7+0uD7+mCK16Jd33ooyiloHjnseBwdzQL29+9KPWm5FSPo+u4uLAEzhJkVSCcM2RaIEaqiUQyuErgamnnOe/wbqDe25RS8Nvv/yDOPO+Clwx8T1ddcy1edfU1KLm1LcsF7gYnGi6eed61EVyVIJpJdJVcJwbOGcIIFfEgcDRwNkgi1rHWc6UetRtV7y6LYdcrLsNV11z7koPv6br3fxDVYNi66W5TdHfEwexbV6VeiM51MghIlSW0+Uc256k5G4s0xGokurTznDf34YG7t9I3w3W//4enBBCXFvH5N70ae26/7aRne26/DZ9/06sRlxY3/H40N4dr3vO+YzbHdn5nHh7ZfuZrsjtP4KFx54ZdSANzdlAs0FRcGoNkc0316GL3HrzDzLHrkstx1vkbq05cWsQX3341Du1+GPfcdONxTOy5/Tbcc9ONOLT7YXzuja/Cod0PbzjOm9/xzuNswNttG2k0/8oMDgYhZuXsoImBNRuYKqVYwMIsMbmYVhcBAMzhXRhw6eve+ILA93TPTTeue7/8syfwxbdfjeu+cje2XXL5uuO94rVvwJ4H7oeRgZxbQWp1UTKXBi6RnEdBKeVMnB1UHGQOiubSVIORMw/7FXC0cct5l125IQPV/AK2XXoymHtuuvE48D3Nn/1yzJ/98g3HO/+yK+Fm7Q/rAhLmoTlESMQcbAVSDMwhBGR3MnEGgMmmbbt6/Qewdj2V+gDAWz5xCy6+/oZTvgMAu679LVz3lbtRzS9s+M4ZXSzVR7V94FcAGFphl77ikR1kABtAdkIW1ZNvEB6vxwSAdY0YAC6+/oa1d56P/ATwDoCYqS1TtBRC6HLMl5DOeMObX9SzX4QKfE3QrIS1isFGRLTuwpxEvbfZiO656Ub88JP/+EJxHjc3AXBrDULaiAkppXYFHHAyGAPOMa6gj0eAteveh77/S4Hv6b6bP/y87z36wx90MdHxTAgABpyPETqnlFAzWSAyJbLRkQM/pe4jWsthCU89tnfDCePSIu776IdO+v/i629Y17D33H4bnv72tzYc7+l9j4K7+cFHV18Ixm2t0FlQhGHHqVDxUiqCUU5PAgAzgZjBzHjsRw9tOGE1v3CSZ+kNdj3v9JZP3IIzThGGP/bwD0DCR4VIBCr5Z0JUilkJBEspIxCclWFmuQyEcs1UKqakudlDRPAuCWcm/Pj+b+Pw/mc2nHTbJZevMXGit+mZqOYX8M5vfe+U7vZ/7rwDcToB4WhoTW314geBqcxUKBWTDRimBOchwwYM85JdrRSG5cHh/ffimI+ZGEyEOz/zrxtO3DPxrnsfXNdVvuUTt+Bd9z644e7b012fvbXNk4kg3SoAwMyRQ99jLxmpFCvZpJApk7HnZDbNNuxXgKhsXjz4OJd8mIja5JsZrIIH777zeY157mXnvKhnAPC1227B4sEDYGYIc1tHIgLl9MjC0sF9Ao+BqQwDJSvJkKKzKspAUMhzHgjliqwZCMdq+dkvEfPaKgi1g9768ZsxWVk5JZAXQ3sf+j6+8e//BtE2N2ZhcFczmn12/38OhKLkkkdKyXP2YVeS50DwIcNmnHLwkmu3XMHiaU8/9k3O6ZG+BCLMEBHkZop//uMPYLy8/JKBf+qxvbj14ze3c1C74ujAc5w+tOXwU7vZUjNXU6qslBmnPBAqIcO4yjDPyawkU+Q0Ukr9Ksz+/InPkvuEqa0WiAhEBQeeeBx/ccPvPK86vRD67l134O/+4H3IzbQdvxNYm+D7ZP7pfZ+pyZqQLY2UEnnOYqlYiaVimPzZ6dgSBRREARcyAjcZlGBUNdOVSajGZTR3ZbsfAOgS7pISvnvXHTB3XHD5qWtB69F4eRn/dcsn8bVPfwoqnXBEwCqgTl1nDjz59ztWDz8yJJtsCmgGbM2ceRqx51Epeago8udnYrNn0MQLuYONQUZgyyAWpmr5yJMr81t2uoaXtVUDHHVxBDz2w4fwzS98DrObt2DLaTsR6vp5gX/nq1/CrR+/GT/58Y+gQaEi0A48dyo0eO7nt+44+NP7B8irc+bTkZQ4V6wZImVYyrOEMhIY+a9hVxOhfXFrBaFaUq1M6vrAxAZT0ZlVo+H+cy99bxrMvrVP8D0XmHtbDy22VlY897Ir1sLhE+mZfY9i93/f13kZAotAiEF9qZHaiH64ePA/du5//O4Z8ZVhStP5yqYzVJphznGGUjNjKLMBuVYU8ivw8hMr06uu1ThIGBcZHJzYIKqOJs6D/Tt3XT1Z2P5uAMO+Kt0XcvvyuhdbS4SOra+vhSfS+vh+b2FpGQAIDEzm9+/7m82Lhx6dYZ9UOY23j3giuYnDnOPmQEliTFsUua9Qy8dOxwIUqAnwAky8EBPARoDChZlyMhNhqpeP/Ay5+b80mj8fovPoYhXp3C1za3wi0kq5N/zOgzFzq+/UPiNhELc6r3H68OyBn35q+/KhvSPx1WFOky0DjlqaZpRy2lxRUo+t6igMue2hysfOxAIyCKGVFQoowyAAsRE4kAURKrEYk/soNUd48fADuapXrRqcR8wBRKAubpIudup3UyZuVUWk3VmlZYY6XWe3Z+vVxS/v+Mn/3rY1T38ekMezxaZbhhzVWvCbKorqMc8YciUwtWMbHFfhrONaTJ09rDLEKISGgi7Cj+vSJKc6Og+eHc6fNt5x1m/EevR6iG7p8+ijdHyBve/KdMHZ4TBe+sbC/ie+OVeaxQF5MyCbVtlS39ioYs5r4AtKpSi1oiDB+gY4+eU488T26rFMsFRyJHoVK9UMDVNwWG48ROZB7Kp4U3NZ2nHWK5rR/MVWDS7uG3xmbZ+VuE1ACHCO0z2jpYMPLjx38PGKKdWwxG554D6ZrykNUFJATlXMeTa0anMc+Nh18rvuPfmVOAMGgqJv9K8xEa3tG2SqdCV5sFolQsNK9pBJdFxcDRIisTbFAzNzckh2Z3OQSyf0AleCMZErUxYvRYiKkkW1UuaEkqJkQYkLoCSWysBS7vtilcDWAw+GK7hb54zSMQFEoK6QkSHIQNToADxniOVs87VmI1J1D06UohuPyVVIJMO5AEQq5N5mfBRgXooLwZkosxericqQUYisDIVyhZK4yWVWkd2SDQNyVVDmFOW4sxMnnJtQaNeyXJ+JUhO8O9zhiVJRQskFspJz2TLQNM4lzLBy3TosLg4qABXPRIquUw8XhQvgFcOMzCqm4iX7SJFsmm2kyIpUBCgzhFIZrNbuqME6ku9tQDGBY3gCE71NRABVd/gCQCzwGOA5J1fAcgZzQSHKNFDlmItmgFQVrQ10B0C0rYXknFEbTARFSjYxmGaYdoIJgM0arA7HSN3gkHVOrLSHPVwhcEyA45iYAhigIIOR2kZiXcHq7uwECGWlgiRPpIAgtRFGdqTkoNzkVvf7FWhaNVWCB4IrYJ6Sg+BKKDMVrGp9t68d8DjVcZsOPAT+/0b4+sV5Du2QAAAAAElFTkSuQmCC",
            revealImage:
              "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAAD7UlEQVRYhc1Yu27jRhQ9d7gy0sl/YAFBaitlkGJVKLDNxvoD6w9Wa0mhOjMduZYd5QtC/4HSaL2AC26TlKHrpND+gbaVwTkpaBl6cTiUXOQABizizpl7Z+Y+Ba8Etzs80kgbSrFBorZdShISiYITT256X15jX9lncdMLqgepdChsC6RWZi3BqVAi0In2MWYnA5peUK2k4ougs+vGyyAw1in9T7eDx7JrSxvg9sIrAB0IDsuuLQYj6Dd+mRuxNuDkMjhWCiMRaRjEEhBjgAlFzVY2oj4EpA5BC0A9l4GYQehPrge/2ehlZcBpN7xQClHunmQMUf7H658/2/Cd9T+8BbVvOgyS8ZOD1kM4+GriKjTA7Qe/A9LOFSD8ydD7pYhnK3cvvILAz6fmVKdomXwj14CmF1QrWiIBWrka7KH8AkVGgJhRpJV3u862j1mUwVhETvO3ZjQZDt6XU3cT//z58Pm7H5s1QLb7heAbAdrf/vDT9N+/HjZuQq1/aHpB9UBLbHyf4HSuXieEAsBcoUNwapJRCpHbC843vi//WJw8TFECgBCdIucqg4dw8FVocSAi49NueLHyafGP1ZvPkEyuve9NAm4vOCdWFRJgNBkO/jCu64d/o+DwQMwAthdcLzdgqTwARkYleuEVRMYi0lj+g8j4OQnuzA0AWQKV6OQyOH4xwO2FV3bKA4RKcpXvDo+MEUXgu93h0S7cazyHysG46QVVdXIZHBs3XYMpWVHSwndskrFNhAAgkNpBKh2lFEa2i4pB8/u1lrFGRxXUNv9vCA5V5tX2aHpB1cBo8YbzZczcmyA4Vdom/i6holXuExA6hc/RJGPi3gadoqXub7w70t4PBDp3k8lN74vWaG+9VWKmNdqmWt/EvUFHjD7dDh4VAHwceu8BWIWw9QS1jvsb7y7VbACMSMYkY4BRqtm4v/Hu9uFeQvLk0AeWMnEWw9PEptPSGu0iZcqiqOd4ATFLNRuLEnulnD65DI4dp9gRCU6fFOqvVQ9lZQwSm8HA+uGtFHOfbgePIAszskBqFS1RaU1zkJUxUiuWZGf95rc2NG4vOIfI2IIwmqvdK9OsdMfI2PEtdiJGz766gtyO7OQyOHaUxBY+kcwVG2WNWPQdKKo+Yfa5jYZmgew5OXUUR6d6RSNx+8G7IkUWcPvBu4pGApvSmWyZAobVVOKsF/5qNcQiZgQiAeNtYxVCGgK0bSIdyVj4xpg3gBJzobP+h7cCjmBx5fuA4FSA0avOhZZx2g0vRNEvOwstxPNAa64QlfGnnYe7bi84p0jbthHKA4ExNca7Jsa9ptMLZD2wNADWi8rzrLSQRMB47iDeNxn+B703ztcjT6uLAAAAAElFTkSuQmCC",
            concealImage:
              "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAgCAYAAABU1PscAAADsElEQVRYhb1YzU4aURT+zgXbtDGRPoG+ASTuDMi8gbyBuBGJi+LKKCHFNGDcTReN4KbTN6BvMEDTncn0DegbYEJXOvd0MYAD83PvKPRbkDBz7znfuXPu+QPWhN3j8618pZF9yd5C9aKou5deoiCgsFI/EMQlMHIgysUuZnYAjFhQT0rh/Ox+/j17tV+tH5KECULGW8q1Qbf9ZS0G7J3WtzdcboKpNFP4EkhGadht/div1g+JYS28ZIz73daHuP3ppAp3j8+3NkXKhIsyQK/6hkwoDzsR5AHoHEwiA+afGArBzA6IxkvPMovuxdbgtv09kjwAZpgqTlrnt3t8vrVJKQtEpZhltmSYw27rR5yc95Q2iDg36LSv4sgDbPU77SMVN6UBU1+3AdoJ14OxFLI0vL3uq2T5sQrygMKAQvWiKFjYkQuYnQm7xv3dzYOOshl0yE+/us0ge9BtnUXJijSgUKkfCMCKvEiMsQth+MPgqsk/3xm2JtKthR1UqAHxSjxIksY63CZfaWRT5PYCLhvxtcWymEL1oqgiD7C1NvKQduh9I8ptUiqwf8GAfKWRjfV5AGCMJ9KtabGeQtdtUpB2bOwnKhVPLr/5H80NeLZeAeJekkurG208mTxSS6Sy3wgBePE5RW5PJ/NJpp4OcSB5qGRBysTlgcr7lcuPwDQTe75FOzpb3TQcnXUvifNSCidFUkc8iMgsVC8c0ok4fvQ7LWXye02SKp7UWZcLAFtMa5uVYVUZVhOGeE0pvIz/TB6Ad4ntJBuiOiWFK9o65PdO69tJuDDDFBP5VNILXx6EkIGOK5Y8s+PpUCP1hPhublHwaNBtnYn7u5sHSVzW3UbMhv+/knyCYo8AQ7loihlnAQDD2+s+M2tmVyrvHp9vAaslDwAElHXWMbg5K2XmmdhrnjmczOJ26/7u5mHV5PdPLj9pBhR70Glfzf4s1EL9TvtoOjWIgBdJVk0+X2lkiUntASH3KVCNTtg1wo1YD3mviHOj+465bIwf01RSltP3dzcPQSPWd/KLjUsUeXYe08j9+tr6s/wqtiyYVX3rIq8snzVka00ldMgDwNuNdCbslILE3aZiwjEVDTOuHwY0DIht7H3k567AGDNggXhpLkQZAhtKd/EWjyRxWafrUw62BItmHPl39GZnoYclZAioBc6G5j8xvDFmcPMvu5auO+pM5oygIh95r4d9ZUHII89d4ge5YVAawAyTCDXfg/mlylcaYGIzmXs8y2GQLSGspKMZP/4B6HCJVL8oVrYAAAAASUVORK5CYII=",
            cornerResizeImage: _this.n.getResult("entities", linkCont),
            fillImage: _this.n.getResult("entities", fakeSrc),
          };
          (fx = curve((e = new _this.t(null, stream)), true)).x += 24 * Math.random() - 12;
          fx.y += 24 * Math.random() - 12;
          /** @type {number} */
          e.x = fx.x - e.width / 2;
          /** @type {number} */
          e.y = fx.y - e.height / 2;
          self.addShade(e);
          (deviceOrientationEvent = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT)).set({
            skipAnimation: true,
            selectionBounds: e.getConstraintBounds(),
          });
          e.display.dispatchEvent(deviceOrientationEvent);
          _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          _this.u.canvas.focus();
        }
      }
      /**
       * @param {?} _clr_hex
       * @return {undefined}
       */
      function setColor(_clr_hex) {
        //console.log("SET COLOR........");
        var target;
        var body;
        var deviceOrientationEvent;
        var docLoadedEvent;
        if (onChange(1)) {
          _this.f.dispatchEvent(new doc.a.Event(_this.d.SPAWN_ITEM_FAILURE_PROMPT_EVENT));
        } else {
          target = new selection(null, {
            position: {
              x: me.width / 2 + 50 * me.entities.length - 188,
              y: me.height / 3 + 50 * me.entities.length - 188,
            },
            gearedHands: _clr_hex.gearedClock,
            initialTime: _clr_hex.initialTime,
            readoutDisplayMode: DirSearchPathEntry.ReadoutModes.hr12,
            digitalReadoutMode: _clr_hex.digitalReadoutMode,
            runJumpMode: _clr_hex.runJumpMode,
            elapsedTimeMode: _clr_hex.elapsedTimeMode,
            tellTimeMode: _clr_hex.tellTimeMode,
            fractionMode: _clr_hex.fractionMode,
            fractionFillMode: _clr_hex.fractionFillMode,
            minuteHandOn: _clr_hex.minuteHandOn,
            hourHandOn: _clr_hex.hourHandOn,
            initialFillColor: Array.FragmentColors[args.State.activeColor],
          });
          me.addToWorkspace(target);
          _this.f.dispatchEvent(data.Events.NEW_CLOCK_base_CLOSE);
          _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
          body = {
            ids: [target.id],
          };
          (deviceOrientationEvent = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT)).set(body);
          _this.f.dispatchEvent(deviceOrientationEvent);
          if (_clr_hex.fractionMode) {
            (docLoadedEvent = new doc.a.Event(data.Events.FRACTION_PICK_PALETTE_SHOW)).set({
              targetEntity: target,
            });
            _this.f.dispatchEvent(docLoadedEvent);
          } else {
            _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
          }
        }
      }
      /**
       * @return {undefined}
       */
      function onLoadGlyphSet() {
        var beat = new doc.a.Event(data.Events.SPAWN_CLOCK_REQUEST);
        beat.set({
          gearedClock: true,
        });
        _this.f.dispatchEvent(beat);
      }
      /**
       * @return {undefined}
       */
      function userPointsUpdate() {
        var beat = new doc.a.Event(data.Events.SPAWN_CLOCK_REQUEST);
        beat.set({
          gearedClock: false,
        });
        _this.f.dispatchEvent(beat);
      }
      /**
       * @return {undefined}
       */
      function rubricAdvance() {
        console.log("rubricAdvance: EVENT: SPAWN_FRACTION_CLOCK_REQUEST");
        var beat = new doc.a.Event(data.Events.SPAWN_CLOCK_REQUEST);
        beat.set({
          gearedClock: true,
          fractionMode: true,
          fractionFillMode: koyomi.isOpen,
          minuteHandOn: false,
          hourHandOn: false,
        });
        _this.f.dispatchEvent(beat);
      }
      /**
       * @param {?} numSamps
       * @param {string} start
       * @return {?}
       */
      function curve(numSamps, start) {
        var parent;
        var obj = {
          x: data.WORKSPACE_WIDTH / 2,
          y: data.WORKSPACE_HEIGHT / 3,
        };
        return (
          (parent = start
            ? (function () {
                var z;
                var pt = me.interactionState.currentPosition;
                if (pt) {
                  if ((z = me.workspace.globalToLocal(pt.x, pt.y)).x < 0) {
                    /** @type {number} */
                    z.x = 0;
                  }
                  if (z.y < 0) {
                    /** @type {number} */
                    z.y = 0;
                  }
                } else {
                  /** @type {null} */
                  z = null;
                }
                return z;
              })()
            : null) || (parent = obj),
          parent
        );
      }
      /**
       * @return {undefined}
       */
      function onRefreshRateChanged() {
        if (
          !match()(req.a).call(req.a, me.entities, function (child) {
            if (child.selected && child.fractionControl) {
              return child.fractionControl.getFragmentCount() > 0;
            }
          })
        ) {
          _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
        }
      }
      /**
       * @return {undefined}
       */
      function flush() {
        //console.log("Flush: EVENT: TOGGLE_DIGITAL_READOUT_MODE");
        var beat = new doc.a.Event(data.Events.TOGGLE_SELECTION_DIGITAL_READOUT_MODE);
        /** @type {!Array} */
        var t = [];
        var selected = me.getSelection(selection);
        var event = require()(req.a).call(req.a, selected, function (canCreateDiscussions) {
          return canCreateDiscussions.isGeared();
        });
        /** @type {boolean} */
        var a = !i()(req.a).call(req.a, event, function (canCreateDiscussions) {
          return canCreateDiscussions.digitalReadoutMode;
        });
        req.a.each(event, function (e) {
          t.push(e.id);
        });
        beat.set({
          id: t,
          setTo: a,
        });
        _this.f.dispatchEvent(beat);
      }

      function tellTimeHandler() {
        //console.log("tellTimeHandler: EVENT: TOGGLE_TELL_TIME_MODE");//Vikas
        var ct = document.getElementById("tell-time-mode");
        var tt = document.getElementById("run-jump-mode");  
        if(tt.getAttribute("data-on")=="yes"){
          ct.setAttribute("data-on", "no");
          tt.click();
          tt.setAttribute("data-on", "no");
        }
        if(ct.classList.contains("on")){
          ct.setAttribute("data-on", "yes");
        }else{
          ct.setAttribute("data-on", "no");
        }
        var beat = new doc.a.Event(data.Events.TOGGLE_SELECTION_TELL_TIME_MODE);
        /** @type {!Array} */
        var t = [];
        var selected = me.getSelection(selection);
        var event = require()(req.a).call(req.a, selected, function (canCreateDiscussions) {
          return canCreateDiscussions.isGeared();
        });
        /** @type {boolean} */
        var a = !i()(req.a).call(req.a, event, function (canCreateDiscussions) {
          return canCreateDiscussions.tellTimeMode;
        });
        req.a.each(event, function (e) {
          t.push(e.id);
        });
        beat.set({
          id: t,
          setTo: a,
        });
        _this.f.dispatchEvent(beat);
      }
      /**
       * @return {undefined}
       */
      function decode() {
        //console.log("decode: EVENT: TOGGLE_RUN_JUMP_MODE");
        var tt = document.getElementById("tell-time-mode");
        var ct = document.getElementById("run-jump-mode");  
        if(tt.getAttribute("data-on")=="yes"){
          ct.setAttribute("data-on", "no");
          tt.click();
          tt.setAttribute("data-on", "no");
        }
        if(ct.classList.contains("on")){
          ct.setAttribute("data-on", "yes");
        }else{
          ct.setAttribute("data-on", "no");
        }
        var beat = new doc.a.Event(data.Events.TOGGLE_SELECTION_RUN_JUMP_MODE);
        /** @type {!Array} */
        var t = [];
        var selected = me.getSelection(selection);
        var event = require()(req.a).call(req.a, selected, function (canCreateDiscussions) {
          return canCreateDiscussions.isGeared();
        });
        /** @type {boolean} */
        var a = !i()(req.a).call(req.a, event, function (canCreateDiscussions) {
          return canCreateDiscussions.runJumpMode;
        });
        req.a.each(event, function (e) {
          t.push(e.id);
        });
        beat.set({
          id: t,
          setTo: a,
        });
        _this.f.dispatchEvent(beat);
      }
      /**
       * @return {undefined}
       */
      function _init() {
        //console.log("_init: EVENT: TOGGLE_ELAPSED_TIME_MODE");
        var beat = new doc.a.Event(data.Events.TOGGLE_SELECTION_ELAPSED_TIME_MODE);
        /** @type {!Array} */
        var t = [];
        var selected = me.getSelection(selection);
        var event = require()(req.a).call(req.a, selected, function (canCreateDiscussions) {
          return canCreateDiscussions.isGeared();
        });
        /** @type {boolean} */
        var a = !i()(req.a).call(req.a, event, function (canCreateDiscussions) {
          return canCreateDiscussions.elapsedTimeMode;
        });
        req.a.each(event, function (e) {
          t.push(e.id);
        });
        beat.set({
          id: t,
          setTo: a,
        });
        _this.f.dispatchEvent(beat);
      }

      /**
       * @param {string} name
       * @param {!Function} x
       * @param {?} alpha
       * @return {undefined}
       */
      function add(name, x, alpha) {
        var result = req.a.defaults(alpha, {});
        var o = (function (event, handler, name) {
          var sheet = {
            attached: false,
          };
          if (!name) {
            /** @type {string} */
            name = info.DEFAULT;
          }
          return (
            (sheet.attach = function () {
              if (!sheet.attached) {
                Object(global.a)(event, name, handler);
                /** @type {boolean} */
                sheet.attached = true;
              }
            }),
            (sheet.detach = function () {
              if (sheet.attached) {
                global.a.unbind(event, name, handler);
                /** @type {boolean} */
                sheet.attached = false;
              }
            }),
            sheet
          );
        })(name, x, result.scope);
        var elements = result.enableEvent;
        var data = result.disableEvent;
        if (!(req.a.isBoolean(result.disabled) && result.disabled)) {
          o.attach();
        }
        if (!req.a.isUndefined(elements)) {
          if (elements && !req.a.isArray(elements)) {
            /** @type {!Array} */
            elements = [elements];
          }
          req.a.each(elements, function (s) {
            if (req.a.isString(s)) {
              _this.f.on(s, o.attach);
            } else {
              _this.f.on(s.event, function (value) {
                if (s.condition(value)) {
                  o.attach();
                }
              });
            }
          });
        }
        if (!req.a.isUndefined(data)) {
          if (data && !req.a.isArray(data)) {
            /** @type {!Array} */
            data = [data];
          }
          req.a.each(data, function (s) {
            if (req.a.isString(s)) {
              _this.f.on(s, o.detach);
            } else {
              _this.f.on(s.event, function (value) {
                if (s.condition(value)) {
                  o.detach();
                }
              });
            }
          });
        }
      }
      /**
       * @param {string} name
       * @return {?}
       */
      function run(name) {
        return function () {
          var mEvt = new doc.a.Event(name);
          _this.f.dispatchEvent(mEvt);
        };
      }
      /**
       * @param {string} v
       * @param {!Object} x
       * @param {string} n
       * @param {string} i
       * @return {undefined}
       */
      function log(v, x, n, i) {
        /** @type {string} */
        var s = v;
        /** @type {!Object} */
        var element = x;
        /** @type {string} */
        var target = n;
        /** @type {string} */
        var r = i;
        if (req.a.isUndefined(i)) {
          /** @type {string} */
          target = info.DEFAULT;
          /** @type {string} */
          r = n;
        }
        if (req.a.isString(element)) {
          /** @type {!Array} */
          element = [element];
        }
        if (req.a.isString(r)) {
          /** @type {!Array} */
          r = [r];
        }
        cb()(element).call(element, function (mmCoreEventSessionExpired) {
          _this.f.on(mmCoreEventSessionExpired, function () {
            $scope.setScope(s);
          });
        });
        cb()(r).call(r, function (mmCoreEventSessionExpired) {
          _this.f.on(mmCoreEventSessionExpired, function () {
            $scope.setScope(target);
          });
        });
      }
      /**
       * @param {!Object} a
       * @return {?}
       */
      function fn(a) {
        var data = root.getEntities();
        return data
          ? require()(data).call(data, function (t) {
              var x;
              /** @type {boolean} */
              var neg = t instanceof selection;
              var b = t.selected;
              var p1 = a ? trigger()((x = a.ids)).call(x, t.id) : b;
              var p2 = !!a && a.add;
              return neg && ((b && (p1 || p2)) || (!b && p1));
            })
          : [];
      }
      /**
       * @param {!Object} args
       * @return {?}
       */
      function call(args) {
        var url = fn(args);
        return match()(url).call(url, function (canCreateDiscussions) {
          return (
            canCreateDiscussions.fractionControl.getFragmentCount() > 0 &&
            canCreateDiscussions.activeMajorControl === selection.MajorControls.FractionControl
          );
        });
      }
      /**
       * @param {!Object} blob
       * @return {?}
       */
      function read(blob) {
        var url = fn();
        return match()(url).call(url, function () {
          return blob.value > 0;
        });
      }
      /**
       * @return {undefined}
       */
      function testAppearance() {
        /** @type {string} */
        document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).value = "";
        rule = {};
        __WEBPACK_IMPORTED_MODULE_2_date_fns_difference_in_days___default()(function () {
          document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).focus();
        }, 0);
      }
      /**
       * @return {undefined}
       */
      function clear() {
        /** @type {string} */
        document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).value = "";
        document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).removeAttribute("aria-invalid");
        document.querySelector(data.ACTIVITY_CODE_SUBMIT_BOX_SELECTOR).classList.remove("show-error");
      }
      /**
       * @return {undefined}
       */
      function init() {
        var req = new doc.a.Event(_this.d.LOAD_ACTIVITY_CODE_EVENT);
        var input = find(document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).value);
        input = input.toLowerCase().replace(/o/g, "0").replace(/i/g, "1");
        _.fetch(input).then(
          function (nextResponse) {
            req.set({
              response: nextResponse,
              saveId: input,
            });
            _this.f.dispatchEvent(req);
          },
          function () {
            document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).setAttribute("aria-invalid", "true");
            document.querySelector(data.ACTIVITY_CODE_SUBMIT_BOX_SELECTOR).classList.add("show-error");
            document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).select();
          }
        );
      }
      /**
       * @return {undefined}
       */
      function refresh() {
        document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).removeAttribute("aria-invalid");
        document.querySelector(data.ACTIVITY_CODE_SUBMIT_BOX_SELECTOR).classList.remove("show-error");
        (function () {
          var SOFT_TAB_LENGTH;
          var ret;
          var val;
          /** @type {(Element|null)} */
          var textarea = document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR);
          var value = textarea.value;
          var caret = textarea.selectionStart;
          var selectionEnd = textarea.selectionEnd;
          var i = value.length;
          /** @type {boolean} */
          var c = false;
          if (req.a.isString(rule.value)) {
            /** @type {boolean} */
            c = "-" === rule.value.substr(4, 1) && 4 === caret && 4 === value.length;
          }
          if (c) {
            value = write()(value).call(value, 0, 3);
          }
          ret = find(value);
          val = (function (value) {
            /** @type {string} */
            var output = "";
            output = value.length >= 4 ? write()(value).call(value, 0, 4) + "-" + write()(value).call(value, 4, 8) : value;
            return (output = output.toUpperCase());
          })(ret);
          if (8 === ret.length) {
            Radiocheck.codeOpen.enable();
          } else {
            Radiocheck.codeOpen.disable();
          }
          /** @type {number} */
          SOFT_TAB_LENGTH = val.length - i;
          textarea.value = val;
          textarea.setSelectionRange(caret + SOFT_TAB_LENGTH, selectionEnd + SOFT_TAB_LENGTH);
          rule = {
            value: textarea.value,
            selectionStart: textarea.selectionStart,
            selectionEnd: textarea.selectionEnd,
          };
        })();
      }
      /**
       * @param {string} p1
       * @return {?}
       */
      function find(p1) {
        var t;
        return write()((t = p1.replace(/[^a-z0-9]/gi, ""))).call(t, 0, 8);
      }
      /**
       * @param {?} event
       * @return {undefined}
       */
      function onSuccess(event) {
        /** @type {(Element|null)} */
        var t = document.querySelector(data.SHARE_POPUP_URL_INPUT_SELECTOR);
        t.setAttribute("value", event.stateLink);
        t.select();
        document.querySelector(data.SHARE_POPUP_CODE_INPUT_SELECTOR).setAttribute("value", event.formattedSaveStateId);
        document.querySelector(data.ACTIVITY_CODE_DISPLAY_SELECTOR).textContent = event.formattedSaveStateId;
        authReqCmd.saveLinkCopy.enable();
        authReqCmd.saveLinkDisplay.enable();
      }
      /**
       * @return {undefined}
       */
      function Menu() {
        console.log("show popup ...");
        if (document.querySelector("#save-popup").classList.contains("open")) {
          _this.f.dispatchEvent(_this.d.SAVE_POPUP_HIDE_EVENT);
        } else {
          _this.f.dispatchEvent(_this.d.SAVE_POPUP_SHOW_EVENT);
        }
      }
      /**
       * @return {undefined}
       */
      function _getCroppedText() {
        /** @type {(Element|null)} */
        var transporterInput = document.querySelector(data.SHARE_POPUP_URL_INPUT_SELECTOR);
        /** @type {(Element|null)} */
        var oldpwbox = document.querySelector(data.SHARE_POPUP_CODE_INPUT_SELECTOR);
        /** @type {(Element|null)} */
        var xorEl = document.querySelector(data.ACTIVITY_CODE_DISPLAY_SELECTOR);
        transporterInput.setAttribute("value", "Saving...");
        oldpwbox.setAttribute("value", "");
        /** @type {string} */
        xorEl.textContent = "";
        authReqCmd.saveLinkCopy.disable();
        authReqCmd.saveLinkDisplay.disable();
      }
      /**
       * @return {undefined}
       */
      function request() {
        if (navigator.onLine) {
          _this.f.dispatchEvent(_this.d.SAVE_STATE);
        } else {
          document.querySelector(data.SHARE_POPUP_URL_INPUT_SELECTOR).setAttribute("value", "No internet connection");
          document.querySelector(data.SHARE_POPUP_CODE_INPUT_SELECTOR).setAttribute("value", "No internet connection");
        }
      }
      /**
       * @return {undefined}
       */
      function download() {
        var dataUrl = root.getPageDataURL();
        var blob = Data.dataURLToBlob(dataUrl);
        /** @type {(Element|null)} */
        var el = document.querySelector(data.SAVE_IMAGE_DOWNLOAD_HELPER);
        if (Data.checkDownloadSupport()) {
          el.setAttribute("href", dataUrl);
          el.setAttribute("download", "clock-app");
          el.click();
        } else {
          if (Data.checkSaveBlobSupport()) {
            navigator.msSaveBlob(blob, "clock-app.png");
          } else {
            var styleElId = dataUrl.replace("data:image/png", "data:attachment/file");
            el.setAttribute("href", styleElId);
            el.setAttribute("target", "_blank");
            el.click();
          }
        }
      }
      /**
       * @return {undefined}
       */
      function done() {
        var url;
        if (Data.isCPA() && Data.isChromeOS()) {
          var placeMidpointLine;
          url = root.getPageDataURL();
          chrome.runtime.sendMessage(
            {
              dataUrl: url,
              imageType: chrome.clipboard.ImageType.PNG,
            },
            function () {
              if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError.message);
              }
            }
          );
          /** @type {(Element|null)} */
          var row = document.querySelector("#copy-container #image-copy-feedback");
          /** @type {!Array} */
          var range = [];
          row.classList.add("input-feedback-pulse");
          cb()((placeMidpointLine = ["animationend", "webkitAnimationEnd", "oAnimationEnd", "MSAnimationEnd"])).call(
            placeMidpointLine,
            function (type) {
              var t = row.addEventListener(type, function () {
                row.classList.remove("input-feedback-pulse");
                cb()(range).call(range, function (increment) {
                  row.removeEventListener(type, increment);
                });
              });
              range.push(t);
            }
          );
        } else {
          if (!Data.isCPA()) {
            var o = oMultiSelect.$element[0].querySelector(".copy-image-source");
            url = root.getPageDataURL();
            o.setAttribute("src", "");
            if (url) {
              o.setAttribute("src", url);
            }
            _this.f.dispatchEvent(_this.d.COPY_IMAGE_OPEN_EVENT);
          }
        }
      }
      /**
       * @return {undefined}
       */
      function notify() {
        if ((document.querySelector(data.SHARE_POPUP_URL_INPUT_SELECTOR).select(), document.execCommand("copy"))) {
          var placeMidpointLine;
          /** @type {(Element|null)} */
          var t = document.querySelector("#save-popup #copy-feedback");
          t.classList.add("input-feedback-pulse");
          cb()((placeMidpointLine = ["animationend", "webkitAnimationEnd", "oAnimationEnd", "MSAnimationEnd"])).call(placeMidpointLine, function (e) {
            t.addEventListener(e, function () {
              t.classList.remove("input-feedback-pulse");
            });
          });
        }
      }
      /**
       * @param {!Object} e
       * @return {?}
       */
      function resolve(e) {
        var data = root.getEntities();
        return data
          ? require()(data).call(data, function (t) {
              var _ref;
              /** @type {boolean} */
              var neg = t instanceof selection;
              var b = t.selected;
              var p1 = e ? trigger()((_ref = e.ids)).call(_ref, t.id) : b;
              var p2 = !!e && e.add;
              return neg && ((b && (p1 || p2)) || (!b && p1));
            })
          : [];
      }
      /**
       * @param {!Object} options
       * @return {?}
       */
      function search(options) {
        var imageryProvider;
        var context = require()((imageryProvider = root.getEntities())).call(imageryProvider, function (bounds) {
          return bounds instanceof selection;
        });
        return context
          ? require()(context).call(context, function (_this) {
              /** @type {boolean} */
              var relation = true;
              return (
                "minute" === options.hand
                  ? (relation = (relation = req.a.isBoolean(options.setTo) ? options.setTo : !_this.minuteHandOn) && _this.hourHandOn)
                  : "hour" === options.hand &&
                    (relation = (relation = req.a.isBoolean(options.setTo) ? options.setTo : !_this.hourHandOn) && _this.minuteHandOn),
                _this.gearedHands && relation
              );
            })
          : [];
      }
      /**
       * @param {!Object} id
       * @return {?}
       */
      function getType(id) {
        var url = resolve(id);
        return match()(url).call(url, function (canCreateDiscussions) {
          return (
            canCreateDiscussions.fractionControl.getFragmentCount() > 0 &&
            canCreateDiscussions.activeMajorControl === selection.MajorControls.FractionControl
          );
        });
      }
      /**
       * @param {!Object} retry
       * @return {?}
       */
      function next(retry) {
        var url = resolve();
        return match()(url).call(url, function () {
          return retry.value > 0;
        });
      }
      /**
       * @return {undefined}
       */
      function get() {
        _this.u.canvas.removeAttribute("height");
        _this.u.canvas.removeAttribute("width");
        _this.u.canvas.width = _this.u.canvas.offsetWidth;
        _this.u.canvas.height = _this.u.canvas.offsetHeight;
        _this.u.setBounds(0, 0, _this.u.canvas.width, _this.u.canvas.height);
        _this.f.dispatchEvent(new doc.a.Event(_this.d.STAGE_UPDATE));
      }
      /**
       * @return {undefined}
       */
      function animate() {
        var data = {
          width: _this.u.canvas.width,
          height: _this.u.canvas.height,
        };
        if (view) {
          view.setBounds(0, 0, _this.u.canvas.width, _this.u.canvas.height);
        }
        root.resizePage(data);
      }
      /**
       * @return {undefined}
       */
      function submitForm() {
        if (_this.u.updateNeeded) {
          _this.u.update();
          /** @type {boolean} */
          _this.u.updateNeeded = false;
        }
      }
      /**
       * @return {undefined}
       */
      function replicantDeclared() {
        if (!ret.anyActive()) {
          if (root.hasConfig()) {
            _this.f.dispatchEvent(_this.d.START_OVER_SAVESTATE_PROMPT_EVENT);
          } else {
            _this.f.dispatchEvent(_this.d.START_OVER_ALL_PROMPT_EVENT);
          }
        }
      }
      /**
       * @param {boolean} endStatus
       * @return {undefined}
       */
      function update(endStatus) {
        if (
          (animate(),
          _this.f.dispatchEvent(_this.d.DRAW_TOOLS_HIDE_EVENT),
          _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE),
          _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE),
          _this.f.dispatchEvent(_this.d.STAGE_UPDATE),
          endStatus) &&
          root.getConfig().appState.booleanFlags.drawToolsActive
        ) {
          var beat = new doc.a.Event(_this.d.DRAW_TOOLS_SHOW_EVENT);
          beat.set({
            newMode: _this.g.DrawMode.NONE,
          });
          _this.f.dispatchEvent(beat);
        }
      }
      /**
       * @return {undefined}
       */
      function remove() {
        var query = req.a.where(root.getAllEntities(), {
          selected: true,
        });
        var t = root.tooManyTexts(query.length);
        var types = root.tooManyEntities(query.length);
        /** @type {!Array} */
        var groups = [];
        if (t || types) {
          _this.f.dispatchEvent(_this.d.DUPLICATE_ITEM_FAILURE_PROMPT_EVENT);
        } else {
          req.a.each(query, function (e) {
            if (req.a.isFunction(e.clone)) {
              var el = e.clone();
              el.x += data.CellDimensions.WIDTH;
              el.y += data.CellDimensions.HEIGHT;
              root.addDefault(el);
              groups.push(el);
            }
          });
          req.a.each(query, function (cbCollection) {
            /** @type {boolean} */
            cbCollection.selected = false;
          });
          req.a.each(groups, function (cbCollection) {
            /** @type {boolean} */
            cbCollection.selected = true;
          });
          var ids = req.a.pluck(groups, "id");
          var self = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT);
          self.set({
            ids: ids,
            add: false,
          });
          _this.f.dispatchEvent(self);
          _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
          _this.f.dispatchEvent(new doc.a.Event(_this.d.STAGE_UPDATE));
        }
      }
      /**
       * @return {undefined}
       */
      function Matrix2D() {
        if (
          req.a.where(root.getAllEntities(), {
            selected: true,
          }).length > 1
        ) {
          _this.f.dispatchEvent(_this.d.DELETE_SELECTION_PROMPT_EVENT);
        } else {
          _this.f.dispatchEvent(_this.d.DELETE_SELECTION_EVENT);
        }
      }
      /**
       * @return {undefined}
       */
      function onMasterMessage() {
        var data = {
          appState: {
            booleanFlags: {
              drawToolsActive: ctx.isDrawToolsVisible(),
            },
            customObjects: [],
          },
          workspaces: [root.getSaveData()],
        };
        _.send(data);
      }
      /**
       * @param {!Object} opt
       * @return {undefined}
       */
      function render(opt) {
        if (opt.saveId) {
          if (
            (document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).removeAttribute("aria-invalid"),
            document.querySelector(data.ACTIVITY_CODE_SUBMIT_BOX_SELECTOR).classList.remove("show-error"),
            Data.isCPA())
          ) {
            var state = opt.response[_.SAVE_KEY];
            if (state.appState.booleanFlags.drawToolsActive) {
              var beat = new doc.a.Event(_this.d.DRAW_TOOLS_SHOW_EVENT);
              beat.set({
                newMode: _this.g.DrawMode.NONE,
              });
              _this.f.dispatchEvent(beat);
            }
            root.loadState(state);
            get();
            animate();
            _this.f.dispatchEvent(_this.d.ACTIVITY_CODE_CLOSE_EVENT);
          } else {
            /** @type {string} */
            window.location.href = window.location.origin + window.location.pathname + "?" + opt.saveId;
          }
        }
      }
      $.r(d);
      var node1 = $("bZW+");
      var doc = $.n(node1);
      var avatarSrc = ($("6QhM"), $("CZX6"), $("RjO5"), $("XVer"));
      var schema = $("L6fE");
      var __WEBPACK_IMPORTED_MODULE_20_date_fns_min__ = $("OBge");
      var __WEBPACK_IMPORTED_MODULE_20_date_fns_min___default = $.n(__WEBPACK_IMPORTED_MODULE_20_date_fns_min__);
      var opts = $("F/us");
      var req = $.n(opts);
      var link = $("EVdn");
      var debug = $.n(link);
      var _this = $("tRS1");
      var path = $("xS4f");
      var match = $.n(path);
      var v = new _this.a({
        id: "offline-msgBox",
        openEvent: _this.d.ACTIVITY_CODE_OFFLINE_EVENT,
        message: "Sorry, entering a code requires internet connection.",
        buttons: [
          {
            label: "Okay",
            default: true,
          },
        ],
        appendTo: "body",
      });
      var that = {};
      var data = that;
      /** @type {string} */
      that.CACHEBUST_BASEPATH = "";
      /** @type {string} */
      that.IS_CPA = "@@isCPA";
      /** @type {string} */
      that.TOOLBAR_SELECTOR = "#toolbar";
      /** @type {string} */
      that.DUPLICATE_SELECTOR = "#duplicate";
      /** @type {string} */
      that.DELETE_SELECTOR = "#trash";
      /** @type {string} */
      that.DRAW_TOOLS_SELECTOR = "#draw";
      /** @type {string} */
      that.EQUATION_TOOLS_SELECTOR = "#equation";
      /** @type {string} */
      that.INFO_SELECTOR = "#info";
      /** @type {string} */
      that.SHADE_SELECTOR = "#shade";
      /** @type {string} */
      that.START_OVER_SELECTOR = "#restart";
      /** @type {string} */
      that.TEXT_TOOLS_SELECTOR = "#text";
      /** @type {string} */
      that.ADD_CLOCK_SELECTOR = "#new-clock";
      /** @type {string} */
      that.EDIT_CLOCK_SELECTOR = "#edit-clock";
      /** @type {string} */
      that.TOGGLE_DIGITAL_READOUT_SELECTOR = "#digital-mode";
      /** @type {string} */
      that.TOGGLE_RUN_JUMP_SELECTOR = "#run-jump-mode";
      /** @type {string} */
      that.TOGGLE_ELAPSED_TIME_SELECTOR = "#elapsed-time-mode";
      /** @type {string} */
      that.TOGGLE_TELL_TIME_SELECTOR = "#tell-time-mode";
      /** @type {string} */
      that.TOGGLE_TELL_ANGLE_SELECTOR = "#tell-angle-mode";
      /** @type {string} */
      that.TOGGLE_FRACTION_SELECTOR = "#fractions-mode";
      /** @type {string} */
      that.FRACTION_FILL_SELECTOR = "#fill-mode";
      /** @type {string} */
      that.ADD_GEARED_CLOCK_SELECTOR = "#add-geared-clock";
      /** @type {string} */
      that.ADD_UNGEARED_CLOCK_SELECTOR = "#add-ungeared-clock";
      /** @type {string} */
      that.ADD_FRACTION_CLOCK_SELECTOR = "#add-fraction-clock";
      /** @type {string} */
      that.FRACTION_FILL_PALETTE_SELECTOR = ".fraction-fill-palette";
      /** @type {string} */
      that.FRACTION_FILL_RED_SELECTOR = "#fraction-fill-red";
      /** @type {string} */
      that.FRACTION_FILL_ORANGE_SELECTOR = "#fraction-fill-orange";
      /** @type {string} */
      that.FRACTION_FILL_YELLOW_SELECTOR = "#fraction-fill-yellow";
      /** @type {string} */
      that.FRACTION_FILL_GREEN_SELECTOR = "#fraction-fill-green";
      /** @type {string} */
      that.FRACTION_FILL_BLUE_SELECTOR = "#fraction-fill-blue";
      /** @type {string} */
      that.FRACTION_FILL_PURPLE_SELECTOR = "#fraction-fill-purple";
      /** @type {string} */
      that.SAVE_LINK_URL_SELECTOR = "#link-url";
      /** @type {string} */
      that.SAVE_LINK_COPY_SELECTOR = "#link-copy";
      /** @type {string} */
      that.SAVE_LINK_DISPLAY_SELECTOR = "#link-display";
      /** @type {string} */
      that.SAVE_IMAGE_DOWNLOAD_SELECTOR = "#download-work";
      /** @type {string} */
      that.SAVE_IMAGE_DOWNLOAD_HELPER = "#image-download-link";
      /** @type {string} */
      that.SAVE_IMAGE_COPY_SELECTOR = "#image-copy";
      /** @type {string} */
      that.ACTIVITY_CODE_SUBMIT_BOX_SELECTOR = "#submit-activity-submit-box";
      /** @type {string} */
      that.ACTIVITY_CODE_OPEN_SELECTOR = "#submit-activity-submit";
      /** @type {string} */
      that.ACTIVITY_CODE_TARGET_SELECTOR = "#submit-activity-target";
      /** @type {string} */
      that.ACTIVITY_CODE_ERROR_SELECTOR = "#submit-activity-error";
      /** @type {string} */
      that.SHARE_POPUP_URL_INPUT_SELECTOR = "#save-popup #link-url";
      /** @type {string} */
      that.SHARE_POPUP_CODE_INPUT_SELECTOR = "#save-popup #link-code";
      /** @type {string} */
      that.ACTIVITY_CODE_DISPLAY_SELECTOR = "#activity-display-code";
      /** @type {string} */
      that.DELETE_msgBox_ID = "delete-msgBox";
      /** @type {string} */
      that.START_OVER_msgBox_ID = "start-over-msgBox";
      /** @type {string} */
      that.START_OVER_FROM_SAVE_msgBox_ID = "start-over-from-save-msgBox";
      /** @type {string} */
      that.SPAWN_ITEM_FAILURE_ID = "spawn-item-failure";
      /** @type {string} */
      that.DUPLICATE_ITEM_FAILURE_ID = "duplicate-item-failure";
      /** @type {string} */
      that.TEXT_SELECTED_BACKING_COLOR = "rgba(255, 255, 255, 0.1)";
      that.Events = {};
      /** @type {string} */
      that.Events.TOOLBAR_CLICKED = "toolbarclicked";
      /** @type {string} */
      that.Events.REQUEST_START_OVER = "requeststartover";
      /** @type {string} */
      that.Events.START_OVER_DONE = "startoverdone";
      /** @type {string} */
      that.Events.SPAWN_EQUATION_REQUEST = "requestnewequation";
      /** @type {string} */
      that.Events.SPAWN_TEXT_REQUEST = "requestnewtext";
      /** @type {string} */
      that.Events.SPAWN_SHADE_REQUEST = "requestnewshade";
      /** @type {string} */
      that.Events.SPAWN_CLOCK_REQUEST = "requestnewclock";
      /** @type {string} */
      that.Events.SPAWN_GEARED_CLOCK_REQUEST = "requestnewgearclock";
      /** @type {string} */
      that.Events.SPAWN_UNGEARED_CLOCK_REQUEST = "requestnewungearclock";
      /** @type {string} */
      that.Events.SPAWN_FRACTION_CLOCK_REQUEST = "requestnewfractionclock";
      /** @type {string} */
      that.Events.EDIT_CLOCK_PALETTE_SHOW = "editclockpaletteshow";
      /** @type {string} */
      that.Events.EDIT_CLOCK_PALETTE_HIDE = "editclockpalettehide";
      /** @type {string} */
      that.Events.EDIT_CLOCK_PALETTE_TOGGLE = "editclockpalettetoggle";
      /** @type {string} */
      that.Events.SPAWN_CLOCK_FAILURE_PROMPT = "spawnclockfailureprompt";
      /** @type {string} */
      that.Events.SPAWN_CLOCK_FAILURE_PROMPT_CLOSE = "spawnclockfailureclose";
      /** @type {string} */
      that.Events.SPAWN_TEXT_FAILURE_PROMPT = "spawntextfailureprompt";
      /** @type {string} */
      that.Events.SPAWN_TEXT_FAILURE_PROMPT_CLOSE = "spawntextfailureclose";
      /** @type {string} */
      that.Events.DUPLICATE_CLOCK_FAILURE_PROMPT = "duplicateclockfailureprompt";
      /** @type {string} */
      that.Events.DUPLICATE_CLOCK_FAILURE_PROMPT_CLOSE = "duplicateclockfailureclose";
      /** @type {string} */
      that.Events.DUPLICATE_TEXT_FAILURE_PROMPT = "duplicatetextfailureprompt";
      /** @type {string} */
      that.Events.DUPLICATE_TEXT_FAILURE_PROMPT_CLOSE = "duplicatetextfailureclose";
      /** @type {string} */
      that.Events.SPAWN_CLOCK_FAILURE = "spawnclockfailure";
      /** @type {string} */
      that.Events.DUPLICATE_CLOCK_FAILURE = "duplicateclockfailure";
      /** @type {string} */
      that.Events.SPAWN_TEXT_FAILURE = "spawntextfailure";
      /** @type {string} */
      that.Events.DUPLICATE_TEXT_FAILURE = "duplicatetextfailure";
      /** @type {string} */
      that.Events.TOGGLE_EDIT_MODE = "toggleeditmode";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_EDIT_MODE = "toggleselectioneditmode";
      /** @type {string} */
      that.Events.TOGGLE_DIGITAL_READOUT_MODE = "toggledigitalreadout";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_DIGITAL_READOUT_MODE = "togglesleectiondigitalreadoutmode";
      /** @type {string} */
      that.Events.TOGGLE_RUN_JUMP_MODE = "togglerunjump";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_RUN_JUMP_MODE = "toggleselectionrunjumpmode";
      /** @type {string} */
      that.Events.TOGGLE_ELAPSED_TIME_MODE = "toggleelapsedtime";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_ELAPSED_TIME_MODE = "toggleselectionelapsedtimemode";
      /** @type {string} */
      that.Events.TOGGLE_TELL_TIME_MODE = "toggletelltime";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_TELL_TIME_MODE = "toggleselectiontelltimemode";
      /** @type {string} */
      that.Events.TOGGLE_TELL_ANGLE_MODE = "toggletellangle";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_TELL_ANGLE_MODE = "toggleselectiontellanglemode";
      /** @type {string} */
      that.Events.TOGGLE_FRACTION_MODE = "togglefractionmode";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_FRACTION_MODE = "toggleselectionfractionmode";
      /** @type {string} */
      that.Events.FRACTION_PICK_PALETTE_SHOW = "fractionpickpaletteshow";
      /** @type {string} */
      that.Events.FRACTION_PICK_PALETTE_HIDE = "fractionpickpalettehide";
      /** @type {string} */
      that.Events.FRACTION_PICK_PALETTE_TOGGLE = "fractionpickpalettetoggle";
      /** @type {string} */
      that.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT = "fractionpickpalettesetfragmentcount";
      /** @type {string} */
      that.Events.FRACTION_ENTITY_SET_FRAGMENT_COUNT = "fractionentitysetfragmentcount";
      /** @type {string} */
      that.Events.FRACTION_FILL_PALETTE_SHOW = "fractionfillpaletteshow";
      /** @type {string} */
      that.Events.FRACTION_FILL_PALETTE_HIDE = "fractionfillpalettehide";
      /** @type {string} */
      that.Events.FRACTION_FILL_PALETTE_TOGGLE = "fractionfillpalettetoggle";
      /** @type {string} */
      that.Events.TOGGLE_FRACTION_FILL_MODE = "togglefractionfillmode";
      /** @type {string} */
      that.Events.TOGGLE_SELECTION_FRACTION_FILL_MODE = "toggleselectionfractionfillmode";
      /** @type {string} */
      that.Events.SET_FRACTION_FILL_COLOR = "setfractionfillcolor";
      /** @type {string} */
      that.Events.SET_CLOCK_TYPE = "setclocktype";
      /** @type {string} */
      that.Events.SET_SELECTION_CLOCK_TYPE = "setselectionclocktype";
      /** @type {string} */
      that.Events.SET_CLOCK_HAND_VISIBILITY = "setclockhandvisibility";
      /** @type {string} */
      that.Events.SET_SELECTION_CLOCK_HAND_VISIBILITY = "setselectionclockhandvisibility";
      /** @type {string} */
      that.Events.SET_CLOCK_HAND_LABEL_VISIBILITY = "setclockhandlabelvisibility";
      /** @type {string} */
      that.Events.SET_SELECTION_CLOCK_HAND_LABEL_VISIBILITY = "setselectionclockhandlabelvisibility";
      /** @type {string} */
      that.Events.TOGGLE_RUN_JUMP_STATE = "togglerunjumpstate";
      /** @type {string} */
      that.Events.JUMP_BY_AMOUNT = "jumpbyamount";
      /** @type {string} */
      that.Events.REQUEST_SELECTION_DELETE = "requestselectiondelete";
      /** @type {string} */
      that.Events.DISABLE_SELECTION_DELETE = "disableselectiondelete";
      /** @type {string} */
      that.Events.ENABLE_SELECTION_DELETE = "enableselectiondelete";
      /** @type {string} */
      that.Events.NEW_CLOCK_base_OPEN = "newclockbaseopen";
      /** @type {string} */
      that.Events.NEW_CLOCK_base_CLOSE = "newclockbaseclose";
      /** @type {string} */
      that.Events.REQUEST_INFO = "requestinfo";
      /** @type {string} */
      that.Events.SAVE_STATE = "savestate";
      /** @type {string} */
      that.Events.SAVE_POPOUT_SHOW = "savepopoutshow";
      /** @type {string} */
      that.Events.SAVE_POPOUT_HIDE = "savepopouthide";
      /** @type {string} */
      that.Events.SAVE_POPOUT_TOGGLE = "savepopouttoggle";
      /** @type {string} */
      that.Events.COPY_SAVE_LINK = "savelinkcopy";
      /** @type {string} */
      that.Events.EXPORT_CANVAS_TO_DESKTOP = "exportcanvasdesktop";
      /** @type {string} */
      that.Events.EXPORT_CANVAS_TO_IMAGE = "exportcanvasimage";
      /** @type {string} */
      that.Events.COPY_IMAGE_OPEN_EVENT = "copyimageopen";
      /** @type {string} */
      that.Events.COPY_IMAGE_CLOSE_EVENT = "copyimageclose";
      /** @type {string} */
      that.Events.ACTIVITY_CODE_DISPLAY_OPEN_EVENT = "activitycodedisplayopen";
      /** @type {string} */
      that.Events.ACTIVITY_CODE_DISPLAY_CLOSE_EVENT = "activitycodedisplayclose";
      /** @type {string} */
      that.Events.ACTIVITY_CODE_OPEN_EVENT = "activitycodeopen";
      /** @type {string} */
      that.Events.ACTIVITY_CODE_CLOSE_EVENT = "activitycodeclose";
      /** @type {string} */
      that.Events.LOAD_ACTIVITY_CODE = "loadactivitycode";
      /** @type {string} */
      that.Events.HAND_CHANGED = "handchanged";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_ADJUSTMENT = "digitalreadoutadjustment";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_MODE_TOGGLE = "digitalreadoutmodetoggle";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_TOGGLE_ACTIVE = "digitalreadouttoggleactive";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_SET_ACTIVE = "digitalreadoutsetactive";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_UNSET_ACTIVE = "digitalreadoutunsetactive";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_INPUT_FOCUS = "digitalreadoutinputfocus";
      /** @type {string} */
      that.Events.DIGITAL_READOUT_INPUT_BLUR = "digitalreadoutinputblur";
      /** @type {string} */
      /* ---------------------------*/
      that.Events.TELL_TIME_ADJUSTMENT = "digitalreadoutadjustment";
      /** @type {string} */
      that.Events.TELL_TIME_MODE_TOGGLE = "digitalreadoutmodetoggle";
      /** @type {string} */
      that.Events.TELL_TIME_TOGGLE_ACTIVE = "digitalreadouttoggleactive";
      /** @type {string} */
      that.Events.TELL_TIME_SET_ACTIVE = "digitalreadoutsetactive";
      /** @type {string} */
      that.Events.TELL_TIME_UNSET_ACTIVE = "digitalreadoutunsetactive";
      /** @type {string} */
      that.Events.TELL_TIME_INPUT_FOCUS = "digitalreadoutinputfocus";
      /** @type {string} */
      that.Events.TELL_TIME_INPUT_BLUR = "digitalreadoutinputblur";
      /** @type {string} */
      /* -------------------------- */
      that.Events.JUMP_TOGGLE_ACTIVE = "jumptoggleactive";
      /** @type {string} */
      that.Events.JUMP_SET_ACTIVE = "jumpsetactive";
      /** @type {string} */
      that.Events.JUMP_UNSET_ACTIVE = "jumpunsetactive";
      /** @type {string} */
      that.Events.JUMP_INPUT_FOCUS = "jumpinputfocus";
      /** @type {string} */
      that.Events.JUMP_INPUT_BLUR = "jumpinputblur";
      /** @type {string} */
      that.Events.SET_RUN_STATE = "setrunstate";
      that.Keycodes = {
        ARROW_LEFT: 37,
        ARROW_UP: 38,
        ARROW_RIGHT: 39,
        ARROW_DOWN: 40,
      };
      that.ITEM_DEFINITIONS = {};
      that.BUTTON_DEFINITIONS = {};
      that.CellDimensions = {
        WIDTH: 34,
        HEIGHT: 34,
      };
      /** @type {number} */
      that.SHADOW_BLUR = 8;
      /** @type {number} */
      that.SHADOW_SPREAD = 6;
      /** @type {number} */
      that.COLOR_ALPHA_AFFIX = 80;
      /** @type {number} */
      that.TRANSPARENT_ALPHA_AFFIX = 26;
      /** @type {number} */
      that.DEFAULT_CLOCK_RADIUS = 188;
      /** @type {number} */
      that.MINIMUM_CLOCK_RADIUS = 120;
      /** @type {number} */
      that.MAXIMUM_CLOCK_RADIUS = 325;
      /** @type {number} */
      that.GENERAL_CLOCK_FACE_RADIUS_PADDING = 30;
      /** @type {number} */
      that.RADIANS_TO_DEGREES = 180 / Math.PI;
      /** @type {number} */
      that.DEGREES_TO_RADIANS = Math.PI / 180;
      /** @type {number} */
      that.CLOCK_LIMIT = 12;
      /** @type {number} */
      that.WORKSPACE_HEIGHT = 720;
      /** @type {number} */
      that.WORKSPACE_WIDTH = 1024;
      /** @type {number} */
      that.SPAWN_PADDING_INC = 50;
      /** @type {string} */
      that.APP_FULL_NAME = "Math Clock Tool";
      /** @type {string} */
      that.IOS_APP_URL = "";
      /** @type {string} */
      that.DEFAULT_SAVE_FILENAME = "my math clock";
      that.FALLBACK_CONFIG = {
        appState: {
          booleanFlags: {},
          customObjects: [],
        },
        workspaces: [],
      };
      var bubbled_sets__3355;
      var m = new _this.a({
        id: data.DELETE_msgBox_ID,
        openEvent: _this.d.DELETE_SELECTION_PROMPT_EVENT,
        closeEvent: _this.d.DELETE_SELECTION_PROMPT_CLOSE_EVENT,
        message: "Delete selected items?",
        buttons: [
          {
            label: "Cancel",
          },
          {
            label: "Delete",
            event: _this.d.DELETE_SELECTION_EVENT,
            default: true,
          },
        ],
        appendTo: "body",
      });
      var button1 = new _this.a({
        id: data.SPAWN_ITEM_FAILURE_ID,
        openEvent: _this.d.SPAWN_ITEM_FAILURE_PROMPT_EVENT,
        closeEvent: _this.d.SPAWN_ITEM_FAILURE_PROMPT_CLOSE_EVENT,
        title: "Too many items",
        message: "Please remove some items before adding new ones.",
        parent: "body",
      });
      var C = new _this.a({
        id: data.DUPLICATE_ITEM_FAILURE_ID,
        openEvent: _this.d.DUPLICATE_ITEM_FAILURE_PROMPT_EVENT,
        closeEvent: _this.d.DUPLICATE_ITEM_FAILURE_PROMPT_CLOSE_EVENT,
        title: "Too many items",
        message: "Please remove some items before adding new ones.",
        parent: "body",
      });
      var S = new _this.a({
        id: data.ACTIVITY_CODE_SELECTOR,
        openEvent: _this.d.ACTIVITY_CODE_OPEN_EVENT,
        closeEvent: _this.d.ACTIVITY_CODE_CLOSE_EVENT,
        message: "Activity code display opened.",
        appendTo: "body",
      });
      var events = new _this.a({
        id: data.START_OVER_msgBox_ID,
        openEvent: _this.d.START_OVER_ALL_PROMPT_EVENT,
        closeEvent: _this.d.START_OVER_ALL_PROMPT_CLOSE_EVENT,
        title: "Start Over?",
        message: "Do you want to clear all your work?",
        buttons: [
          {
            label: "",
            event: _this.d.START_OVER_EVENT,
            default: true,
          },
          {
            label: "",
          },
        ],
        appendTo: "body",
      });
      var O = new _this.a({
        id: data.START_OVER_FROM_SAVE_msgBox_ID,
        openEvent: _this.d.START_OVER_SAVESTATE_PROMPT_EVENT,
        closeEvent: _this.d.START_OVER_SAVESTATE_PROMPT_CLOSE_EVENT,
        title: "Start Over",
        message: "What would you like to do?",
        buttons: [
          {
            label: "Go Back to Start",
            event: _this.d.START_OVER_SAVESTATE_EVENT,
          },
          {
            label: "Clear All",
            event: _this.d.START_OVER_EVENT,
          },
          {
            label: "Cancel",
          },
        ],
        appendTo: "body",
      });
      var model = {};
      /**
       * @return {undefined}
       */
      model.init = function () {
        bubbled_sets__3355 = {
          keymsgBox: S,
          deletemsgBox: m,
          startOvermsgBox: events,
          startOverFromSavemsgBox: O,
          spawnItemFailurePrompt: button1,
          duplicateItemFailurePrompt: C,
          activityCodeOfflineWarning: v,
        };
        this.anyActive();
      };
      /**
       * @return {?}
       */
      model.anyActive = function () {
        return match()(req.a).call(req.a, bubbled_sets__3355, function (FileModal) {
          return FileModal.isOpen;
        });
      };
      var ret = model;
      var div = $("mnMc");
      var trigger = $.n(div);
      var value = $("RXMP");
      var cb = $.n(value);
      var script = $("5PDf");
      var require = $.n(script);
      var global = $("m2rO");
      var links = $("ZbhI");
      var action = $.n(links);
      var s = $("TTrh");
      var parse = $.n(s);
      var elements = $("rPUy");
      var mutation = $.n(elements);
      filter.prototype = mutation()(_this.c.prototype);
      filter.prototype.constructor = _this.c;
      /** @type {function(?, !Object): undefined} */
      var LogEntry = filter;
      /**
       * @return {undefined}
       */
      filter.prototype.setupDisplayComponents = function () {
        this.back = new doc.a.Shape();
        this.label = new doc.a.Shape();
        this.back.graphics = this.handGraphics;
        this.label.graphics = this.handLabel;
        if (req.a.isObject(this.handHitArea)) {
          this.back.hitArea = new doc.a.Shape(this.handHitArea);
        }
        /** @type {!Array} */
        this.displayComponents = [this.back, this.label];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this.display.setBounds(0, 0, this.width, this.height);
      };
      /**
       * @return {undefined}
       */
      filter.prototype.draw = function () {
        this.back.rotation = this.angle;
        this.label.visible = this.labelOn;
        this.label.rotation = this.angle;
        /** @type {number} */
        this.label.regY = -this.height / 3;

        //console.log("Angle: ", this);//Vikas
      };
      CheckerToolkit.prototype = mutation()(_this.c.prototype);
      CheckerToolkit.prototype.constructor = _this.c;
      /** @type {function(?, !Object): undefined} */
      var K = CheckerToolkit;
      /**
       * @param {!Object} size
       * @return {undefined}
       */
      CheckerToolkit.prototype.setupDisplayComponents = function (size) {
        this.gear = new doc.a.Shape();
        this.gear.graphics = size.gearGraphics;
        this.gear.mask = new doc.a.Shape(size.maskGraphics);
        this.highlight = new doc.a.Shape(size.highlightGraphics);
        /** @type {number} */
        this.highlight.alpha = 0.0;
        /** @type {!Array} */
        this.displayComponents = [this.gear, this.highlight];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
      };
      var tablesongs = $("Kwsy");
      var __WEBPACK_IMPORTED_MODULE_2_date_fns_difference_in_days___default = $.n(tablesongs);
      var x = $("lHQ6");
      var pipe = $.n(x);
      var state = {
        hr24: "24hr",
        hr12: "12hr",
      };
      /** @type {string} */
      var readFunction = state.hr12;
      /** @type {string} */
      var width = "normal 24px Helvetica Neue, sans-serif";
      /** @type {string} */
      var fontName = "normal 16px Helvetica Neue, sans-serif";
      var TABS_ACTIVE_LINE_COLOR = _this.d.COLOR_PRIMARY_BASE;
      var nums = {
        HOURS_UP: "hours-up",
        HOURS_DOWN: "hours-down",
        MINUTES_UNITS_UP: "minutes-units-up",
        MINUTES_UNITS_DOWN: "minutes-units-down",
        MINUTES_FIVES_UP: "minutes-fives-up",
        MINUTES_FIVES_DOWN: "minutes-fives-down",
        PERIOD_UP: "period-up",
        PERIOD_DOWN: "period-down",
      };
      test.prototype = mutation()(_this.c.prototype);
      test.prototype.constructor = _this.c;
      /** @type {function(?, string): undefined} */
      var DirSearchPathEntry = test;
      /**
       * @return {undefined}
       */
      test.prototype._setupDisplayComponents = function () {
        var interval = this._setupTextComponents();
        var file = this._setupUiComponents();
        var n = this._setupElements();
        this.hours = interval.hours;
        this.spacer = interval.spacer;
        this.minutes = interval.minutes;
        this.period = interval.period;
        this.backing = file.backing;
        this.hoursUp = file.hoursUp;
        this.hoursDown = file.hoursDown;
        this.hoursInput = n.hoursInput;
        this.minutesUp = file.minutesUp;
        this.minutesDown = file.minutesDown;
        this.minutesInput = n.minutesInput;
        this.periodUp = file.periodUp;
        this.periodDown = file.periodDown;
        this.readoutDisplayModeToggle = file.readoutDisplayModeToggle;
        /** @type {!Array} */
        this.displayComponents = [
          this.backing,
          this.hours,
          this.spacer,
          this.minutes,
          this.period,
          this.hoursUp.display,
          this.hoursDown.display,
          this.hoursInput,
          this.minutesUp.display,
          this.minutesDown.display,
          this.minutesInput,
          this.periodUp.display,
          this.periodDown.display,
          this.readoutDisplayModeCanToggle ? this.readoutDisplayModeToggle.display : null,
        ];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this._placeComponents();
      };
      /**
       * @return {?}
       */
      test.prototype._setupTextComponents = function () {
        var options = {};
        return (
          (options.hours = new doc.a.Text("88", width, "white")),
          (options.spacer = new doc.a.Text(":", fontName, "white")),
          (options.minutes = new doc.a.Text("88", width, "white")),
          (options.period = new doc.a.Text("AM", fontName, "white")),
          (options.hours.textBaseline = "middle"),
          (options.spacer.textBaseline = "middle"),
          (options.minutes.textBaseline = "middle"),
          (options.period.textBaseline = "middle"),
          options
        );
      };
      /**
       * @return {?}
       */
      test.prototype._setupUiComponents = function () {
        var self = {};
        var result = this._getButtonOptions("up", nums.HOURS_UP);
        var y = this._getButtonOptions("down", nums.HOURS_DOWN);
        var subprotocols = this._getButtonOptions("up", nums.MINUTES_UNITS_UP);
        var startHistoryId = this._getButtonOptions("down", nums.MINUTES_UNITS_DOWN);
        var data = this._getButtonOptions("up", nums.PERIOD_UP);
        var tls_socket_options = this._getButtonOptions("down", nums.PERIOD_DOWN);
        return (
          (self.backing = new doc.a.Shape()),
          (self.hoursUp = new _this.b(null, result)),
          (self.hoursDown = new _this.b(null, y)),
          (self.minutesUp = new _this.b(null, subprotocols)),
          (self.minutesDown = new _this.b(null, startHistoryId)),
          (self.periodUp = new _this.b(null, data)),
          (self.periodDown = new _this.b(null, tls_socket_options)),
          (self.readoutDisplayModeToggle = new _this.v(null, this._getModeToggleButtonOptions())),
          self.hoursUp.draw(),
          self.hoursDown.draw(),
          self.minutesUp.draw(),
          self.minutesDown.draw(),
          self.periodUp.draw(),
          self.periodDown.draw(),
          self.readoutDisplayModeToggle.draw(),
          self
        );
      };
      /**
       * @return {undefined}
       */
      test.prototype._bindDispatcherEvents = function () {
        var node = this;
        _this.f.on(
          data.Events.DIGITAL_READOUT_MODE_TOGGLE,
          function (aReport) {
            console.log("DIGITAL_READOUT_MODE_TOGGLE", aReport);
            var node = this.readoutDisplayMode;
            var value = pipe()(this.hours.text, 10);
            var BR = this.period.text;
            this.readoutDisplayMode = aReport.mode;
            if ((node === state.hr24 && value > 12) || (node === state.hr24 && 0 === value)) {
              this.setTime(value);
            } else {
              if (node === state.hr12 && "AM" === BR && 12 === value) {
                this.setTime(0);
              } else {
                if (node === state.hr12 && "PM" === BR && 12 === value) {
                  this.setTime(12);
                } else {
                  if (node === state.hr12 && "PM" === BR) {
                    this.setTime(value + 12);
                  }
                }
              }
            }
            this._placeComponents();
            this.draw();
          },
          this
        );
        _this.f.on(data.Events.DIGITAL_READOUT_TOGGLE_ACTIVE, function (options) {
          var c;
          var s = req.a.isBoolean(options.setTo);
          if (req.a.contains(options.ids, node.id) && node.enabled) {
            if ((s && options.setTo) || (!s && !node.active)) {
              c = new doc.a.Event(data.Events.DIGITAL_READOUT_SET_ACTIVE);
            }
            if ((s && !options.setTo) || (!s && node.active)) {
              c = new doc.a.Event(data.Events.DIGITAL_READOUT_UNSET_ACTIVE);
            }
            c.set({
              ids: [node.id],
            });
            _this.f.dispatchEvent(c);
          }
        });
        _this.f.on(data.Events.DIGITAL_READOUT_SET_ACTIVE, function (options) {
          if (req.a.contains(options.ids, node.id) && node.enabled) {
            /** @type {boolean} */
            node.active = true;
            node.draw();
            _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          }
        });
        _this.f.on(data.Events.DIGITAL_READOUT_UNSET_ACTIVE, function (options) {
          if (req.a.contains(options.ids, node.id) && node.enabled) {
            /** @type {boolean} */
            node.active = false;
            node.draw();
            _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          }
        });
      };
      /**
       * @return {?}
       */
      test.prototype._setupElements = function () {
        var d = {};
        return (d.hoursInput = this._createInputField("hours")), (d.minutesInput = this._createInputField("minutes")), d;
      };
      /**
       * @param {string} key
       * @return {?}
       */
      test.prototype._createInputField = function (key) {
        var x;
        var y;
        var element = debug()("<div><input/></div>");
        var bunny = new doc.a.DOMElement(element[0]);
        return (
          document.querySelector("main").appendChild(element[0]),
          (bunny.y = 4),
          element.addClass("digital-readout"),
          element.addClass("digital-readout--" + key + "-input"),
          (x = 24 - (element.outerWidth(true) - element.width())),
          (y = 24 - (element.outerHeight(true) - element.height())),
          (bunny.width = x),
          (bunny.height = y),
          element.width(x),
          element.height(y),
          this._attachInputFieldEvents(debug()("input", element), key),
          bunny
        );
      };
      /**
       * @param {!Object} e
       * @param {string} undefined
       * @return {undefined}
       */
      test.prototype._attachInputFieldEvents = function (e, undefined) {
        var scope = this;
        e.on("input", function () {
          var name;
          var n;
          var trigger = new doc.a.Event(data.Events.DIGITAL_READOUT_INPUT_TEXT_CHANGE);
          e.val(e.val().replace(/\D/g, ""));
          if ((name = e.val()).length > 2) {
            name = name.substring(1);
            e.val(name);
          }
          n = pipe()(name, 10);
          if (req.a.isNaN(n)) {
            console.error("New time is not a number.");
          } else {
            if (!(("hours" === undefined && (n < 1 || n > 12)) || ("minutes" === undefined && (n < 0 || n > 59)))) {
              if ("hours" === undefined && scope.readoutDisplayMode === state.hr12) {
                if ("PM" === scope.period.text && 12 !== n) {
                  n = n + 12;
                } else {
                  if ("AM" === scope.period.text && 12 === n) {
                    /** @type {number} */
                    n = n - 12;
                  }
                }
              }
              trigger.set({
                newTime: n,
                hoursOrMinutes: undefined,
                id: scope.id,
              });
              _this.f.dispatchEvent(trigger);
            }
          }
        });
        e.on("keydown", function (event) {
          switch (event.keyCode) {
            case data.Keycodes.ARROW_UP:
            case data.Keycodes.ARROW_DOWN:
              scope._adjustmentKeyboardTicker(undefined, event.keyCode);
          }
        });
        e.on("keyup", function () {
          scope._cleanupTickTracker();
        });
        e.on("focus", function () {
          e.select();
          _this.f.dispatchEvent(data.Events.DIGITAL_READOUT_INPUT_FOCUS);
        });
        e.on("blur", function () {
          var intVal = pipe()(e.val(), 10);
          if ("hours" === undefined && (intVal < 1 || intVal > 12 || req.a.isNaN(intVal))) {
            e.val(scope.hours.text);
          }
          if ("minutes" === undefined && (intVal < 0 || intVal > 59 || req.a.isNaN(intVal))) {
            e.val(scope.minutes.text);
          }
          _this.f.dispatchEvent(data.Events.DIGITAL_READOUT_INPUT_BLUR);
        });
      };
      /**
       * @return {undefined}
       */
      test.prototype.draw = function () {
        this.hoursUp.display.visible = this.active && this.enabled;
        this.hoursDown.display.visible = this.active && this.enabled;
        this.hoursInput.visible = this.active && this.enabled;
        this.minutesUp.display.visible = this.active && this.enabled;
        this.minutesDown.display.visible = this.active && this.enabled;
        this.minutesInput.visible = this.active && this.enabled;
        this.periodUp.display.visible = this.readoutDisplayMode === state.hr12 && this.active && this.enabled;
        this.periodDown.display.visible = this.readoutDisplayMode === state.hr12 && this.active && this.enabled;
        if (this.enabled) {
          if (this.active) {
            //console.log("enable Active");
            this.backing.graphics
              .clear()
              .setStrokeStyle(3)
              .beginStroke(TABS_ACTIVE_LINE_COLOR)
              .beginFill("black")
              .drawRoundRect(0, -this.height / 2, this.width, 2 * this.height, 8);
          } else {
            //console.log("enable NOT active");
            this.backing.graphics
              .clear()
              .setStrokeStyle(3)
              .beginStroke(TABS_ACTIVE_LINE_COLOR)
              .beginFill("black")
              .drawRoundRect(0, 0, this.width, this.height, 8);
          }
        } else {
          //console.log("NOT enable");
          this.backing.graphics.clear().setStrokeStyle(3).beginStroke("grey").beginFill("grey").drawRoundRect(0, 0, this.width, this.height, 8);
        }
      };
      /**
       * @param {number} i
       * @param {number} v
       * @return {undefined}
       */
      test.prototype.setTime = function (i, v) {
        var value;
        if (req.a.isNumber(i)) {
          if (i < 0 || i >= 24) {
            console.error("Hour time out of bounds:", i);
          } else {
            if (this.readoutDisplayMode === state.hr12) {
              if (0 === (value = Math.floor(i % 12))) {
                /** @type {number} */
                value = value + 12;
              }
              /** @type {string} */
              this.hours.text = "" + value;
              if (this.hours.text.length < 2) {
                /** @type {string} */
                this.hours.text = "0" + this.hours.text;
              }
            } else {
              /** @type {string} */
              this.hours.text = "" + Math.floor(i);
              if (this.hours.text.length < 2) {
                /** @type {string} */
                this.hours.text = "0" + this.hours.text;
              }
            }
          }
          debug()("input", this.hoursInput.htmlElement).val(this.hours.text);
        }
        if (req.a.isNumber(v)) {
          if (v < 0 || v >= 60) {
            console.error("Minute time out of bounds:", v);
          } else {
            /** @type {string} */
            this.minutes.text = "" + Math.floor(v);
            if (this.minutes.text.length < 2) {
              /** @type {string} */
              this.minutes.text = "0" + this.minutes.text;
            }
          }
          debug()("input", this.minutesInput.htmlElement).val(this.minutes.text);
        }
        if (this.readoutDisplayMode === state.hr12) {
          /** @type {string} */
          this.period.text = i < 12 ? "AM" : "PM";
        }
      };

      /**
       * @return {undefined}
       */
      test.prototype._placeComponents = function () {
        /** @type {number} */
        var w = this.width / 2;
        var lineWidth =
          this.hours.getMeasuredWidth() +
          4 +
          this.spacer.getMeasuredWidth() +
          4 +
          this.minutes.getMeasuredWidth() +
          (this.readoutDisplayMode === state.hr12 ? 8 : 0) +
          (this.readoutDisplayMode === state.hr12 ? this.period.getMeasuredWidth() : 0);
        /** @type {number} */
        var plottingAreaHeight = this.height / 2 + 1;
        /** @type {number} */
        var yAxisVerticalMargin = -this.hours.getMeasuredHeight() - 4;
        /** @type {number} */
        var wty = this.hours.getMeasuredHeight() / 2 + 2;
        /** @type {number} */
        var i = w - lineWidth / 2;
        /** @type {number} */
        this.hours.x = i;
        /** @type {number} */
        this.hoursUp.x = i;
        /** @type {number} */
        this.hoursDown.x = i;
        /** @type {number} */
        this.hoursInput.x = i - (this.hours.getMeasuredWidth() - debug()(this.hoursInput.htmlElement).outerWidth(true)) / 2 - 5;
        i = i + this.hours.getMeasuredWidth();
        i = i + 4;
        this.spacer.x = i + -1;
        i = i + this.spacer.getMeasuredWidth();
        i = i + 4;
        this.minutes.x = i;
        this.minutesUp.x = i;
        this.minutesDown.x = i;
        /** @type {number} */
        this.minutesInput.x = i - (this.minutes.getMeasuredWidth() - debug()(this.minutesInput.htmlElement).outerWidth(true)) / 2 - 5;
        i = i + this.minutes.getMeasuredWidth();
        i = i + 8;
        /** @type {boolean} */
        this.period.visible = this.readoutDisplayMode === state.hr12;
        this.periodUp.display.visible = this.readoutDisplayMode === state.hr12 && this.active;
        this.periodDown.display.visible = this.readoutDisplayMode === state.hr12 && this.active;
        this.period.x = i;
        this.periodUp.x = i;
        this.periodDown.x = i;
        i = i + this.period.getMeasuredWidth();
        /** @type {number} */
        this.hours.y = plottingAreaHeight;
        /** @type {number} */
        this.hoursUp.y = plottingAreaHeight + yAxisVerticalMargin;
        /** @type {number} */
        this.hoursDown.y = plottingAreaHeight + wty;
        /** @type {number} */
        this.spacer.y = plottingAreaHeight;
        /** @type {number} */
        this.minutes.y = plottingAreaHeight;
        /** @type {number} */
        this.minutesUp.y = plottingAreaHeight + yAxisVerticalMargin;
        /** @type {number} */
        this.minutesDown.y = plottingAreaHeight + wty;
        /** @type {number} */
        this.period.y = plottingAreaHeight;
        /** @type {number} */
        this.periodUp.y = plottingAreaHeight + yAxisVerticalMargin;
        /** @type {number} */
        this.periodDown.y = plottingAreaHeight + wty;
        /** @type {number} */
        this.readoutDisplayModeToggle.x = 2;
        /** @type {number} */
        this.readoutDisplayModeToggle.y = 2;
      };
      /**
       * @param {string} direction
       * @param {!Object} length
       * @return {?}
       */
      test.prototype._getButtonOptions = function (direction, length) {
        var removedRelations = this;
        /** @type {boolean} */
        var ev = "down" !== direction;
        var config = {
          buttonType: _this.b.ButtonTypes.TEXT,
          font: fontName,
          fillColor: _this.d.COLOR_PRIMARY_BASE,
          activeColor: _this.d.COLOR_PRIMARY_PALE,
          borderColor: "transparent",
          dimensions: {
            width: 24,
            height: 12,
          },
          clickableHandlers: {
            mousedown: function (event) {
              if (0 === event.nativeEvent.button) {
                removedRelations._adjustmentButtonMouseDown(length);
                /** @type {boolean} */
                this.active = true;
                this.draw();
                _this.f.dispatchEvent(new doc.a.Event(data.STAGE_UPDATE));
              }
            },
            pressup: function () {
              removedRelations._adjustmentButtonPressUp();
              /** @type {boolean} */
              this.active = false;
              this.draw();
              _this.f.dispatchEvent(new doc.a.Event(data.STAGE_UPDATE));
            },
          },
          clickCallback: function () {},
        };
        return (
          (config.draw = ev
            ? {
                init: function () {
                  this.shape = new doc.a.Shape();
                  this.display.addChild(this.shape);
                },
                callback: function () {
                  //console.log("TEST 11111");
                  this.shape.graphics
                    .clear()
                    .setStrokeStyle(this.strokeThickness)
                    .beginStroke(this.borderColor)
                    .beginFill(this.active ? this.activeColor : this.fillColor)
                    .moveTo(0, this.height)
                    .lineTo(this.width / 2, 0)
                    .lineTo(this.width, this.height)
                    .closePath();
                },
              }
            : {
                init: function () {
                  this.shape = new doc.a.Shape();
                  this.display.addChild(this.shape);
                },
                callback: function () {
                  //console.log("TEST 2222222");
                  this.shape.graphics
                    .clear()
                    .setStrokeStyle(this.strokeThickness)
                    .beginStroke(this.borderColor)
                    .beginFill(this.active ? this.activeColor : this.fillColor)
                    .moveTo(0, 0)
                    .lineTo(this.width / 2, this.height)
                    .lineTo(this.width, 0);
                },
              }),
          config
        );
      };
      /**
       * @param {boolean} bitmask
       * @return {undefined}
       */
      test.prototype._adjustmentButtonMouseDown = function (bitmask) {
        this._cleanupTickTracker();
        this._adjustmentButtonTicker(bitmask);
      };
      /**
       * @return {undefined}
       */
      test.prototype._adjustmentButtonPressUp = function () {
        this._cleanupTickTracker();
      };
      /**
       * @return {undefined}
       */
      test.prototype._cleanupTickTracker = function () {
        if (this.tickTracker) {
          if (req.a.isNumber(this.tickTracker.timeoutId)) {
            clearTimeout(this.tickTracker.timeoutId);
          }
          /** @type {null} */
          this.tickTracker.timeoutId = null;
          /** @type {number} */
          this.tickTracker.tickCount = 0;
        }
      };
      /**
       * @param {number} n
       * @return {undefined}
       */
      test.prototype._adjustmentButtonTicker = function (n) {
        var jimple = this;
        /** @type {number} */
        var start = 500;
        if (!req.a.isObject(this.tickTracker)) {
          this.tickTracker = {
            timeoutId: null,
            tickCount: 0,
          };
        }
        this._adjustmentTick(n);
        this.tickTracker.tickCount += 1;
        if (this.tickTracker.tickCount > 1) {
          /** @type {number} */
          start = n === nums.MINUTES_FIVES_UP || n === nums.MINUTES_FIVES_DOWN ? 250 : 150;
        }
        if (this.tickTracker.tickCount >= 10) {
          if (n === nums.MINUTES_UNITS_UP) {
            /** @type {string} */
            n = nums.MINUTES_FIVES_UP;
          } else {
            if (n === nums.MINUTES_UNITS_DOWN) {
              /** @type {string} */
              n = nums.MINUTES_FIVES_DOWN;
            }
          }
        }
        this.tickTracker.timeoutId = __WEBPACK_IMPORTED_MODULE_2_date_fns_difference_in_days___default()(function () {
          jimple._adjustmentButtonTicker(n);
        }, start);
      };
      /**
       * @param {string} undefined
       * @param {number} keyCode
       * @return {undefined}
       */
      test.prototype._adjustmentKeyboardTicker = function (undefined, keyCode) {
        /** @type {string} */
        var n = "";
        if (!req.a.isObject(this.tickTracker)) {
          this.tickTracker = {
            timeoutId: null,
            tickCount: 0,
          };
        }
        if (req.a.isNull(this.tickTracker.timeoutId)) {
          if ("hours" === undefined) {
            if (keyCode === data.Keycodes.ARROW_UP) {
              /** @type {string} */
              n = nums.HOURS_UP;
            } else {
              if (keyCode === data.Keycodes.ARROW_DOWN) {
                /** @type {string} */
                n = nums.HOURS_DOWN;
              }
            }
          } else {
            if ("minutes" === undefined) {
              if (keyCode === data.Keycodes.ARROW_UP) {
                /** @type {string} */
                n = nums.MINUTES_UNITS_UP;
              } else {
                if (keyCode === data.Keycodes.ARROW_DOWN) {
                  /** @type {string} */
                  n = nums.MINUTES_UNITS_DOWN;
                }
              }
            }
          }
          if (this.tickTracker.tickCount >= 10) {
            if (n === nums.MINUTES_UNITS_UP) {
              /** @type {string} */
              n = nums.MINUTES_FIVES_UP;
            } else {
              if (n === nums.MINUTES_UNITS_DOWN) {
                /** @type {string} */
                n = nums.MINUTES_FIVES_DOWN;
              }
            }
          }
          this._adjustmentTick(n);
          this.tickTracker.tickCount += 1;
        }
      };
      /**
       * @param {!Object} posnum
       * @return {undefined}
       */
      test.prototype._adjustmentTick = function (posnum) {
        var new_record = new doc.a.Event(data.Events.DIGITAL_READOUT_ADJUSTMENT);
        new_record.set({
          adjustmentType: posnum,
          id: this.display.id,
        });
        _this.f.dispatchEvent(new_record);
      };
      /**
       * @return {?}
       */
      test.prototype._getModeToggleButtonOptions = function () {
        var e = this;
        return {
          dimensions: {
            width: 20,
            height: 20,
          },
          buttonText: this.readoutDisplayMode,
          initialState: this.readoutDisplayMode !== state.hr24,
          fillColor: "teal",
          activeColor: "chocolate",
          toggleEvent: data.Events.DIGITAL_READOUT_MODE_TOGGLE,
          clickCallback: function () {
            var instance = new doc.a.Event(data.Events.DIGITAL_READOUT_MODE_TOGGLE);
            if (e.enabled) {
              if (this.stateActive) {
                /** @type {string} */
                this.label.text = "24hr";
              } else {
                /** @type {string} */
                this.label.text = "12hr";
              }
              instance.set({
                mode: this.stateActive ? state.hr24 : state.hr12,
                id: e.display.id,
                setState: !this.stateActive,
              });
              _this.f.dispatchEvent(instance);
              this.draw();
            }
          },
          font: "normal 8px Helvetica Neue",
        };
      };
      /**
       * @return {undefined}
       */
      test.prototype.delete = function () {
        debug()(this.hoursInput.htmlElement).remove();
        debug()(this.minutesInput.htmlElement).remove();
      };
      test.AdjustmentTypes = nums;
      test.ReadoutModes = state;
      var $sharepreview = $("iapb");
      var bar = $("2xYs");
      var obj2 = $("NVI9");
      var str = $("lD3G");
      var pattern = $("ZgxC");
      var accessInfo = {
        PLAY: "play",
        STOP: "stop",
        RESET: "reset",
      };
      /*Tell time funcions start...............*/

      testTellTime.prototype = mutation()(_this.c.prototype);
      testTellTime.prototype.constructor = _this.c;
      /** @type {function(?, string): undefined} */
      //var DirSearchPathEntry = testTellTime;
      /**
       * @return {undefined}
       */
      testTellTime.prototype._setupDisplayComponents = function () {
        //console.log(testTellTime.prototype._setupDisplayComponents.caller);
        var interval = this._setupTextComponents();
        var file = this._setupUiComponents();
        var n = this._setupElements();
        //console.log("testTellTime.prototype._setupDisplayComponents: ", interval);//Vikas
        this.hours = interval.hours;
        this.spacer = interval.spacer;
        this.minutes = interval.minutes;
        this.period = interval.period;
        this.backing = file.backing;
        this.timebg = file.timebg;
        this.timeButton = n.timeButton;
        this.timeBar = n.timeBar;
        this.tellTimeDisplayModeToggle = file.tellTimeDisplayModeToggle;
        /** @type {!Array} */
        this.displayComponents = [
          this.backing,
          this.timebg,
          this.hours,
          this.spacer,
          this.minutes,
          this.period,
          this.timeButton,
          this.timeBar,
          this.tellTimeDisplayModeCanToggle ? this.tellTimeDisplayModeToggle.display : null,
        ];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this._placeComponents();
      };
      /**
       * @return {?}
       */
      testTellTime.prototype._setupTextComponents = function () {
        var options = {};
        if(this.timeEnabled){
          return (
            (options.hours = new doc.a.Text("88", width, "black")),
            (options.spacer = new doc.a.Text(":", fontName, "black")),
            (options.minutes = new doc.a.Text("88", width, "black")),
            (options.period = new doc.a.Text("AM", fontName, "black")),
            (options.hours.textBaseline = "middle"),
            (options.spacer.textBaseline = "middle"),
            (options.minutes.textBaseline = "middle"),
            (options.period.textBaseline = "middle"),
            options
          );
        }else{
          return (
            (options.hours = new doc.a.Text("88", width, "#999999")),
            (options.spacer = new doc.a.Text(":", fontName, "#999999")),
            (options.minutes = new doc.a.Text("88", width, "#999999")),
            (options.period = new doc.a.Text("AM", fontName, "#999999")),
            (options.hours.textBaseline = "middle"),
            (options.spacer.textBaseline = "middle"),
            (options.minutes.textBaseline = "middle"),
            (options.period.textBaseline = "middle"),
            options
          );
        }
        
      };
      /**
       * @return {?}
       */
      testTellTime.prototype._setupUiComponents = function () {
        var self = {};
        
        return (
          (self.backing = new doc.a.Shape()),
          (self.timebg = new doc.a.Shape()),
          
          (self.tellTimeDisplayModeToggle = new _this.v(null, this._getModeToggleButtonOptions())),
          self.tellTimeDisplayModeToggle.draw(),
          self
        );
      };
      
      /**
       * @return {undefined}
       */
      testTellTime.prototype._bindDispatcherEvents = function () {
        var node = this;
        _this.f.on(
          data.Events.TELL_TIME_MODE_TOGGLE,
          function (aReport) {
            console.log("TELL_TIME_MODE_TOGGLE",this.tellTimeDisplayMode);
            var node = this.tellTimeDisplayMode;
            var value = pipe()(this.hours.text, 10);
            var BR = this.period.text;
            this.tellTimeDisplayMode = aReport.mode;
            if ((node === state.hr24 && value > 12) || (node === state.hr24 && 0 === value)) {
              this.setTime(value);
            } else {
              if (node === state.hr12 && "AM" === BR && 12 === value) {
                this.setTime(0);
              } else {
                if (node === state.hr12 && "PM" === BR && 12 === value) {
                  this.setTime(12);
                } else {
                  if (node === state.hr12 && "PM" === BR) {
                    this.setTime(value + 12);
                  }
                }
              }
            }
            this._placeComponents();
            this.draw();
          },
          this
        );
        _this.f.on(data.Events.TELL_TIME_TOGGLE_ACTIVE, function (options) {
          var c;
          var s = req.a.isBoolean(options.setTo);
          if (req.a.contains(options.ids, node.id) && node.enabled) {
            if ((s && options.setTo) || (!s && !node.active)) {
              c = new doc.a.Event(data.Events.TELL_TIME_SET_ACTIVE);
            }
            if ((s && !options.setTo) || (!s && node.active)) {
              c = new doc.a.Event(data.Events.TELL_TIME_UNSET_ACTIVE);
            }
            c.set({
              ids: [node.id],
            });
            _this.f.dispatchEvent(c);
          }
        });
        _this.f.on(data.Events.TELL_TIME_SET_ACTIVE, function (options) {
          if (req.a.contains(options.ids, node.id) && node.enabled) {
            /** @type {boolean} */
            node.active = true;
            node.draw();
            _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          }
        });
        _this.f.on(data.Events.TELL_TIME_UNSET_ACTIVE, function (options) {
          if (req.a.contains(options.ids, node.id) && node.enabled) {
            /** @type {boolean} */
            node.active = false;
            node.draw();
            _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          }
        });
      };
      /**
       * @return {?}
       */
      testTellTime.prototype._setupElements = function () {
        var d = {};
        return (d.timeButton = this._createButton("time")),d;
      };
      
      /**
       * @param {string} key
       * @return {?}
       */
      testTellTime.prototype._createButton = function (key) {
        var element = debug()("<div><button id='tell-time-button'>Tell the Time</button></div>");
        var bunny = new doc.a.DOMElement(element[0]);
        return (
          document.querySelector("main").appendChild(element[0]), this._attachInputFieldEvents(debug()("#tell-time-button", element), key), bunny
        );
      };

      /**
       * @param {!Object} e
       * @param {string} undefined
       * @return {undefined}
       */
      testTellTime.prototype._attachInputFieldEvents = function (e, undefined) {
        var scope = this;
        e.on("click", function (event) {
          //console.log(scope);
          if(this.timeEnabled){
            event.target.classList.remove("on");
          }else{
            event.target.classList.add("on");
          }
          this.timeEnabled = !this.timeEnabled;
          var trigger = new doc.a.Event(data.Events.TELL_TIME_BUTTON_CLICK);
          trigger.set({
            display: true,
            id: scope.id,
          });
          _this.f.dispatchEvent(trigger);
          
        });

        
      };
      /**
       * @return {undefined}
       */
      testTellTime.prototype.draw = function () {
        //this.hoursInput.visible = this.active && this.enabled;
        //this.minutesInput.visible = this.active && this.enabled;
        //console.log("TELL TIME: ", this);
        //console.log("------TELL TIME: ", _this);
        if (this.enabled) {
          if (this.active) {
           // console.log("enable active");
            this.backing.graphics
              .clear()
              //.setStrokeStyle(3)
              //.beginStroke(TABS_ACTIVE_LINE_COLOR)
              .beginFill('#233239')
              .drawRoundRect(0, 0, this.width, this.height, 20);              
          } else {
            //console.log("enable NOT active");
            this.backing.graphics
              .clear()
              //setStrokeStyle(3)
              //beginStroke(TABS_ACTIVE_LINE_COLOR)
              .beginFill('#233239')
              .drawRoundRect(0, 0, this.width, this.height, 20);
          }
        } else {
         // console.log("NOT Enable");
         this.backing.graphics
          .clear()
          //.setStrokeStyle(3)
          //.beginStroke("grey")
          .beginFill('#233239')
          .drawRoundRect(0, 0, this.width, this.height, 20);
        }
        if(!this.timeEnabled){
          this.timebg.graphics
          .clear()
          .beginFill("#999999")
          .drawRoundRect(0, 0, 275, 50, 8);
        }else{
          this.timebg.graphics
          .clear()
          .beginFill("white")
          .drawRoundRect(0, 0, 275, 50, 8);
        }
      };
      /**
       * @param {number} i
       * @param {number} v
       * @return {undefined}
       */
      testTellTime.prototype.setTime = function (i, v) {
        //console.log("testTellTime.prototype.setTime", i,v);//Vikas
        var value;
        if (req.a.isNumber(i)) {
          if (i < 0 || i >= 24) {
            console.error("Hour time out of bounds:", i);
          } else {
            if (this.tellTimeDisplayMode === state.hr12) {
              if (0 === (value = Math.floor(i % 12))) {
                /** @type {number} */
                value = value + 12;
              }
              /** @type {string} */
              this.hours.text = "" + value;
              if (this.hours.text.length < 2) {
                /** @type {string} */
                this.hours.text = "0" + this.hours.text;
              }
            } else {
              /** @type {string} */
              this.hours.text = "" + Math.floor(i);
              if (this.hours.text.length < 2) {
                /** @type {string} */
                this.hours.text = "0" + this.hours.text;
              }
            }
          }
          //debug()("input", this.hoursInput.htmlElement).val(this.hours.text);
        }
        if (req.a.isNumber(v)) {
          if (v < 0 || v >= 60) {
            console.error("Minute time out of bounds:", v);
          } else {
            /** @type {string} */
            this.minutes.text = "" + Math.floor(v);
            if (this.minutes.text.length < 2) {
              /** @type {string} */
              this.minutes.text = "0" + this.minutes.text;
            }
          }
          //debug()("input", this.minutesInput.htmlElement).val(this.minutes.text);
        }
        if (this.tellTimeDisplayMode === state.hr12) {
          /** @type {string} */
          this.period.text = i < 12 ? "AM" : "PM";
        }
      };

      /**
       * @return {undefined}
       */
      testTellTime.prototype._placeComponents = function () {
        /** @type {number} */
        //console.log("TELL TIME: ", this);
        var w = this.width / 2;
        var lineWidth =
          this.hours.getMeasuredWidth() +
          4 +
          this.spacer.getMeasuredWidth() +
          4 +
          this.minutes.getMeasuredWidth() +
          (this.tellTimeDisplayMode === state.hr12 ? 8 : 0) +
          (this.tellTimeDisplayMode === state.hr12 ? this.period.getMeasuredWidth() : 0);        
        
        /** @type {number} */
        var i = w - lineWidth / 2;
        /** @type {number} */
        this.timeButton.x = i - 92;
        
        this.hours.x = i;
        /** @type {number} */
        i = i + this.hours.getMeasuredWidth();
        i = i + 4;
        this.spacer.x = i + -1;
        i = i + this.spacer.getMeasuredWidth();
        i = i + 4;
        this.minutes.x = i;
        /** @type {number} */
        i = i + this.minutes.getMeasuredWidth();
        i = i + 8;
        /** @type {boolean} */
        this.period.visible = this.readoutDisplayMode === state.hr12;
        this.period.x = i;
        i = i + this.period.getMeasuredWidth();
        /** @type {number} */
        this.hours.y = 40;
        /** @type {number} */
        this.spacer.y = 40;
        /** @type {number} */
        this.minutes.y = 40;
        /** @type {number} */
        this.period.y = 40;
        /** @type {number} */
        this.timeButton.y = 80;
        this.timebg.x=15;
        this.timebg.y=15;
        
        this.tellTimeDisplayModeToggle.x = 2;
        /** @type {number} */
        this.tellTimeDisplayModeToggle.y = 2;
      };
      /**
       * @param {string} direction
       * @param {!Object} length
       * @return {?}
       */
      testTellTime.prototype._getButtonOptions = function (direction, length) {
        var removedRelations = this;
        /** @type {boolean} */
        var ev = "down" !== direction;
        var config = {
          buttonType: _this.b.ButtonTypes.TEXT,
          font: fontName,
          fillColor: _this.d.COLOR_PRIMARY_BASE,
          activeColor: _this.d.COLOR_PRIMARY_PALE,
          borderColor: "transparent",
          dimensions: {
            width: 24,
            height: 12,
          },
          clickableHandlers: {
            mousedown: function (event) {
              if (0 === event.nativeEvent.button) {
                removedRelations._adjustmentButtonMouseDown(length);
                /** @type {boolean} */
                this.active = true;
                this.draw();
                _this.f.dispatchEvent(new doc.a.Event(data.STAGE_UPDATE));
              }
            },
            pressup: function () {
              removedRelations._adjustmentButtonPressUp();
              /** @type {boolean} */
              this.active = false;
              this.draw();
              _this.f.dispatchEvent(new doc.a.Event(data.STAGE_UPDATE));
            },
          },
          clickCallback: function () {},
        };
        return (
          (config.draw = ev
            ? {
                init: function () {
                  this.shape = new doc.a.Shape();
                  this.display.addChild(this.shape);
                },
                callback: function () {
                  this.shape.graphics
                    .clear()
                    .setStrokeStyle(this.strokeThickness)
                    .beginStroke(this.borderColor)
                    .beginFill(this.active ? this.activeColor : this.fillColor)
                    .moveTo(0, this.height)
                    .lineTo(this.width / 2, 0)
                    .lineTo(this.width, this.height)
                    .closePath();
                },
              }
            : {
                init: function () {
                  this.shape = new doc.a.Shape();
                  this.display.addChild(this.shape);
                },
                callback: function () {
                  this.shape.graphics
                    .clear()
                    .setStrokeStyle(this.strokeThickness)
                    .beginStroke(this.borderColor)
                    .beginFill(this.active ? this.activeColor : this.fillColor)
                    .moveTo(0, 0)
                    .lineTo(this.width / 2, this.height)
                    .lineTo(this.width, 0);
                },
              }),
          config
        );
      };
      /**
       * @param {boolean} bitmask
       * @return {undefined}
       */
      testTellTime.prototype._adjustmentButtonMouseDown = function (bitmask) {
        this._cleanupTickTracker();
        this._adjustmentButtonTicker(bitmask);
      };
      /**
       * @return {undefined}
       */
      testTellTime.prototype._adjustmentButtonPressUp = function () {
        this._cleanupTickTracker();
      };
      /**
       * @return {undefined}
       */
      testTellTime.prototype._cleanupTickTracker = function () {
        if (this.tickTracker) {
          if (req.a.isNumber(this.tickTracker.timeoutId)) {
            clearTimeout(this.tickTracker.timeoutId);
          }
          /** @type {null} */
          this.tickTracker.timeoutId = null;
          /** @type {number} */
          this.tickTracker.tickCount = 0;
        }
      };
      /**
       * @param {number} n
       * @return {undefined}
       */
      testTellTime.prototype._adjustmentButtonTicker = function (n) {
        var jimple = this;
        /** @type {number} */
        var start = 500;
        if (!req.a.isObject(this.tickTracker)) {
          this.tickTracker = {
            timeoutId: null,
            tickCount: 0,
          };
        }
        this._adjustmentTick(n);
        this.tickTracker.tickCount += 1;
        if (this.tickTracker.tickCount > 1) {
          /** @type {number} */
          start = n === nums.MINUTES_FIVES_UP || n === nums.MINUTES_FIVES_DOWN ? 250 : 150;
        }
        if (this.tickTracker.tickCount >= 10) {
          if (n === nums.MINUTES_UNITS_UP) {
            /** @type {string} */
            n = nums.MINUTES_FIVES_UP;
          } else {
            if (n === nums.MINUTES_UNITS_DOWN) {
              /** @type {string} */
              n = nums.MINUTES_FIVES_DOWN;
            }
          }
        }
        this.tickTracker.timeoutId = __WEBPACK_IMPORTED_MODULE_2_date_fns_difference_in_days___default()(function () {
          jimple._adjustmentButtonTicker(n);
        }, start);
      };
      /**
       * @param {string} undefined
       * @param {number} keyCode
       * @return {undefined}
       */
      testTellTime.prototype._adjustmentKeyboardTicker = function (undefined, keyCode) {
        /** @type {string} */
        var n = "";
        if (!req.a.isObject(this.tickTracker)) {
          this.tickTracker = {
            timeoutId: null,
            tickCount: 0,
          };
        }
        if (req.a.isNull(this.tickTracker.timeoutId)) {
          if ("hours" === undefined) {
            if (keyCode === data.Keycodes.ARROW_UP) {
              /** @type {string} */
              n = nums.HOURS_UP;
            } else {
              if (keyCode === data.Keycodes.ARROW_DOWN) {
                /** @type {string} */
                n = nums.HOURS_DOWN;
              }
            }
          } else {
            if ("minutes" === undefined) {
              if (keyCode === data.Keycodes.ARROW_UP) {
                /** @type {string} */
                n = nums.MINUTES_UNITS_UP;
              } else {
                if (keyCode === data.Keycodes.ARROW_DOWN) {
                  /** @type {string} */
                  n = nums.MINUTES_UNITS_DOWN;
                }
              }
            }
          }
          if (this.tickTracker.tickCount >= 10) {
            if (n === nums.MINUTES_UNITS_UP) {
              /** @type {string} */
              n = nums.MINUTES_FIVES_UP;
            } else {
              if (n === nums.MINUTES_UNITS_DOWN) {
                /** @type {string} */
                n = nums.MINUTES_FIVES_DOWN;
              }
            }
          }
          this._adjustmentTick(n);
          this.tickTracker.tickCount += 1;
        }
      };
      /**
       * @param {!Object} posnum
       * @return {undefined}
       */
      testTellTime.prototype._adjustmentTick = function (posnum) {
        var new_record = new doc.a.Event(data.Events.DIGITAL_READOUT_ADJUSTMENT);
        new_record.set({
          adjustmentType: posnum,
          id: this.display.id,
        });
        _this.f.dispatchEvent(new_record);
      };
      /**
       * @return {?}
       */
      testTellTime.prototype._getModeToggleButtonOptions = function () {
        var e = this;
        return {
          dimensions: {
            width: 20,
            height: 20,
          },
          buttonText: this.readoutDisplayMode,
          initialState: this.readoutDisplayMode !== state.hr24,
          fillColor: "teal",
          activeColor: "chocolate",
          toggleEvent: data.Events.DIGITAL_READOUT_MODE_TOGGLE,
          clickCallback: function () {
            var instance = new doc.a.Event(data.Events.DIGITAL_READOUT_MODE_TOGGLE);
            if (e.enabled) {
              if (this.stateActive) {
                /** @type {string} */
                this.label.text = "24hr";
              } else {
                /** @type {string} */
                this.label.text = "12hr";
              }
              instance.set({
                mode: this.stateActive ? state.hr24 : state.hr12,
                id: e.display.id,
                setState: !this.stateActive,
              });
              _this.f.dispatchEvent(instance);
              this.draw();
            }
          },
          font: "normal 8px Helvetica Neue",
        };
      };
      /**
       * @return {undefined}
       */
      testTellTime.prototype.delete = function () {
        debug()(this.hoursInput.htmlElement).remove();
        debug()(this.minutesInput.htmlElement).remove();
      };
      testTellTime.AdjustmentTypes = nums;
      testTellTime.ReadoutModes = state;
      

      /*Tell time functions end................*/
      
      M6CorpoChecker_HpPro.prototype = mutation()(_this.c.prototype);
      M6CorpoChecker_HpPro.prototype.constructor = _this.c;
      /** @type {function(?, ?): undefined} */
      var CatchEntry = M6CorpoChecker_HpPro;
      /**
       * @return {undefined}
       */
      M6CorpoChecker_HpPro.prototype._setupDisplayComponents = function () {
        //this.backing = new doc.a.Bitmap($sharepreview);
        this.stop = this._setupStopButton();
        this.play = this._setupPlayButton();
        /** @type {!Array} */
        this.displayComponents = [this.stop.display, this.play.display];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this._placeComponents();
      };
      /**
       * @return {?}
       */
      M6CorpoChecker_HpPro.prototype._setupStopButton = function () {
        var e = this;
        var config = this._genericButtonOptions();
        return (
          (config.defaultImage = bar),
          (config.activeImage = obj2),
          (config.clickCallback = function () {
            var deviceOrientationEvent;
            /** @type {boolean} */
            var continueLast = true === e.stop.stateActive;
            /** @type {boolean} */
            e.stop.stateActive = true;
            /** @type {boolean} */
            e.play.stateActive = false;
            e.draw();
            (deviceOrientationEvent = new doc.a.Event(data.Events.SET_RUN_STATE)).set({
              ids: [e.id],
              newState: continueLast ? accessInfo.RESET : accessInfo.STOP,
            });
            _this.f.dispatchEvent(deviceOrientationEvent);
          }),
          (config.initialState = true),
          new _this.v(null, config)
        );
      };
      /**
       * @return {?}
       */
      M6CorpoChecker_HpPro.prototype._setupPlayButton = function () {
        var e = this;
        var options = this._genericButtonOptions();
        return (
          (options.defaultImage = str),
          (options.activeImage = pattern),
          (options.clickCallback = function () {
            var deviceOrientationEvent;
            e.stop.stateActive = e.play.stateActive;
            /** @type {boolean} */
            e.play.stateActive = !e.play.stateActive;
            e.draw();
            (deviceOrientationEvent = new doc.a.Event(data.Events.SET_RUN_STATE)).set({
              ids: [e.id],
              newState: e.play.stateActive ? accessInfo.PLAY : accessInfo.STOP,
            });
            _this.f.dispatchEvent(deviceOrientationEvent);
          }),
          new _this.v(null, options)
        );
      };
      /**
       * @return {?}
       */
      M6CorpoChecker_HpPro.prototype._genericButtonOptions = function () {
        return {
          buttonType: _this.b.ButtonTypes.ICON,
          dimensions: {
            width: 150,
            height: 150,
          },
        };
      };
      /**
       * @return {undefined}
       */
      M6CorpoChecker_HpPro.prototype._placeComponents = function () {
        
        /** @type {number} */
        this.stop.x = 70;
        /** @type {number} */
        this.stop.y = 50;
        /** @type {number} */
        this.play.x = 170;
        /** @type {number} */
        this.play.y = 50;
        
      };
      /**
       * @return {undefined}
       */
      M6CorpoChecker_HpPro.prototype.draw = function () {
        this.stop.draw();
        this.play.draw();
      };
      M6CorpoChecker_HpPro.RunStates = accessInfo;
      var el = $("y45+");
      var A = $("qN/d");
      HtmlAxisLabel.prototype = mutation()(_this.c.prototype);
      HtmlAxisLabel.prototype.constructor = _this.c;
      /** @type {function(?, string): undefined} */
      var FinallyEntry = HtmlAxisLabel;
      /**
       * @param {string} val
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._setupDisplayComponents = function (val) {
        var resolution;
        //this.backing = new doc.a.Bitmap($sharepreview);
        this.backButton = this._setupBackButton();
        this.forwardButton = this._setupForwardButton();
        this.fakeInputBacking = new doc.a.Shape();
        this.fakeInputText = this._setupFakeText(val);
        this.input = this._setupInputElement(val);
        /** @type {!Array} */
        this.displayComponents = [
          
          this.backButton.display,
          this.forwardButton.display,
          this.fakeInputBacking,
          this.fakeInputText,
          this.input,
        ];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        resolution = {
          width: 160,
          height: 50,
        };
        /** @type {number} */
        this.width = resolution.width;
        /** @type {number} */
        this.height = resolution.height;
        this._placeComponents();
        this._bindDispatcherEvents();
      };
      /**
       * @param {string} keys
       * @return {?}
       */
      HtmlAxisLabel.prototype._setupInputElement = function (keys) {
        var width;
        var size;
        var $grid = debug()("<div><input/></div>");
        var iframe = new doc.a.DOMElement($grid[0]);
        return (
          document.querySelector("main").appendChild($grid[0]),
          $grid.addClass("jump-control"),
          $grid.addClass("jump-control--input"),
          debug()("input", $grid).attr("type", "text"),
          debug()("input", $grid).attr("maxlength", "2"),
          (width = 24 - ($grid.outerWidth(true) - $grid.width())),
          (size = 24 - ($grid.outerHeight(true) - $grid.height())),
          (iframe.width = width),
          (iframe.height = size),
          $grid.width(width),
          $grid.height(size),
          debug()("input", $grid).val(keys.initialJumpStep),
          this._attachInputFieldEvents(debug()("input", $grid)),
          iframe
        );
      };
      /**
       * @param {!Object} e
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._attachInputFieldEvents = function (e) {
        var RoomVisual = this;
        e.on("input", function () {
          var deviceOrientationEvent = new doc.a.Event(data.Events.JUMP_CONTROL_INPUT_TEXT_CHANGE);
          e.val(e.val().replace(/\D/g, ""));
          RoomVisual.fakeInputText.text = e.val();
          _this.f.dispatchEvent(deviceOrientationEvent);
        });
        e.on("focus", function () {
          e.select();
          _this.f.dispatchEvent(data.Events.JUMP_INPUT_FOCUS);
        });
        e.on("blur", function () {
          _this.f.dispatchEvent(data.Events.JUMP_INPUT_BLUR);
        });
      };
      /**
       * @param {string} word
       * @return {?}
       */
      HtmlAxisLabel.prototype._setupFakeText = function (word) {
        var labelContext = new doc.a.Text(word.initialJumpStep, "normal 24px Helvetica neue, sans-serif", "#333333");
        return (labelContext.textAlign = "center"), (labelContext.textBaseline = "middle"), labelContext;
      };
      /**
       * @return {?}
       */
      HtmlAxisLabel.prototype._setupBackButton = function () {
        var e = el;
        var json = this._getButtonOptions(e, -1);
        return new _this.b(null, json);
      };
      /**
       * @return {?}
       */
      HtmlAxisLabel.prototype._setupForwardButton = function () {
        var e = A;
        var json = this._getButtonOptions(e, 1);
        return new _this.b(null, json);
      };
      /**
       * @param {string} fn
       * @param {!Object} val
       * @return {?}
       */
      HtmlAxisLabel.prototype._getButtonOptions = function (fn, val) {
        var QuickBase = this;
        return {
          buttonType: _this.b.ButtonTypes.ICON,
          defaultImage: fn,
          borderColor: "transparent",
          activeColor: "transparent",
          fillColor: "transparent",
          dimensions: {
            width: 24,
            height: 24,
          },
          clickableHandlers: {
            mousedown: function (event) {
              if (0 === event.nativeEvent.button) {
                QuickBase._jumpButtonMouseDown(val);
                /** @type {boolean} */
                this.active = true;
                this.draw();
                _this.f.dispatchEvent(new doc.a.Event(data.STAGE_UPDATE));
              }
            },
            pressup: function () {
              QuickBase._jumpButtonPressUp();
              /** @type {boolean} */
              this.active = false;
              this.draw();
              _this.f.dispatchEvent(new doc.a.Event(data.STAGE_UPDATE));
            },
          },
          clickCallback: function () {},
        };
      };
      /**
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._bindDispatcherEvents = function () {
        var node = this;
        _this.f.on(data.Events.JUMP_TOGGLE_ACTIVE, function (options) {
          var c;
          var s = req.a.isBoolean(options.setTo);
          if (req.a.contains(options.ids, node.id)) {
            if ((s && options.setTo) || (!s && !node.active)) {
              c = new doc.a.Event(data.Events.JUMP_SET_ACTIVE);
            }
            if ((s && !options.setTo) || (!s && node.active)) {
              c = new doc.a.Event(data.Events.JUMP_UNSET_ACTIVE);
            }
            c.set({
              ids: [node.id],
            });
            _this.f.dispatchEvent(c);
          }
        });
        _this.f.on(data.Events.JUMP_SET_ACTIVE, function (options) {
          if (req.a.contains(options.ids, node.id)) {
            /** @type {boolean} */
            node.active = true;
            node.draw();
            _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          }
        });
        _this.f.on(data.Events.JUMP_UNSET_ACTIVE, function (options) {
          if (req.a.contains(options.ids, node.id)) {
            /** @type {boolean} */
            node.active = false;
            node.draw();
            _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
          }
        });
      };
      /**
       * @param {!Object} callback
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._jumpButtonMouseDown = function (callback) {
        this._cleanupTickTracker();
        this._jumpButtonTicker(callback);
      };
      /**
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._jumpButtonPressUp = function () {
        this._cleanupTickTracker();
      };
      /**
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._cleanupTickTracker = function () {
        if (this.tickTracker) {
          if (req.a.isNumber(this.tickTracker.timeoutId)) {
            clearTimeout(this.tickTracker.timeoutId);
          }
          /** @type {null} */
          this.tickTracker.timeoutId = null;
          /** @type {number} */
          this.tickTracker.tickCount = 0;
        }
      };
      /**
       * @param {boolean} data
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._jumpButtonTicker = function (data) {
        var cnxn = this;
        /** @type {number} */
        var start = 500;
        if (!req.a.isObject(this.tickTracker)) {
          this.tickTracker = {
            timeoutId: null,
            tickCount: 0,
          };
        }
        getEvents(this, data);
        this.tickTracker.tickCount += 1;
        if (this.tickTracker.tickCount > 1) {
          /** @type {number} */
          start = 150;
        }
        this.tickTracker.timeoutId = __WEBPACK_IMPORTED_MODULE_2_date_fns_difference_in_days___default()(function () {
          cnxn._jumpButtonTicker(data);
        }, start);
      };
      /**
       * @return {undefined}
       */
      HtmlAxisLabel.prototype._placeComponents = function () {
        /** @type {number} */
        this.backButton.y = 50;
        /** @type {number} */
        this.backButton.x = 25;
        /** @type {number} */
        this.forwardButton.x = 220;
        /** @type {number} */
        this.forwardButton.y = 50;
        /** @type {number} */
        this.input.x = 120;
        /** @type {number} */
        this.input.y = 45;
        /** @type {number} */
        this.fakeInputBacking.x = this.input.x;
        /** @type {number} */
        this.fakeInputBacking.y = this.input.y;
        /** @type {number} */
        this.fakeInputText.x = this.input.x + 19;
        /** @type {number} */
        this.fakeInputText.y = this.input.y + 14 + 1;
      };
      /**
       * @return {undefined}
       */
      HtmlAxisLabel.prototype.draw = function () {
        this.input.visible = this.active;
        this.fakeInputBacking.graphics.clear().beginFill("white").beginStroke("rgb(238, 238, 238)").drawRect(0, 0, 38, 28);
      };
      /**
       * @return {undefined}
       */
      HtmlAxisLabel.prototype.delete = function () {
        debug()(this.input.htmlElement).remove();
      };
      var key = $("z6m/");
      var index = $("CJ9Q");
      var _img = $("X750");
      var imageNum = $("jbH8");
      var listTypeStack = {
        RUN: "run",
        JUMP: "jump",
      };
      /** @type {string} */
      // NNO run jump
      var toolsElement = listTypeStack.JUMP;
      var BUTTON_BACKGROUND_COLOR = _this.d.COLOR_PRIMARY_BASE;
      var BUTTON_BORDER_COLOR = _this.d.COLOR_NEUTRAL_BASE;
      Tween.prototype = mutation()(_this.c.prototype);
      Tween.prototype.constructor = _this.c;
      /** @type {function(?, string): undefined} */
      var MOUSEDOWN = Tween;
      /**
       * @param {string} obj2
       * @return {undefined}
       */
      Tween.prototype._setupDisplayComponents = function (obj2) {
        
        var RawClasses = this._setupRunComponent(obj2.controlMode);
        var keys = this._setupJumpComponent(obj2.controlMode, obj2.initialJumpStep);
        this.backing = new doc.a.Bitmap($sharepreview);
        this.runTab = RawClasses.tab;
        this.runControl = RawClasses.control;
        this.jumpTab = keys.tab;
        this.jumpControl = keys.control;
        /** @type {!Array} */
        this.displayComponents = [this.backing, this.runTab.display, this.jumpTab.display, this.runControl.display, this.jumpControl.display];
        req.a.each(
          this.displayComponents,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this._placeComponents();
      };
      /**
       * @param {string} tab
       * @return {?}
       */
      Tween.prototype._setupRunComponent = function (tab) {
        var $scope = {};
        return ($scope.tab = this._setupRunTab(tab)), ($scope.control = this._setupRunControl()), $scope;
      };
      /**
       * @param {string} indent
       * @return {?}
       */
      Tween.prototype._setupRunTab = function (indent) {
        var opts = this._getGenericButtonOptions("RUN", data.Events.TOGGLE_RUN_JUMP_STATE);
        return (
          (opts.defaultImage =
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAA9CAYAAACHtnoZAAAKs0lEQVR4nO1dfXATxxX/rSzLtmQixykYCCFmBmOIMZikNhDkIgINFEgCQ3DTTBtESSeZIWWgfzSeKQlm0k4g6QCZgXRIm0YwkzK1YUoa6EDKhxJsCIGAKDUB42CRkGKbD8u25C+k2/4h6bR3OkknW+IO534z69Huvff27b6f3mpXJx9BP3CmxTMZHM0J1QnhSkCRE0tHgwIgcFOqc/J1HXE/mpd9Tr66DJxp8Uwmfr8NoFYQlCTupQZVgcIJEAdNS7PHIktMcpxt7ngGHFelEWIQg8IJna5qyvD7PhJfkiTH6dvUnNbTbgfBotR7p0EVoNjrzzTbfphL2kNNEeQ4fZua+7raHQRatrjX4B+4CWem0WwNEURAjn/fpmbS2e4ghMQkhp4A2YY0vt7j49DjpwN37XsCVU8VpU5yn9n641zSrmfbu9s9VYAughh6HVCYk4HhRj2Mel2EvTschfNmD5q7fKlzWgFwag5iykBKSJunCsAaPnNUN3XOhB8OsehIYxpKh2XCkBZ7Y9Pg7sO5W33J9lSDUkiDlc8cnJ/aiOgjSI5BhxkjsmTZcvdx+F6+0QYpqJ/aCABUf03NHPW42YvpOmDhaFPcjAEAl9x9cGpZY9BBDwA+6l0kpkCOIS0mMfr8FE2dd9DQfgden5YzBiP0AEABq3hX64kS8LZePy61+9DUyX74lHXQquEegx4ACJAvvuD1UXx2vQf3Z+j4elsvB3cfd3c91KAYCAB82OjR1gUNEQgtKxo0REA15Hh/3Rq46uV9m5xfNJl/nWnMxogxYzF9wRJkmbKj6jTVO/HXdb/h62/sPpKQf0eqd+Bo9Q6+/xXrN0fIvPbsEwIfpWRigZ2DX67fhDFFyn6DESTHvfWBUkyii6fqcGLfbix+pRITyiySOuIxDnTM8fRd9edwfN8eTF/4bL/tKx0X1WQOFjlD85AzbHjU61IZpqfLi11vvQbb+s2S7zjxGBMdc3/0j1bbUVhmwf0xxhKrP6XjEiCH0l4Agpkosc6DtcImS+3iF7XYu20Derq8AADH3+3IX78lpn2gH2Omwtdy9Hu6vNi7dQNsUv4kqY9UQhf0QxUlhER0CsssmMkQyXXhHNpam2Pa7++Y4+lKwXXhHE7s353SOUhVCZKDKF6EB2mJ6U5dsBTmoeHU/dWpuih9sJOffP9YsP44qnegrbUloT6UjgcFUU/mEAYu8ZLDBKPH60lJH/H0WTxpewUZxsDuqbfLg4+2bUj5HKQkcwwGNLsalXZBgExTNp5eWcnXr15w4uT+3Qp6lDhUmTkS9amttRm9XR5eNy9/bFLty9UXo7DMgnGl4a31p9X2qJ+HkuFjSjKH0k6IJycRnW6vBzVvr+V1M4zZGF1UEnfyU+GflP2nVlYKlpeat9cmfQ5SVVR5COa+0QxXvTOuXMMXtWg4VYv2G818W3mFDRmmIZLBEtZTewhGgzIZpiFYuLISe4IEbnE14rNqO8orlsvSVxKqPAQ77ziA844DCetZltpQumCp5HjikSUeEtVnM8G4snIUlFpw+VQtAOBYjR0FpRbkjSmQpa8UVLOsDATF1nl4vmoLLBXLZdsfqH+JyixglhcA2Pdu5O5loD6maFlRHqwPDz1SgtESR+DnHQfQEVxCMozZmFFhQ7F1HjJNQyJsxLIfTzaevhxCi2UyTEMwf2Ul/hFcXlpdjThW/QEszPKSaB+phnqOzxmMLirBjKWRa/KMpctxen8NjuzYit4uD47Yt6LX65GUFUM8xoGOOZ4+pZEyBaXlGFtqQWNweamrsWNsqQV5+ZHLi5T+3YYeADhODXd3hWeCUhrVp0d/sgQGowkH/rQRQGCCDVkmPDY/9refVDTTiY5ZqB/dP1ZeSmbey69ip+syOm60AAD+te1NLNv4F95uPP27CR0QmCilCzv3oYmJVh4pfxLTl7zAyx/duQ3NVxri9sEiUf/crdcZ/6T15dg3ZBkx96Xf8nI3rn6NupoPIuZA6XhwHKcecki9a2KVqYt/gVETJvE6/9z0Oro7O6LKPzg+LAsA39SfTci/Dma7PGrCpLjkiDWGB8dPwpS5i3nZE3t2oqWpIeE5iFb8/uQU1ZAjkcwRKuXPv8zrdNxswcHtb8WUNxhNvLy79bps37o7O3Dtq//wuulZprjkiGezbNHPMeQHebz8we1vC+ZgIEFNVkx0AODnOMULZd41HKWydHIfGoPxljm83pUzJ3D5dG1UeTZ7XDj2iWzfLp+uEwQ+v2SaZFCE5KAxA6jPNGL2ivBtize/uYLvLoYJOJDMkVRyKO0Ex3GCfVsiE/P4c7+CISucEQ7/eVNgefFzEaV49tO83P8unseh9/4oKceWb+udqP3bdl5vZGExsnOHDjhzcByHEeMmonjOM5CC0vHgOE7B3UrE1pJZbzkKzi/Pp/QMI6zLV+OTd/8AAOjr9qJ213uYtXx1hOyIcRORXzIVLudJAMCl44fx3aXzKHx8NkYWFgtke7u8aDh+iJcNYXrFi7LmS+5u47GnnkPT2RPw3Grtl34qIY8cd3m/nejEPDy5DCPGTcT1hv8CABqOH0bBtFkRAQeAHy1bhd6uN3lZz61WfPnxLnz58a6YfRiyTJhpW4XcUfmyfJPKJlJIzzRi5rJV2L9praBdrn4qEVhW4qTWu5HCBJmjH+tt+Qu/hiHLyNv41P4Ouj2dEXLpmUbMX/MGpiz4qUA+GgxZRhRMm4VFv9uE0ZPKYi+NDBIZw/CCIhQ9sbDf+qkqBACq6r5V/Iz09rUm9AVvEs5+YBiyHxg2IBsAkDtqjGCHIoXGz4+i8fOjkteGFxRh7LRZsn1pDmYjuX2z6Ovy4va1pn7rpwIEAF4/dlVxcmhQH1R0fK5BbdDIoSEqNHJoiAqNHBqiQiOHhqjQyKEhKjRyaIgKPQD4Ob+DgFgV9kWDyhDIHH4KEO0cTIMQgcxBOQehsCrsiwaVIUgOv0NH1fWrNw3Kg2fEizUn2wi057RpCIACbuYf43N7CYFNQX80qAiUYi+fOVZ8WPewH5xLQX80qAhp0OULPmj87P2DmwlI5P11MkEIoAMBIQAhBDoSfA0CXbCNrYME24M6OhJ4qEdILqAfaAvZAgJ3KPG2CGHqTD+MT+L+WR+DbgR+YYbATTaUAhxo8FdnlG8PPZyHrQfkKThGN1QHgr9xEdgIGAnrhuSZ1xSgUepcsD/Wx2SDgm7ZtWLuGsGTmnw+XRXn81qB2I/xioZwYNhgCAPGB5xARB4RqQBJkgnbpfpj+qCU9yFWf/ykxApWKCiE8EGODB4VBj1olwuRQoIoYfKwwWeuQ4KIov6SC+rU6U1VgMTjDuZsqDZn6f1OIPKf5ceDVIAjySAmTsCFNJEc+EwilA+RQ9IuxHapMPvoIjNRdHJAggQUAGHevdHlBOTguGAQKfwsSUREFNgV22LIIsgeyU0drm5fWsmhyorIBwCGMGfDdrPOl+7o7xMiCfOHTe+hq+HrrAPhZSMsSgR1IvBWyo6wTWxL8P8AxYI8hKk6EFMafs1cCLVSiTa+iVmK2AYqqIq0RHaENihzPXmggJPT37Eeqnwp+qNDWVjXblsH0NUERNviDlJQUDdAtjh+v3K9+Frck685r243+9J9NlDYiPZk6kEDSuEEgV1/R28/tDGcLVj8H+0Tk8ZoBs6XAAAAAElFTkSuQmCC"), //old Bright- transparent),
            //"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAA9CAIAAAAI1O1OAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAACbpJREFUeNrsXHtUFNcZ/+7y3l0ESVQwhEAOsOiKkphF1CVAzAOF2PiAWm0j1ubUUxNj0p6GnBKjTXuCsSXmHDU1rQmaYzwBbGOExKRRiIIvSAQXDCxE0GBZQQWW3WVBmNs/5rGzs7vDsOwu23S+Mx4uc3/3++b+fve7984wDgJhFq9MDJ4SQpYVcyxl0YTYgL6/pVHDlLVNGn484ldiee7aRxapFXMSRWZday2Nmrqz1Z+WfGRXIfuqpGdmbfptviiGZ+T5218Lq05U8KkinxLyx937MpZmiXx50io/r9i29TcGfb8dVeRTQvaWlscrxRRxgY2OE9/apHkhJ5sUxqKKbEpI0cflscq5dtv4IpD7+5Bl8whhHsU/ck4no3/fN13+3Zpso77flzn1sxdfjUiYZ2RJ7CsBRWhAuNRX6ithN75L4PpbZp1pxGs5Jf43x0xEwrw1W1498Kd8KldmL1BvP/w5GzFT6qOaHujvY387oO0bbrg9LE5T7rDt65ZSuZK2ch17eIX6SxZHBPG07BsmsMifeyxt5ToEANLgkPcvdTJn/SSQHSVzlCUA0NI3XC8mijvNFwAeeSLbOlF87EoyPIrbB+5q++8aR8Q8cb8qsxakYtZmzGBDeu/QaEv/SPvAiJAnAqK5RpVpkQ+wTxlH8Oku89QACVnuHSL6hgmRKU8aAoDDbQaRCK/LFXGV+D9V5cDrL3U0NfAAopXzyEKgVB4RE7swa1WQTG4La2+qf//1l8nyG2Wnxox7quRgZclB0v/GHW+zq15b/RgTmlPF34Vf7iiKUSZ5QJXJX73ZmjXX1pwrL1vxfP6sZDUHxr7U8V62I3xHU8PZ8qMLs1cL9+Nuxjw9g4VOmxE6PZxfFQAwm4xH3notb8fbnFGJHZQdMygIX1lSrEhWT7V3YXZ9Yk/MYB6QhQ6RlJ6ZnpvHA2y+WP3J3kKzyQgAVR8XR+/Y7YhmPC5ZMB/ebDJ+sqcwjxPLKVcuMQkjvrsP9kDjORTJ6jRato4rDb3dOrt+YMJxucl6peFcRZlLujDxQ8JMlG49WDeeY4MXZOWETKMmk+9qa2xcWc3vTsdl/DCxqkoO9nbfHNOVB+jyUK6Md4CH0kyZjQaX5Ao4Pv9k3vMBUjkADJkMx/YWuqoLE80VLzRdR5vHYgXK5Ms355Pla1fqL1SUTXr3PZ0rQsL1duuGTNTjhhnRsU774cezTZGsjldRu/CvS4ptFzMnQk98XfGi1X7QaCjdVUCCA6TyKGWSu1d78tenN+cz81jproLJXe09fRfZ16PraKp3VKu9WK2tre7v0ZG/pubmBciCscP7D9fcRWIADChAFpy9Of/orgIAuNnRdrqkODV3Aw/+R3UXqak6oak6IQSpzslTZeVgp+4Kx4Vn8iA+OTVOpW6trQaAM6XFcSr1jJi4SbmLnIR1ZUxLTM9cu323OnfDxCd3gesKczKLnscAoHxf4WStKx7KFSbE/bOToqwfomiqTuh7dOQqsjg3LzE9M1AW7OiqnM4VLCBXACBAFrxsc/6/dhUAQHdH25mSD9T0PIY9mCueeuJCW5QyaXGO1Xy9OGdDXUXpqYN7hkyGU8V7howGDsCKwfE+cYGx8dj6CUqcKjVWpW6rrQaAmtLiWJV6RnQcD95dqhAE4bFswRjbhnt46Sp/qezEuztJIvyDZPOXrXbAoIUPIZfNwmNHeNtLytz0yqGOVn3PTQD4bO+b63f+Y8wuuH5dIdxvDDlkl2xtduqTC1c9Sz3BPbRXd1XryBVblTGtr7uLGeDC/fgHSZ/69e/J2p5r39eUfsDuggfo8pAqnIFm1xas+EXkLOp92k+Ltg0O6G0x9yVYXri93nRpzLh6epMdOWuuI1XsXtJ9CXMfemoFCTh39NDNdq2QLtja6Kgzh7fkCmmpazeRMP2tm1/sf8suxl8qo259urv4gw4O6Du/u0yC/YJk48255Gd+HnzvDBLzxf5dTBfGxa/zuTJKEO4+MD3QCIx5YGH3xySoHyeRV78911pXbYth0uXKmS/5g7bW1Vj+Ap2UwuGLpQq2S6hvoHTJRuqv0beuX73RfNmJXPHuGUxYrhAEsWjNc/5BVDac/HvR4ICeQ3bikuVk7X+aNV+99xdHmvzQVF/90X4SOVORKA+b5sT6FBE/J/Hxn3CWYg/Q5c49GLazF8IEJkb5wvkFSNM3bP1y358BYHjQWH3kvYwNW9mAiPg50UkLOuovAEDL2ZM3WjSKRUtmKiz/52bIZNSe/YoEkLYw91c8feTfU81/ek37pXOG290C8e7fGbthVy6kSw/MS46In9OlbQQA7dmTcSkZbNIB4NH1W4ZMb5IAw+3ub44f+eb4Ebuu/INkaXlbwiKjeYJyUoc7SgKlaeu3VBQVCMS7bmfsaGJ25Wo/vg1M6rMv+AdJqUfrxe8MGgbYtX6B0mUvvfFQ1k8ZjD09pHEpGc/8oShqbjL/DnvMSwqPUyofyxaOn7ghANhe84O77yHvdLYPm4wAIL9nuvye6eNqAgBhkTHM1otjbecr285Xck6GxyljUzL4A+m0jWM6Z2zYZLzT2S4cP0FDALDtzDUQzZvMY09cRBNVEVURTVRFVEU0URXRRFW8XpXrDRciE1UiF96WK3hUTBdvU6VTUxuhfFjkwrtUudFYN594TuTCu1Tpavp2cKA/QBYs0uENNmQcoL6u036hKj5d/H6eV1j7hSrqLWb5veGr3ykVGfEGK3sxh8oVwy3d5eOHE55YKbwxQiABhBAghCQIIQQIkAQBYpUBIQkCBAghkCCEgKqVIPInWQAAkNBVCCG6THujw7H9M6ERAEKAMWAAjDHGQADGGDDG5Bnyk1lMGWOMMSZoMFkG8oUxSxMMADSYxNAFDNimTJBO6dATseZ//9NwS2f5lp7m2IdTYxShkQ8KbE9TxjBlIZEinWKfZJOlH0kxS0vWGY5P2hXGyLFPoGi1xyBpCJFcW7OJLbwDAABB6mEtD60Wwz59niMzy6fT1td5VXPsQ+B8vcg3UJr2cqE0bJowVayItlaCLRUCAB9WLVB5Y8GQqnA9ANsDtqSXxCrP7KkC1hpgAEQPZzu1FlUIgsAAgEcZbVgyWzxgGw/AShdnk8V0p+frovwRswlsvynlGxik2vjKlIgoofMY/Y+ZZyw/EbACUOzZ1DNNbFuxQKyGyBZtMcsEgoF639tCEsU+8woB0HOb5Sz7F2xdtG3FaoIBT+jdE33X9doDO0fMg1ad5Vj0o8sikzP8AqXi2utuu2s2dV6s7Dj9GXes27+RCQgKn5cSPjclODxS5M4dNqDr1F0+r2s4PzI0yKn67wA2+YRpfXP09QAAAABJRU5ErkJggg=="),
          (opts.activeImage =
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAA9CAYAAACHtnoZAAAJnUlEQVR4nO2dW1Ab1xnH/2d1FyBxB2EQl4QQk3G4NuM4iY0ndtw+1e0k6Uwn09FLmb64kzz5sbRPzVMz6UvHM5nhoeOZuvXU6UPGDZ0MnkkcxwVbNjV2sIPBYC4GJCSEQFrQ6YOk1e5qJe0KxK5hf8yB1er8z/nOOd9+5+xFiCAPuj4412EkKOV2UNpJwXutowkIsApCvMnXWxSrt//65zsK9Lnp+uBch4HCQ0D7QEhnPobqaAhKvRRkeJtgMJuzZHWO3l/+9qeExAZ0h9jHUOqllBkYufjp5+K3JJ2j571+J7GYBwnI2cJbp6MFKOgVGol6Rv9+IZDcl+YcPf3nnYZoZJhAjxYHDQrq3TZb+kYvfBwARM7R03/eaYnFhqE7xgGGeiMM0zd64eOAkb/bTowDMEJ3jINNp51iAMBHXOR469wfTjA0NqyaSTqaIkaYPi5ymAwGD2BQzxodTWEAPAQATp3/o5OydFVtg3S0hREA6BY5K+9ymM5BIjGt0D5CdO/QEWIEAEKYJj1y6IhJOAfpU9kOHQ0Sn1b0KUVHgmTkUNsOHQ3yXDkHVduAA8ZzNa08H1buHzQTOQKzk2A31mXltZdXc9uMyQyroyynhg2HEHj6mHtd2XpEkX3hlUWEfc8AACZbEZz1LWl5lh+OcduWklKU1DYoqoPfB85DzTDZixXpdxvNRI7A7CTX+flQ2XoElS+9mvF9djMsGLxseaUI+55xent5NZwNL6Tl4ZfPGE2wOssVDTC/D+wVNTAVlaRn2sO5NR45NBGwd2bD8sMxrC3OovHoaRhM5pzlK28zEWzn0se2WMzfuYHG10/vbh17OFSaiRz8RjvrWySPzCThlUVue21hBpGgHwAQCfrhm3qAqpc6spYff62wzUS0LUMf9i3C9/gBylsOF6yOQqKZNQcfs70ExZWujO/z36tu68TU9X9zDuObvI/qtvRHUsRHodI256tfmriDEpcbZoXrBwKi+rgwcUuI+okPUWZTXdebnDS2xSK4MCOjDqU2IrdegtgWiznvN3n0gfpjwsTtIKoncUxVorUUlcBeUcupI0F/hjr4fb/79vEpb2nntsMri/BN3ldUh9rjQQjR5pojn/k2thXNrpc68pWg0D5HnRvsRghr808AAM++96Kkzg2zXeIMJM86Ck08cmjiJ0U+6s2Aj9MbTJYcNeRXR0orrReXX9/9FpjEmVOMjWLu1tcF7YPd/tHmmkOhTcs/3BNIiypdEuXvcE6XY5/IPQxmK+q7j3N71pcX4rbKqkP9MdHQ2QrPhsScl4vtaAT+Jw+xMPYdt6+o0gV7WaVE8aIjW/G0Ijquc+kTbXAeaoLD1Yjg/DQAYGHsOxRX1cFWWiElStOrSWLNoaoNafinJ7C+NJ8z3/qyMI/JXoz63uPS7ZE4MHdELj0vWNX3HseDq39DjI2vi2ZHr6H11M9l69VCO5GDZwIbDoENhxTJi6pcaOg9AbPUJWekR23F1zmEgSOnnvDyGC1WNPSewPS3QwCAzYAPz+7fQk17j0gkrVcL7ZytKIQxmWErrYCttAKVrUcyOkUKiTWHIpTqhesIZ30zHHWNCM7Fp5fF8VtwHGqCrVRiCpTQq4GG7q2kqGnvQe0rvWn7fVPfY+HeCNhwCDE2CoPJgtr2XhjMlpxlSp1N7IRceqkzGPePTmL8i4vc9DJz8xra3nlXtn6v0dDZSlpMTUvlzS+j7Z33YE0s5oJzUxj/4iKi4ZDMOpCzDnn6/Mo3WKxwv3aSy7IZWMHC+KiiPtjLlLhCyqifBF1PMuYzWmxoPXmWW+3H2Cimvrkqow5R5FBsH+HZJ60Xli/dhtL6F1DFe1xg8d4INld96X2QQb+XKe4cDFE9ibwja16j1Qr30be5W/Mbqyt4evvrrBpzsUMweNHwmiL7QktPOa252CHdBlHkyFRW7ZHXBGukJze/kugD9cdEk/dW5OQvKq9G9cupu69LE3cRmH2cMb+1xCkYOzYcUmRfdH2N01qKHRnaID7ypZPJYkXj0VNc3o3VZSz877+K+6DQKbHmYNRPwq6VpXG9elRwBE7f+A+2WDZjfhvv4tjq7GPZtoX9KwLnsJVV5W4Dyd6GktoGVPEeLZgfu4noelC2fi+SdiJH2npPnq6h9wQn22ajmP52KGPeUt4DRL7JcWz4l2XVMc+7AmswmVHmfnFHkSOZ6jqEzs13QLXHg4scahtBCBEt+OTrytwvCgY9MDuJ1ZlJybw1h7thMFk4R5oYuoyVLLfSN/zLmBi6jMDsJFd+zeHujPkFziGjDSaLFc3HzkAKJX1QqJT8rKykgapBiCKbmt84g7uXP8M2GwEAzIxcg8PVAKPZKshnstjQ/MYZPBr+FwBgm41g6vqXmLr+JUpq6gV5t6IRbPiXBPtsZVU41HlsV9vgcLlRc7gLi/dv56UvJPErpOKVthqIphUlNhmtNtR1vY6Zm8MAgOh6EHN3bwiuKSQpa2pF24/fx6OvPsd2NMLtX1uczVpHTXu3ZHkZYYjsNtR1HYN/5gdEQ7w1hwJ9odDMvZX4Z1HidliKnYptcr3Siw3fEiKJDg77lhANBWERnaUAgNPlRse7v8byo3tYGB8VDoqImvZu1Lb3SJYjhv85FaPZKrsNJosNLW/+BE+91/PSFwoCAL/49B8H+pOGwcTTWmIcLvceW6ItNBM51MRZ16i2CZok7hyMxhakewClBzpYyuK5vWW/UwoWLfeRz+nTym6zj7oyeZ1jGECfqpboqED2MJd62GcfebyOXLIPenzNYSDDoHrk0BESjxwGMoyYHjp0hHAe8avPrvqhf0+bTopV7h/jE+AKCPGoaIyOlqD0CuccRmoa2GZiHhXN0dEQhhgzIFhoeAaH/gSQD3ejcML9AvesBhG8mXqd/iyEOB9PL1srrDNjmTx58qIpBbfB/5M68UtkFJ8IUvF+ytdKl5lNK6w7u353oZ8Mek5/JPimJrO9bICNhvoIdv5tTUqcA6KBEi+NCcnsHHK1oqp5TsEvKTFAogFI5hBfcucGjor0ogx0h9r4371xDgp4TebigbhNIvovjThpbNMLoGknlUge5aIdWZ1AsD9VavrgisqSGTHSy04NFPc67wgiygcqUXYyr7TTpOrM7jS7zBRhrJ0X3u9N/wLAJP2XRpwgW8OEFPb73hSfPCu6VpdhusmD9IGQNzTiAc2vrr2BUnhBjX1JxwBy9Nlv/jn6OwL6IfRT3P3MKgX55C8/6/m9+I2cB1T/pREnMcHDgHqgf6XoPoJ6YyCDlMUgP1rw+T9sxb2thLoYDwAAAABJRU5ErkJggg=="), //index),
          (opts.initialState = indent === listTypeStack.RUN),
          new _this.v(null, opts)
        );
      };
      /**
       * @return {?}
       */
      Tween.prototype._setupRunControl = function () {
        return new CatchEntry();
      };
      /**
       * @param {string} index
       * @param {?} context
       * @return {?}
       */
      Tween.prototype._setupJumpComponent = function (index, context) {
        var item = {};
        return (item.tab = this._setupJumpTab(index)), (item.control = this._setupJumpControl(context)), item;
      };
      /**
       * @param {string} indent
       * @return {?}
       */
      Tween.prototype._setupJumpTab = function (indent) {
        var opts = this._getGenericButtonOptions("JUMP", data.Events.TOGGLE_RUN_JUMP_STATE);
        return (
          (opts.defaultImage =
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAA9CAYAAACHtnoZAAAKrUlEQVR4nO1d21Mb1x3+zrKS0M0SAgHGmJsxF8dgbNzaSScNnXqayUPHmSbNdDKdRJ0mzlNTT/vQyV/Q9iEdnD7VaVon03Gn6YyT5iltnQZnOrUdm5gE24DBIGOwuQoBErK0SKcPQov2pl2BpJXj/WbW6Jzz/c7v23N+57IXzxJoQPcPT7iIqbQHTKILQBcA92Yp6SKCtIFiAAWCAB1IywoCGECCGaDcg77+v59eVquDZCo8/OLrx8EkfATk2e2KNVBcoKAfIsGcuXr2rX8ocWSD4+CPf3aApfQMCOnKnzwDRQFKB9YJ8V37y++/FBdJguObL73+MkDOFESYgSIC9X3+3lvvpucIguPoT375MiFGYDyqoJT6Lv35TT5A+OB4/NU3nmII+nRRZaBokKDoufj2ry8AG8HRfeJXLnuJZQAEDboqM6A/KPzheLSr//Rvl1kAcJY6fARGYBgAADQ4TSYfgFMsADAl7EmS8aLWwKMESnESwCnynV/85gBDMKBqYeCRQoKiiy0xbnAZkEEJ8CwLhvToLcRAEYKghyUEDSp30Q08kqANLAhp0FuGgWIEaWAJYTQQab6VGChCsNB0DZubZYeLhMFFwmk58kFnstpFPHlYnG6UmMwa/Ejrj3MxJNY5SRnDmlC6o0zVtxLiXAzR1aCi3sQ6l1Hbdv3nEiwp4A2O9UgYQf8IuEhY0oCs1Q6T1Y5SpxuOqloE/bcQ32jI9bTGZFgTLDvKUOp0w2x1gJhLZfysIei/JfFj9VTCZLXDtasRodkpPFgNIrqyJAgShjWh6anvywadFgTvjGJx7LpEr8lqR0XzfqxH1rAy7QcXCSMSmFOtz+J0w+apRHnz/i1r2irI02/06rJmTPd/htDcFJ9uPva87MnP3ezH0p0RPl3/rWeyGln3v7qIlekJlNW3onJft6ScWwth8vNPBAFY3tyBir0dIqZ6M8W5GMb7PhIEW82hJ+GsqpXlJ8/tVprf/Zu6ImFEV5YEwe1tPwRPQ6uqjlyB1evOaKmrjA8Om6cSrFl+VDirawXBYXVlN+W6a5uwMj0BZ3Wt7Apqtjvgrm3Cwuggn7fkH4a3RRwc6g21Mj0hWap2VO9W5DurdwuCw9vSKeHM3uzHkj95/vNDX4AA8DS2qWrJBRgQAl0OMbRyt+orCy2JdQ7LU+NZ+0l1YlZ6VbhVjx2GyWrnKXNDXyT3LAXoI4YQAj0OQcNo5QFb96OB46pt4v0sjA5m5Wd5ahxcJCyoQ02v1nOrEM0oAf9IQfqo+GeObEdiJnsVTkXrAf43FwkjmMXssXDrq+Rmd/ce7Xo1nptzZ52AFl1ZKkgfFfRqRdgO0lGzHZ6aH360ZuBY7E64du/B8t3bAIDlu7dRVtes6iO8MAMuEkbVY4ez0quVy5otqrb5AAMQ6HOIoZW7VV9a6icob9rHp9YWZxFemFWtf37kSzCsCe66vVvQq86Nc8JNrsnm2GI7ZHfoNnOIO0XPmSOlhRACq7sctvJqrC3OAAAC40NweHcq1h9ZDmBtcRbe1i6wZkteZo7VmbuCtL1iZ0FmDh2XFeFv5eAQp7MNDu0+UuVV7V2Y+O/HAIDVmUlwkRDMNqesbWD8JgCgrL55IwC169XCjXNRzI9svm5jsjngqqkr0LJSgI2N/GZM0jLb46naa+BspO3eGtgrqnmXc8MDsnaxtRCCk2Nw1zXDbN+RvV4VbpyLYezTj8CthZKdZTKj7sh3UWIuLUgf6besaB1h21xW0qcOZR/Susvq9yK8kFxagpNjqOk8ihLRxnDxdnLWqGo/tGmbjV5R2fUP/gSTzQGzzQEguWQluBgYkxlldXtRc+Cocl15gMYHb/kAEf7WGBxZ6xWuK5m1pAdHQytmh67xo3bh9k1U7TvEl8djUSxNjsJesRNmx46t6RWVdTz3CgAgNH9fkG91eSSBWQiwRKcXfcRelXRo5an5IRp8iMur2rsx1X8BALAwdh3e5v18Jy2O3UCCi6Fq3yGBXTZ6lbhOb42iTSGh354jfdQQaONBhZfJfgscT2PrxmUjkOBiCEyO8mXzY9dhsjngqNy1Pb3bPbc8HjpeygqheCUhGl8PlhdhdVdorjfBxQBA9jJTiwZPQytmb/YDSN5Sr2zpRMA/ggQXw66uJyQ2Yr0Zr1ay4OoB/fYcAr8yo2gDjqpdgnSc4xS5cogsBwAA1jKvuhaZer0tnZgfHUSCi4FbCyHgv4WZG/0w2ZzyT0flZgM1v1q4OkC/+xxpv21l5RlHTYnJjPjGDJCc8bRrDs/dg9Wduf5UiRyHtZSisqUTMzeuAgDuXvkUAFAtc6s8pU+YzuA3C64eKMieI87FEJq/l+xgmfXWWubNaO+qbeS5y9N+zX4jwUWE5u8lR7iWtV+hzJv2QA5IBqu39UBu9hHZcAt8aHzBeOtYj0UxeO4dAIDVXYG2Z36Uagm+oV21e5BJR/X+IwhMJN+VCEwMw9PUDlumZWLD7+Tl/8DqrkBl20EVlUktShpYixWexjYEJoYBAJ7GdrAWq0Jdwjoyt2823MIj7+9zPAgu8M4iwQUEJoZBCEGciwIAdnYcgclSmrGOUqcL9UePAUi+ijfy8d/4euSO0Nw0xj75ALHwCuofP6aqMRZe4fUpcXZ2HOHPo7KtS5HHra0KGjhTndlw9TjyvueweSoFe4a5kQHEwqsIjA+htvtJVKmO6iQq9uwDa7bAf/HfiHMx3Ll0HvcHLydvW6chNDcNADDbnWg59hxsHvkZZi0wjzgXRfDuOD8j3Ll0Hru7vw0gudSlPyovdbpQ3tTO/07HeiyKyNI84rEo7g9eFpTduXQeNR1HUGK2wFrmRTwWRSy8gngsiqn+zyRcJf96gDz/5tm8v2C8FpjH7NA1foSWmC2o6Tyq2HFqWJ2ZwuzwNcRjUUlZidmCqraDcFbLv9SbrknOPgWrR9o56xt8ufxIYF5Vt9WzERyhFU1c/YPjd381/seSAVkUzU0wA8WHvF+tGHh4wRJGYeYwFptHHsozR55WG0qNqHtYUPBnK8Ye5+GBsSE1oAhjQ6obin95ZUHgJyANOut4BJGfGTtXIUdB/SwhjB8EDTmq04DOyFXIEUr8LBjGb+w6DIhBCfwsGKaPUOrTW4yBIgOlAyxFos/YlBoQI07ohwQAXvrjP6+BwPgqk4EkKAbee+XpgywAgEEvMb7OZGADlNBeIG1z6zvzrwmANOTakWSzS8T5RK5YYijHUrt/p+xb2ZCmLgapOD8zNp8KCJlUJiGtiwrzs/SdW1D/Gd/3GgGATWURhvUBuflSE+H/2ewIcaeLg4OI8+XstdqmSok230nId1AqLX4mtJmvbi8OuGxskcE+T/Clfgja86dnL+Tk439yHUlEGaodyedv1kokecISSb4oKpTs00ElHUAF+VIeVcjftJfY8lyFWUZUt1LQ5B7U986LT72bSkma6dX3//dzAvTmyh0R/VUKDqgGh/JysFm3KAgkBOW6FR8WS0ax0EDZLC08lJYJ1eAQ5ecRFDj59gtPnErPk222185dOQ7QM8T40vTXHskvVxPfH37wDcnHhxUn2BPvX3UxJnKSgJ6EESRfRwQpSG+Co72nXzgs++lyTXfOXzt35ThD0AOgBzC+Uv3wgg4A6EtQ9MnNFGL8H97ZbcgrjaGYAAAAAElFTkSuQmCC"), //_img),
          (opts.activeImage =
            "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAA9CAYAAACHtnoZAAAKrUlEQVR4nO1d21Mb1x3+zrKS0M0SAgHGmJsxF8dgbNzaSScNnXqayUPHmSbNdDKdRJ0mzlNTT/vQyV/Q9iEdnD7VaVon03Gn6YyT5iltnQZnOrUdm5gE24DBIGOwuQoBErK0SKcPQov2pl2BpJXj/WbW6Jzz/c7v23N+57IXzxJoQPcPT7iIqbQHTKILQBcA92Yp6SKCtIFiAAWCAB1IywoCGECCGaDcg77+v59eVquDZCo8/OLrx8EkfATk2e2KNVBcoKAfIsGcuXr2rX8ocWSD4+CPf3aApfQMCOnKnzwDRQFKB9YJ8V37y++/FBdJguObL73+MkDOFESYgSIC9X3+3lvvpucIguPoT375MiFGYDyqoJT6Lv35TT5A+OB4/NU3nmII+nRRZaBokKDoufj2ry8AG8HRfeJXLnuJZQAEDboqM6A/KPzheLSr//Rvl1kAcJY6fARGYBgAADQ4TSYfgFMsADAl7EmS8aLWwKMESnESwCnynV/85gBDMKBqYeCRQoKiiy0xbnAZkEEJ8CwLhvToLcRAEYKghyUEDSp30Q08kqANLAhp0FuGgWIEaWAJYTQQab6VGChCsNB0DZubZYeLhMFFwmk58kFnstpFPHlYnG6UmMwa/Ejrj3MxJNY5SRnDmlC6o0zVtxLiXAzR1aCi3sQ6l1Hbdv3nEiwp4A2O9UgYQf8IuEhY0oCs1Q6T1Y5SpxuOqloE/bcQ32jI9bTGZFgTLDvKUOp0w2x1gJhLZfysIei/JfFj9VTCZLXDtasRodkpPFgNIrqyJAgShjWh6anvywadFgTvjGJx7LpEr8lqR0XzfqxH1rAy7QcXCSMSmFOtz+J0w+apRHnz/i1r2irI02/06rJmTPd/htDcFJ9uPva87MnP3ezH0p0RPl3/rWeyGln3v7qIlekJlNW3onJft6ScWwth8vNPBAFY3tyBir0dIqZ6M8W5GMb7PhIEW82hJ+GsqpXlJ8/tVprf/Zu6ImFEV5YEwe1tPwRPQ6uqjlyB1evOaKmrjA8Om6cSrFl+VDirawXBYXVlN+W6a5uwMj0BZ3Wt7Apqtjvgrm3Cwuggn7fkH4a3RRwc6g21Mj0hWap2VO9W5DurdwuCw9vSKeHM3uzHkj95/vNDX4AA8DS2qWrJBRgQAl0OMbRyt+orCy2JdQ7LU+NZ+0l1YlZ6VbhVjx2GyWrnKXNDXyT3LAXoI4YQAj0OQcNo5QFb96OB46pt4v0sjA5m5Wd5ahxcJCyoQ02v1nOrEM0oAf9IQfqo+GeObEdiJnsVTkXrAf43FwkjmMXssXDrq+Rmd/ce7Xo1nptzZ52AFl1ZKkgfFfRqRdgO0lGzHZ6aH360ZuBY7E64du/B8t3bAIDlu7dRVtes6iO8MAMuEkbVY4ez0quVy5otqrb5AAMQ6HOIoZW7VV9a6icob9rHp9YWZxFemFWtf37kSzCsCe66vVvQq86Nc8JNrsnm2GI7ZHfoNnOIO0XPmSOlhRACq7sctvJqrC3OAAAC40NweHcq1h9ZDmBtcRbe1i6wZkteZo7VmbuCtL1iZ0FmDh2XFeFv5eAQp7MNDu0+UuVV7V2Y+O/HAIDVmUlwkRDMNqesbWD8JgCgrL55IwC169XCjXNRzI9svm5jsjngqqkr0LJSgI2N/GZM0jLb46naa+BspO3eGtgrqnmXc8MDsnaxtRCCk2Nw1zXDbN+RvV4VbpyLYezTj8CthZKdZTKj7sh3UWIuLUgf6besaB1h21xW0qcOZR/Susvq9yK8kFxagpNjqOk8ihLRxnDxdnLWqGo/tGmbjV5R2fUP/gSTzQGzzQEguWQluBgYkxlldXtRc+Cocl15gMYHb/kAEf7WGBxZ6xWuK5m1pAdHQytmh67xo3bh9k1U7TvEl8djUSxNjsJesRNmx46t6RWVdTz3CgAgNH9fkG91eSSBWQiwRKcXfcRelXRo5an5IRp8iMur2rsx1X8BALAwdh3e5v18Jy2O3UCCi6Fq3yGBXTZ6lbhOb42iTSGh354jfdQQaONBhZfJfgscT2PrxmUjkOBiCEyO8mXzY9dhsjngqNy1Pb3bPbc8HjpeygqheCUhGl8PlhdhdVdorjfBxQBA9jJTiwZPQytmb/YDSN5Sr2zpRMA/ggQXw66uJyQ2Yr0Zr1ay4OoB/fYcAr8yo2gDjqpdgnSc4xS5cogsBwAA1jKvuhaZer0tnZgfHUSCi4FbCyHgv4WZG/0w2ZzyT0flZgM1v1q4OkC/+xxpv21l5RlHTYnJjPjGDJCc8bRrDs/dg9Wduf5UiRyHtZSisqUTMzeuAgDuXvkUAFAtc6s8pU+YzuA3C64eKMieI87FEJq/l+xgmfXWWubNaO+qbeS5y9N+zX4jwUWE5u8lR7iWtV+hzJv2QA5IBqu39UBu9hHZcAt8aHzBeOtYj0UxeO4dAIDVXYG2Z36Uagm+oV21e5BJR/X+IwhMJN+VCEwMw9PUDlumZWLD7+Tl/8DqrkBl20EVlUktShpYixWexjYEJoYBAJ7GdrAWq0Jdwjoyt2823MIj7+9zPAgu8M4iwQUEJoZBCEGciwIAdnYcgclSmrGOUqcL9UePAUi+ijfy8d/4euSO0Nw0xj75ALHwCuofP6aqMRZe4fUpcXZ2HOHPo7KtS5HHra0KGjhTndlw9TjyvueweSoFe4a5kQHEwqsIjA+htvtJVKmO6iQq9uwDa7bAf/HfiHMx3Ll0HvcHLydvW6chNDcNADDbnWg59hxsHvkZZi0wjzgXRfDuOD8j3Ll0Hru7vw0gudSlPyovdbpQ3tTO/07HeiyKyNI84rEo7g9eFpTduXQeNR1HUGK2wFrmRTwWRSy8gngsiqn+zyRcJf96gDz/5tm8v2C8FpjH7NA1foSWmC2o6Tyq2HFqWJ2ZwuzwNcRjUUlZidmCqraDcFbLv9SbrknOPgWrR9o56xt8ufxIYF5Vt9WzERyhFU1c/YPjd381/seSAVkUzU0wA8WHvF+tGHh4wRJGYeYwFptHHsozR55WG0qNqHtYUPBnK8Ye5+GBsSE1oAhjQ6obin95ZUHgJyANOut4BJGfGTtXIUdB/SwhjB8EDTmq04DOyFXIEUr8LBjGb+w6DIhBCfwsGKaPUOrTW4yBIgOlAyxFos/YlBoQI07ohwQAXvrjP6+BwPgqk4EkKAbee+XpgywAgEEvMb7OZGADlNBeIG1z6zvzrwmANOTakWSzS8T5RK5YYijHUrt/p+xb2ZCmLgapOD8zNp8KCJlUJiGtiwrzs/SdW1D/Gd/3GgGATWURhvUBuflSE+H/2ewIcaeLg4OI8+XstdqmSok230nId1AqLX4mtJmvbi8OuGxskcE+T/Clfgja86dnL+Tk439yHUlEGaodyedv1kokecISSb4oKpTs00ElHUAF+VIeVcjftJfY8lyFWUZUt1LQ5B7U986LT72bSkma6dX3//dzAvTmyh0R/VUKDqgGh/JysFm3KAgkBOW6FR8WS0ax0EDZLC08lJYJ1eAQ5ecRFDj59gtPnErPk222185dOQ7QM8T40vTXHskvVxPfH37wDcnHhxUn2BPvX3UxJnKSgJ6EESRfRwQpSG+Co72nXzgs++lyTXfOXzt35ThD0AOgBzC+Uv3wgg4A6EtQ9MnNFGL8H97ZbcgrjaGYAAAAAElFTkSuQmCC"), //imageNum),
          (opts.initialState = indent === listTypeStack.JUMP),
          new _this.v(null, opts)
        );
      };
      /**
       * @param {?} selector
       * @return {?}
       */
      Tween.prototype._setupJumpControl = function (selector) {
        return new FinallyEntry(null, {
          initialJumpStep: selector,
        });
      };
      /**
       * @param {number} text
       * @param {string} properties
       * @return {?}
       */
      Tween.prototype._getGenericButtonOptions = function (text, properties) {
        return {
          buttonType: _this.b.ButtonTypes.ICON,
          font: "normal 24px Helvetica Neue",
          textColor: "white",
          activeColor: _this.d.COLOR_NEUTRAL_BASE,
          fillColor: _this.d.COLOR_PRIMARY_BASE,
          dimensions: {
            // width height of run jump
            width: 135,
            height: 66,
          },
          buttonText: text,
          toggleEvent: properties,
          clickCallback: function () {
            var form = new doc.a.Event(properties);
            /** @type {!Array} */
            var joined_ids = [this.display.parent.js.runTab.id, this.display.parent.js.jumpTab.id];
            form.set({
              ids: joined_ids,
            });
            _this.f.dispatchEvent(form);
          },
        };
      };
      /**
       * @return {undefined}
       */
      Tween.prototype._placeComponents = function () {
        /** @type {number} */
        this.runTab.x = 0;
        /** @type {number} */
        this.runTab.y = 0;
        this.jumpTab.x = this.runTab.width + 2;
        /** @type {number} */
        this.jumpTab.y = 0;
        /** @type {number} */
        this.runControl.x = 0;
        this.runControl.y = this.runTab.height;
        /** @type {number} */
        this.jumpControl.x = 0;
        this.jumpControl.y = this.jumpTab.height;
      };
      /**
       * @return {undefined}
       */
      Tween.prototype.draw = function () {
        this.runControl.display.visible = this.runTab.stateActive;
        this.jumpControl.display.visible = this.jumpTab.stateActive;
        this.runTab.draw();
        this.jumpTab.draw();
        this.runControl.draw();
        this.jumpControl.draw();
      };
      /**
       * @return {undefined}
       */
      Tween.prototype._bindDispatcherEvents = function () {
        _this.f.on(
          data.Events.TOGGLE_RUN_JUMP_STATE,
          function (options) {
            var deviceOrientationEvent;
            if (req.a.contains(options.ids, this.runTab.id) && req.a.contains(options.ids, this.jumpTab.id)) {
              if (this.controlMode === listTypeStack.RUN) {
                /** @type {string} */
                this.controlMode = listTypeStack.JUMP;
                (deviceOrientationEvent = new doc.a.Event(data.Events.SET_RUN_STATE)).set({
                  ids: [this.runControl.id],
                  newState: CatchEntry.RunStates.RESET,
                });
                _this.f.dispatchEvent(deviceOrientationEvent);
              } else {
                if (this.controlMode === listTypeStack.JUMP) {
                  /** @type {string} */
                  this.controlMode = listTypeStack.RUN;
                }
              }
            }
          },
          this
        );
        _this.f.on(
          data.Events.SET_RUN_STATE,
          function (result) {
            if (req.a.contains(result.ids, this.runControl.id)) {
              /** @type {boolean} */
              this.runControl.play.stateActive = result.newState === CatchEntry.RunStates.PLAY;
              /** @type {boolean} */
              this.runControl.stop.stateActive = result.newState === CatchEntry.RunStates.STOP || result.newState === CatchEntry.RunStates.RESET;
            }
          },
          this
        );
      };
      /**
       * @return {undefined}
       */
      Tween.prototype.drawRunControl = function () {
        if (this.controlMode === listTypeStack.RUN) {
          this.display.graphics.clear().beginFill(BUTTON_BACKGROUND_COLOR);
        } else {
          this.display.graphics.clear().beginFill(BUTTON_BORDER_COLOR);
        }
        this.display.graphics
          .moveTo(0, 8)
          .curveTo(0, 0, 8, 0)
          .lineTo(this.width / 2 - 8 - 2, 0)
          .curveTo(this.width / 2 - 2, 0, this.width / 2 - 2, 8)
          .lineTo(this.width / 2 - 2, this.height / 3)
          .lineTo(this.width, this.height / 3)
          .lineTo(this.width, this.height - 8)
          .curveTo(this.width, this.height, this.width - 8, this.height)
          .lineTo(8, this.height)
          .curveTo(0, this.height, 0, this.height - 8)
          .lineTo(0, 8)
          .closePath();
      };
      /**
       * @return {undefined}
       */
      Tween.prototype.drawJumpControl = function () {
        if (this.controlMode === listTypeStack.JUMP) {
          this.display.graphics.clear().beginFill(BUTTON_BACKGROUND_COLOR);
        } else {
          this.display.graphics.clear().beginFill(BUTTON_BORDER_COLOR);
        }
        this.display.graphics
          .moveTo(this.width, 8)
          .curveTo(this.width, 0, this.width - 8, 0)
          .lineTo(this.width / 2 + 8 + 2, 0)
          .curveTo(this.width / 2 + 2, 0, this.width / 2 + 2, 8)
          .lineTo(this.width / 2 + 2, this.height / 3)
          .lineTo(0, this.height / 3)
          .lineTo(0, this.height - 8)
          .curveTo(0, this.height, 8, this.height)
          .lineTo(this.width - 8, this.height)
          .curveTo(this.width, this.height, this.width, this.height - 8)
          .lineTo(this.width, 8)
          .closePath();
      };
      /**
       * @return {undefined}
       */
      Tween.prototype.delete = function () {
        this.runControl.delete();
        this.jumpControl.delete();
      };
      /**
       * @return {?}
       */
      Tween.prototype.getSaveData = function () {
        var data = this.jumpControl.input.htmlElement.querySelector("input");
        var t = pipe()(data.value, 10);
        return {
          shown: this.display.visible,
          activeTab: this.runTab.stateActive ? "run" : "jump",
          jumpStep: t,
        };
      };
      Tween.ControlModes = listTypeStack;
      var border;
      var descriptionBackground;
      var shape;
      var fulcrum;
      var BUTTON_BACKGROUND_BORDER_COLOR;
      var event = $("KEzc");
      var zoom = $("3xDC");
      var val = $.n(zoom);
      var dir = $("UtpJ");
      var write = $.n(dir);
      var __WEBPACK_IMPORTED_MODULE_17_date_fns_difference_in_minutes__ = $("gA8o");
      var refreshFunc = $.n(__WEBPACK_IMPORTED_MODULE_17_date_fns_difference_in_minutes__);
      var jasmine = {};
      var scope = jasmine;
      var toFloat = new (function () {
        this.shape = new doc.a.Shape();
        this.shape.graphics
          .beginFill("#FF451D")
          .beginStroke()
          .moveTo(-7.1, 7.1)
          .curveTo(-10, 4.1, -10, -0)
          .curveTo(-10, -4.1, -7.1, -7.1)
          .curveTo(-4.1, -10, -0, -10)
          .curveTo(4.1, -10, 7.1, -7.1)
          .curveTo(10, -4.1, 10, -0)
          .curveTo(10, 4.1, 7.1, 7.1)
          .curveTo(4.1, 10, -0, 10)
          .curveTo(-4.1, 10, -7.1, 7.1)
          .closePath();
        this.shape_1 = new doc.a.Shape();
        this.shape_1.graphics
          .beginFill("#FF451D")
          .beginStroke()
          .moveTo(-2.8, 21.3)
          .curveTo(-4, 20.1, -4, 18.5)
          .lineTo(-4, 6.5)
          .curveTo(-4, 4.2, -2, 3)
          .lineTo(-2, -13.5)
          .lineTo(-0, -22.5)
          .lineTo(2, -13.5)
          .lineTo(2, 3)
          .curveTo(4, 4.3, 4, 6.5)
          .lineTo(4, 18.5)
          .curveTo(4, 20.1, 2.8, 21.3)
          .curveTo(1.6, 22.5, -0, 22.5)
          .curveTo(-1.6, 22.5, -2.8, 21.3)
          .closePath();
        this.shape_1.setTransform(0, 22.5);
        this.shape_2 = new doc.a.Shape();
        this.shape_2.graphics
          .beginFill("#FF451D")
          .beginStroke()
          .moveTo(-2, 67.5)
          .lineTo(-1, -76.5)
          .lineTo(1, -76.5)
          .lineTo(2, 67.5)
          .lineTo(-0, 76.5)
          .closePath();
        this.shape_2.setTransform(0, -76.5);
        this.shape_3 = new doc.a.Shape();
        this.shape_3.graphics
          .beginFill("#000000")
          .beginStroke()
          .moveTo(-8.1, 69.7)
          .curveTo(-11.6, 66.5, -11.9, 61.8)
          .lineTo(-17.5, -18.2)
          .curveTo(-17.5, -19.8, -17.3, -21.3)
          .lineTo(-10.2, -61.7)
          .curveTo(-10.2, -66.5, -7.3, -69.7)
          .curveTo(-4.4, -73, -0, -73)
          .curveTo(4.4, -73, 7.3, -69.7)
          .curveTo(10.2, -66.5, 10.2, -61.7)
          .lineTo(17.3, -21.3)
          .curveTo(17.6, -19.8, 17.5, -18.2)
          .lineTo(11.9, 61.8)
          .curveTo(11.6, 66.5, 8.1, 69.7)
          .curveTo(4.7, 73, 0, 73)
          .curveTo(-4.7, 73, -8.1, 69.7)
          .closePath();
        this.shape_3.setTransform(-0.0157, -81.025);
        this.shape_4 = new doc.a.Shape();
        this.shape_4.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.3, 3.2)
          .lineTo(-4.3, -3.3)
          .lineTo(4.3, -3.3)
          .lineTo(4.3, 3.1)
          .lineTo(2.7, 3.1)
          .lineTo(2.7, -1.4)
          .lineTo(0.9, -1.4)
          .lineTo(0.9, 2.8)
          .lineTo(-0.6, 2.8)
          .lineTo(-0.6, -1.4)
          .lineTo(-2.7, -1.4)
          .lineTo(-2.7, 3.2)
          .closePath();
        this.shape_4.setTransform(-0.225, -80.9);
        this.shape_5 = new doc.a.Shape();
        this.shape_5.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(2.7, 3.5)
          .lineTo(2.7, 0.9)
          .lineTo(-4.3, 0.9)
          .lineTo(-4.3, -1)
          .lineTo(2.7, -1)
          .lineTo(2.7, -3.5)
          .lineTo(4.3, -3.5)
          .lineTo(4.3, 3.5)
          .closePath();
        this.shape_5.setTransform(-0.225, -88.625);
        this.shape_6 = new doc.a.Shape();
        this.shape_6.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-0.9, 3.6)
          .curveTo(-2.7, 3.6, -3.5, 2.7)
          .curveTo(-4.4, 1.7, -4.4, 0)
          .curveTo(-4.4, -1.8, -3.5, -2.7)
          .curveTo(-2.7, -3.7, -0.9, -3.7)
          .lineTo(4.4, -3.7)
          .lineTo(4.4, -1.8)
          .lineTo(-0.9, -1.8)
          .lineTo(-1.6, -1.7)
          .curveTo(-2, -1.6, -2.2, -1.5)
          .lineTo(-2.6, -1)
          .curveTo(-2.8, -0.6, -2.8, 0)
          .curveTo(-2.8, 1, -2.3, 1.4)
          .curveTo(-1.9, 1.7, -0.9, 1.7)
          .lineTo(4.4, 1.7)
          .lineTo(4.4, 3.6)
          .closePath();
        this.shape_6.setTransform(-0.325, -96.7);
        this.shape_7 = new doc.a.Shape();
        this.shape_7.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.3, 3.6)
          .lineTo(-4.3, 1.8)
          .lineTo(1.5, -1.8)
          .lineTo(-4.3, -1.8)
          .lineTo(-4.3, -3.6)
          .lineTo(4.3, -3.6)
          .lineTo(4.3, -1.7)
          .lineTo(-1.5, 1.9)
          .lineTo(4.3, 1.9)
          .lineTo(4.3, 3.6)
          .closePath();
        this.shape_7.setTransform(-0.225, -105.55);
        this.shape_8 = new doc.a.Shape();
        this.shape_8.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-4.3, 0.9).lineTo(-4.3, -0.9).lineTo(4.3, -0.9).lineTo(4.3, 0.9).closePath();
        this.shape_8.setTransform(-0.225, -111.725);
        this.shape_9 = new doc.a.Shape();
        this.shape_9.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.3, 4.6)
          .lineTo(-4.3, 2.9)
          .lineTo(1.8, 2.9)
          .lineTo(1.8, 2.8)
          .lineTo(-4.3, 0.7)
          .lineTo(-4.3, -0.7)
          .lineTo(1.7, -2.9)
          .lineTo(-4.3, -2.9)
          .lineTo(-4.3, -4.6)
          .lineTo(4.3, -4.6)
          .lineTo(4.3, -2)
          .lineTo(-1.6, 0)
          .lineTo(4.3, 2)
          .lineTo(4.3, 4.6)
          .closePath();
        this.shape_9.setTransform(-0.225, -118.9);
        this.shape_10 = new doc.a.Shape();
        this.shape_10.graphics
          // NNO Minute hand
          .beginFill("#1ab123")
          .beginStroke()
          .moveTo(-4, 66.5)
          .lineTo(-11, -25.5)
          .curveTo(-3, -28.2, -3, -37.5)
          .lineTo(-3, -72.5)
          .curveTo(-3, -74.1, -2.3, -75.2)
          .curveTo(-1.4, -76.5, -0, -76.5)
          .curveTo(1.4, -76.5, 2.2, -75.2)
          .curveTo(3, -74, 3, -72.5)
          .lineTo(3, -37.5)
          .curveTo(3, -28.2, 11, -25.5)
          .lineTo(4, 66.5)
          .lineTo(-0, 76.5)
          .closePath();
        this.shape_10.setTransform(0, -76.5);
        this.shape_11 = new doc.a.Shape();
        this.shape_11.graphics
          // NNO Minuit hand circle
          .beginFill("#1ab123")
          .beginStroke()
          .moveTo(-8.5, 8.5)
          .curveTo(-12, 5, -12, -0)
          .curveTo(-12, -5, -8.5, -8.5)
          .curveTo(-5, -12, -0, -12)
          .curveTo(5, -12, 8.5, -8.5)
          .curveTo(12, -5, 12, -0)
          .curveTo(12, 5, 8.5, 8.5)
          .curveTo(5, 12, -0, 12)
          .curveTo(-5, 12, -8.5, 8.5)
          .closePath();
        this.shape_12 = new doc.a.Shape();
        this.shape_12.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.3, 1.8)
          .curveTo(-3.9, 1.6, -3.3, 1.6)
          .lineTo(-2.2, 1.5)
          .curveTo(-1.6, 1.4, -1.2, 1.1)
          .curveTo(-0.9, 0.8, -0.9, 0.1)
          .lineTo(-0.9, -1.8)
          .lineTo(-4.3, -1.8)
          .lineTo(-4.3, -3.7)
          .lineTo(4.3, -3.7)
          .lineTo(4.3, 0.9)
          .curveTo(4.3, 1.5, 4.1, 2)
          .curveTo(3.9, 2.4, 3.6, 2.8)
          .curveTo(3.3, 3.1, 2.8, 3.3)
          .curveTo(2.4, 3.4, 1.9, 3.4)
          .curveTo(1.2, 3.4, 0.6, 3.1)
          .curveTo(0.1, 2.8, -0.2, 2.1)
          .lineTo(-0.5, 2.7)
          .lineTo(-1, 3)
          .lineTo(-1.6, 3.2)
          .lineTo(-2.2, 3.3)
          .lineTo(-2.7, 3.3)
          .lineTo(-3.8, 3.5)
          .lineTo(-4.3, 3.7)
          .closePath()
          .moveTo(0.4, 0.3)
          .curveTo(0.4, 0.9, 0.7, 1.2)
          .curveTo(1, 1.5, 1.6, 1.5)
          .curveTo(2.3, 1.5, 2.5, 1.2)
          .curveTo(2.8, 0.9, 2.8, 0.3)
          .lineTo(2.8, -1.8)
          .lineTo(0.4, -1.8)
          .closePath();
        this.shape_12.setTransform(-0.225, -74.125);
        this.shape_13 = new doc.a.Shape();
        this.shape_13.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-0.9, 3.7)
          .curveTo(-2.7, 3.7, -3.5, 2.7)
          .curveTo(-4.4, 1.7, -4.4, -0)
          .curveTo(-4.4, -1.7, -3.5, -2.7)
          .curveTo(-2.7, -3.6, -0.9, -3.6)
          .lineTo(4.4, -3.6)
          .lineTo(4.4, -1.7)
          .lineTo(-0.9, -1.7)
          .lineTo(-1.6, -1.7)
          .curveTo(-2, -1.7, -2.2, -1.5)
          .lineTo(-2.6, -0.9)
          .curveTo(-2.8, -0.6, -2.8, -0)
          .curveTo(-2.8, 1, -2.3, 1.4)
          .curveTo(-1.9, 1.8, -0.9, 1.8)
          .lineTo(4.4, 1.8)
          .lineTo(4.4, 3.7)
          .closePath();
        this.shape_13.setTransform(-0.325, -83.05);
        this.shape_14 = new doc.a.Shape();
        this.shape_14.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-1.8, 3.9)
          .curveTo(-2.6, 3.6, -3.2, 3.1)
          .curveTo(-3.8, 2.5, -4.1, 1.8)
          .curveTo(-4.5, 1, -4.5, -0)
          .curveTo(-4.5, -1, -4.1, -1.8)
          .curveTo(-3.8, -2.6, -3.2, -3.1)
          .curveTo(-2.6, -3.6, -1.8, -3.9)
          .curveTo(-1, -4.2, -0, -4.2)
          .curveTo(0.9, -4.2, 1.8, -3.9)
          .curveTo(2.6, -3.6, 3.2, -3.1)
          .curveTo(3.8, -2.6, 4.2, -1.8)
          .curveTo(4.5, -1, 4.5, -0)
          .curveTo(4.5, 1, 4.2, 1.8)
          .curveTo(3.8, 2.5, 3.2, 3.1)
          .curveTo(2.6, 3.6, 1.8, 3.9)
          .curveTo(0.9, 4.2, -0, 4.2)
          .curveTo(-1, 4.2, -1.8, 3.9)
          .closePath()
          .moveTo(-1.1, -2.2)
          .lineTo(-2, -1.8)
          .curveTo(-2.4, -1.5, -2.6, -1.1)
          .curveTo(-2.9, -0.6, -2.9, -0)
          .curveTo(-2.9, 0.6, -2.6, 1.1)
          .curveTo(-2.4, 1.5, -2, 1.8)
          .curveTo(-1.6, 2.1, -1.1, 2.2)
          .curveTo(-0.6, 2.3, -0, 2.3)
          .lineTo(1.1, 2.2)
          .curveTo(1.6, 2.1, 2, 1.8)
          .curveTo(2.4, 1.5, 2.7, 1.1)
          .curveTo(2.9, 0.6, 2.9, -0)
          .curveTo(2.9, -0.6, 2.7, -1.1)
          .curveTo(2.4, -1.5, 2, -1.8)
          .lineTo(1.1, -2.2)
          .lineTo(-0, -2.3)
          .lineTo(-1.1, -2.2)
          .closePath();
        this.shape_14.setTransform(-0.225, -92.125);
        this.shape_15 = new doc.a.Shape();
        this.shape_15.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.3, 3.6)
          .lineTo(-4.3, 1.7)
          .lineTo(-0.6, 1.7)
          .lineTo(-0.6, -1.8)
          .lineTo(-4.3, -1.8)
          .lineTo(-4.3, -3.6)
          .lineTo(4.3, -3.6)
          .lineTo(4.3, -1.8)
          .lineTo(1, -1.8)
          .lineTo(1, 1.7)
          .lineTo(4.3, 1.7)
          .lineTo(4.3, 3.6)
          .closePath();
        this.shape_15.setTransform(-0.225, -101.2);
        this.shape_16 = new doc.a.Shape();
        this.shape_16.graphics
          .beginFill("#000000")
          .beginStroke()
          .moveTo(-9.1, 48)
          .curveTo(-12.7, 44.6, -13.2, 39.8)
          .lineTo(-19, -9.3)
          .curveTo(-19.2, -11, -15.3, -24.1)
          .curveTo(-12.7, -32.8, -10.1, -40.8)
          .curveTo(-9.7, -45.1, -6.9, -48.2)
          .curveTo(-3.9, -51.5, 0, -51.5)
          .curveTo(3.9, -51.5, 6.9, -48.2)
          .curveTo(9.7, -45.1, 10.1, -40.8)
          .curveTo(12.7, -32.8, 15.3, -24.1)
          .curveTo(19.2, -11, 19, -9.3)
          .lineTo(13.2, 39.8)
          .curveTo(12.7, 44.6, 9.1, 48)
          .curveTo(5.3, 51.5, 0, 51.5)
          .curveTo(-5.2, 51.5, -9.1, 48)
          .closePath();
        this.shape_16.setTransform(-0.0224, -59.5);
        this.shape_17 = new doc.a.Shape();
        // NNO hour hand
        this.shape_17.graphics
          .beginFill("#ff0038")
          .beginStroke()
          .moveTo(-9.9, 9.9)
          .curveTo(-14, 5.8, -14, -0)
          .curveTo(-14, -5.8, -9.9, -9.9)
          .curveTo(-5.8, -14, -0, -14)
          .curveTo(5.8, -14, 9.9, -9.9)
          .curveTo(14, -5.8, 14, -0)
          .curveTo(14, 5.8, 9.9, 9.9)
          .curveTo(5.8, 14, -0, 14)
          .curveTo(-5.8, 14, -9.9, 9.9)
          .closePath();
        //console.log("HAND: ",this.shape_17); //Vikas
        this.shape_18 = new doc.a.Shape();
        this.shape_18.graphics
          // NNO hour hand circle
          .beginFill("#ff0038")
          .beginStroke()
          .moveTo(-5.4, 43)
          .lineTo(-13, -17)
          .curveTo(-7.3, -19.9, -5, -23.1)
          .curveTo(-3, -26, -3, -30.5)
          .lineTo(-3, -51)
          .curveTo(-3, -52.6, -2.3, -53.7)
          .curveTo(-1.4, -55, -0, -55)
          .curveTo(1.4, -55, 2.2, -53.7)
          .curveTo(3, -52.6, 3, -51)
          .lineTo(3, -30.5)
          .curveTo(3, -26, 5, -23.1)
          .curveTo(7.2, -19.9, 13, -17)
          .lineTo(5.4, 43)
          .lineTo(-0, 55)
          .closePath();
        this.shape_18.setTransform(0, -55);
        this.shape_19 = new doc.a.Shape();
        this.shape_19.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(16.5, 21.4)
          .curveTo(14.2, 21.2, 12.5, 19.6)
          .curveTo(7.3, 14.5, 0, 14.5)
          .curveTo(-7.3, 14.5, -12.5, 19.6)
          .curveTo(-14.2, 21.2, -16.5, 21.4)
          .curveTo(-18.7, 21.7, -20.7, 20.5)
          .lineTo(-40.3, 9.3)
          .curveTo(-43, 7.7, -43.6, 4.6)
          .curveTo(-44.3, 1.5, -42.3, -1)
          .curveTo(-34.8, -10.5, -23.9, -15.9)
          .curveTo(-12.6, -21.5, 0, -21.5)
          .curveTo(12.7, -21.5, 23.9, -15.9)
          .curveTo(34.8, -10.5, 42.3, -1)
          .curveTo(44.3, 1.5, 43.6, 4.6)
          .curveTo(43, 7.7, 40.3, 9.3)
          .lineTo(20.7, 20.5)
          .curveTo(19.1, 21.5, 17.3, 21.5)
          .lineTo(16.5, 21.4)
          .closePath();
        this.shape_19.setTransform(-0.025, -32.0277);
        this.shape_20 = new doc.a.Shape();
        this.shape_20.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-23.1, 9.4)
          .curveTo(-25.1, 8.2, -25.5, 6)
          .curveTo(-25.9, 3.9, -24.6, 2.1)
          .curveTo(-17.1, -7.3, -6.4, -12.5)
          .curveTo(4.2, -17.6, 16.2, -17.6)
          .curveTo(20.9, -17.6, 25.6, -16.8)
          .curveTo(11.8, -10.8, 2.9, -2)
          .curveTo(-6.3, 7, -8.9, 17.6)
          .closePath();
        this.shape_20.setTransform(-16.2312, -33.9);
        this.shape_21 = new doc.a.Shape();
        this.shape_21.graphics
          .beginFill("#D8E9E9")
          .beginStroke()
          .moveTo(-1.3, 50)
          .curveTo(-4.3, 50, -6.1, 42.8)
          .lineTo(-7.1, 38.8)
          .curveTo(-7.4, 37.9, -7.9, 37.1)
          .curveTo(-9.9, 36.7, -11.7, 36.1)
          .curveTo(-12.7, 36.6, -13.2, 37.1)
          .lineTo(-16.1, 40.1)
          .curveTo(-21.3, 45.4, -24, 43.9)
          .lineTo(-26.1, 42.6)
          .curveTo(-28.7, 41.2, -26.8, 34.1)
          .lineTo(-25.6, 29.9)
          .curveTo(-25.4, 29.1, -25.5, 28.1)
          .lineTo(-28.2, 25.4)
          .curveTo(-29.1, 25.3, -30, 25.5)
          .lineTo(-34.1, 26.7)
          .curveTo(-41.2, 28.7, -42.7, 26.1)
          .lineTo(-43.9, 23.9)
          .curveTo(-45.5, 21.3, -40.2, 16.1)
          .lineTo(-37.2, 13.2)
          .curveTo(-36.6, 12.6, -36.1, 11.7)
          .curveTo(-36.8, 9.8, -37.2, 7.9)
          .curveTo(-38, 7.4, -38.8, 7.1)
          .lineTo(-42.9, 6.1)
          .curveTo(-50, 4.3, -50, 1.2)
          .lineTo(-50, -1.3)
          .curveTo(-50, -4.3, -42.9, -6.1)
          .lineTo(-38.8, -7.1)
          .curveTo(-38, -7.4, -37.2, -7.9)
          .curveTo(-36.8, -9.9, -36.1, -11.7)
          .curveTo(-36.6, -12.7, -37.2, -13.2)
          .lineTo(-40.2, -16.1)
          .curveTo(-45.5, -21.3, -43.9, -24)
          .lineTo(-42.7, -26.1)
          .curveTo(-41.2, -28.7, -34.1, -26.8)
          .lineTo(-30, -25.6)
          .curveTo(-29.1, -25.4, -28.2, -25.5)
          .lineTo(-25.5, -28.2)
          .curveTo(-25.4, -29.1, -25.6, -30)
          .lineTo(-26.8, -34.1)
          .curveTo(-28.7, -41.2, -26.1, -42.7)
          .lineTo(-24, -43.9)
          .curveTo(-21.3, -45.5, -16.1, -40.2)
          .lineTo(-13.2, -37.2)
          .curveTo(-12.7, -36.6, -11.7, -36.1)
          .curveTo(-9.9, -36.8, -7.9, -37.2)
          .curveTo(-7.4, -38, -7.1, -38.8)
          .lineTo(-6.1, -42.9)
          .curveTo(-4.3, -50, -1.3, -50)
          .lineTo(1.2, -50)
          .curveTo(4.3, -50, 6.1, -42.9)
          .lineTo(7.1, -38.8)
          .curveTo(7.4, -38, 7.9, -37.2)
          .curveTo(9.8, -36.8, 11.7, -36.1)
          .curveTo(12.6, -36.6, 13.2, -37.2)
          .lineTo(16.1, -40.2)
          .curveTo(21.3, -45.5, 23.9, -43.9)
          .lineTo(26.1, -42.7)
          .curveTo(28.7, -41.2, 26.7, -34.1)
          .lineTo(25.5, -30)
          .curveTo(25.3, -29.1, 25.4, -28.2)
          .curveTo(26.9, -26.9, 28.1, -25.5)
          .curveTo(29.1, -25.4, 29.9, -25.6)
          .lineTo(34.1, -26.8)
          .curveTo(41.2, -28.7, 42.6, -26.1)
          .lineTo(43.9, -24)
          .curveTo(45.4, -21.3, 40.1, -16.1)
          .lineTo(37.1, -13.2)
          .curveTo(36.6, -12.7, 36.1, -11.7)
          .curveTo(36.7, -9.9, 37.1, -7.9)
          .curveTo(37.9, -7.4, 38.8, -7.1)
          .lineTo(42.8, -6.1)
          .curveTo(50, -4.3, 50, -1.3)
          .lineTo(50, 1.2)
          .curveTo(50, 4.3, 42.8, 6.1)
          .lineTo(38.8, 7.1)
          .curveTo(37.9, 7.4, 37.1, 7.9)
          .curveTo(36.7, 9.8, 36.1, 11.7)
          .curveTo(36.6, 12.6, 37.1, 13.2)
          .lineTo(40.1, 16.1)
          .curveTo(45.4, 21.3, 43.9, 23.9)
          .lineTo(42.6, 26.1)
          .curveTo(41.2, 28.7, 34.1, 26.7)
          .lineTo(29.9, 25.5)
          .curveTo(29.1, 25.3, 28.1, 25.4)
          .curveTo(26.9, 26.9, 25.4, 28.1)
          .curveTo(25.3, 29.1, 25.5, 29.9)
          .lineTo(26.7, 34.1)
          .curveTo(28.7, 41.2, 26.1, 42.6)
          .lineTo(23.9, 43.9)
          .curveTo(21.3, 45.4, 16.1, 40.1)
          .lineTo(13.2, 37.1)
          .curveTo(12.6, 36.6, 11.7, 36.1)
          .curveTo(9.8, 36.7, 7.9, 37.1)
          .curveTo(7.4, 37.9, 7.1, 38.8)
          .lineTo(6.1, 42.8)
          .curveTo(4.3, 50, 1.2, 50)
          .closePath()
          .moveTo(-15.6, -15.6)
          .curveTo(-22, -9.1, -22, -0)
          .curveTo(-22, 9.1, -15.6, 15.6)
          .curveTo(-9.1, 22, -0, 22)
          .curveTo(9.1, 22, 15.6, 15.6)
          .curveTo(22, 9.1, 22, -0)
          .curveTo(22, -9.1, 15.6, -15.6)
          .curveTo(9.1, -22, -0, -22)
          .curveTo(-9.1, -22, -15.6, -15.6)
          .closePath();
        this.shape_22 = new doc.a.Shape();
        this.shape_22.graphics
          .beginFill("")
          .beginStroke()
          .moveTo(-157.5, 157.5)
          .lineTo(-157.5, -157.5)
          .lineTo(157.5, -157.5)
          .lineTo(157.5, 157.5)
          .closePath();
        this.shape_23 = new doc.a.Shape();
        this.shape_23.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.7, 13.6)
          .lineTo(-4.7, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.5)
          .curveTo(-2.5, 12.1, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11, -2.3, -11.6)
          .curveTo(-2.5, -12.2, -3, -12.5)
          .curveTo(-3.4, -12.9, -4.1, -12.9)
          .lineTo(-4.7, -12.9)
          .lineTo(-4.7, -13.6)
          .lineTo(4.8, -13.6)
          .lineTo(4.8, -12.9)
          .lineTo(4.2, -12.9)
          .curveTo(3.3, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.1, 2.4, -11.5)
          .curveTo(2.2, -11, 2.2, -9)
          .lineTo(2.2, 9)
          .curveTo(2.2, 11.1, 2.4, 11.6)
          .curveTo(2.5, 12.1, 3, 12.5)
          .curveTo(3.3, 12.9, 4.2, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_23.setTransform(60.8, -107.075);
        this.shape_24 = new doc.a.Shape();
        this.shape_24.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.7, 13.6)
          .lineTo(-4.7, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.3, 12.9, -2.8, 12.5)
          .curveTo(-2.5, 12.1, -2.4, 11.5)
          .curveTo(-2.2, 11, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11, -2.4, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.4, -12.9, -4.2, -12.9)
          .lineTo(-4.7, -12.9)
          .lineTo(-4.7, -13.6)
          .lineTo(4.7, -13.6)
          .lineTo(4.7, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.1, 2.3, -11.5)
          .curveTo(2.2, -11, 2.2, -9)
          .lineTo(2.2, 9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 2.9, 12.5)
          .curveTo(3.3, 12.9, 4.1, 12.9)
          .lineTo(4.7, 12.9)
          .lineTo(4.7, 13.6)
          .closePath();
        this.shape_24.setTransform(110.35, -62.375);
        this.shape_25 = new doc.a.Shape();
        this.shape_25.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.5)
          .curveTo(-2.5, 12.1, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.5, -12.9, -4.1, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.6)
          .lineTo(4.8, -13.6)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.1, 2.3, -11.5)
          .curveTo(2.2, -11, 2.2, -9)
          .lineTo(2.2, 9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 3, 12.5)
          .curveTo(3.3, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_25.setTransform(101.05, -62.375);
        this.shape_26 = new doc.a.Shape();
        this.shape_26.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.4, 12.9, -2.9, 12.4)
          .curveTo(-2.5, 12.2, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.4, -12.9, -4.1, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.7)
          .lineTo(4.8, -13.7)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.1, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 3, 12.5)
          .curveTo(3.5, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_26.setTransform(131.65, -0.85);
        this.shape_27 = new doc.a.Shape();
        this.shape_27.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.7, 13.6)
          .lineTo(-4.7, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.4)
          .curveTo(-2.5, 12.2, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.3, -12.9, -4.1, -12.9)
          .lineTo(-4.7, -12.9)
          .lineTo(-4.7, -13.7)
          .lineTo(4.7, -13.7)
          .lineTo(4.7, -12.9)
          .lineTo(4.2, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.1, 2.4, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.4, 11.6)
          .curveTo(2.5, 12.1, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.2, 12.9)
          .lineTo(4.7, 12.9)
          .lineTo(4.7, 13.6)
          .closePath();
        this.shape_27.setTransform(122.35, -0.85);
        this.shape_28 = new doc.a.Shape();
        this.shape_28.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.7, 13.6)
          .lineTo(-4.7, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.4, 12.9, -2.8, 12.4)
          .curveTo(-2.5, 12.2, -2.3, 11.5)
          .curveTo(-2.2, 10.9, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .lineTo(-2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.7, -12.9)
          .lineTo(-4.7, -13.7)
          .lineTo(4.7, -13.7)
          .lineTo(4.7, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.6, -12.3, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.7, 12.9)
          .lineTo(4.7, 13.6)
          .closePath();
        this.shape_28.setTransform(113.05, -0.85);
        this.shape_29 = new doc.a.Shape();
        this.shape_29.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-0.5, 14)
          .lineTo(-6.7, -7.7)
          .curveTo(-7.9, -11.7, -8.2, -12.3)
          .curveTo(-8.6, -13.1, -9.7, -13.2)
          .lineTo(-9.7, -13.9)
          .lineTo(-0.9, -13.9)
          .lineTo(-0.9, -13.2)
          .lineTo(-1.2, -13.2)
          .curveTo(-2.4, -13.2, -2.8, -12.8)
          .curveTo(-3.2, -12.4, -3.2, -11.9)
          .lineTo(-3, -11)
          .lineTo(1.6, 5.2)
          .lineTo(5.9, -9.9)
          .lineTo(6.1, -11.1)
          .curveTo(6.1, -11.8, 5.9, -12.1)
          .curveTo(5.6, -12.6, 5.2, -12.9)
          .curveTo(4.7, -13.2, 3.7, -13.2)
          .lineTo(3.7, -13.9)
          .lineTo(9.7, -13.9)
          .lineTo(9.7, -13.2)
          .curveTo(8.7, -13, 7.9, -11.6)
          .curveTo(7.4, -10.7, 6.2, -6.9)
          .lineTo(-0, 14)
          .closePath();
        this.shape_29.setTransform(111.175, 62.25);
        this.shape_30 = new doc.a.Shape();
        this.shape_30.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.7, 13.6)
          .lineTo(-4.7, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.4, 12.9, -2.8, 12.5)
          .curveTo(-2.5, 12.2, -2.3, 11.5)
          .curveTo(-2.2, 10.9, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .lineTo(-2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.7, -12.9)
          .lineTo(-4.7, -13.6)
          .lineTo(4.7, -13.6)
          .lineTo(4.7, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.6, -12.3, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.2, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.7, 12.9)
          .lineTo(4.7, 13.6)
          .closePath();
        this.shape_30.setTransform(97.3, 61.95);
        this.shape_31 = new doc.a.Shape();
        this.shape_31.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-0.5, 13.9)
          .lineTo(-6.7, -7.7)
          .curveTo(-7.9, -11.8, -8.3, -12.3)
          .curveTo(-8.7, -13.1, -9.7, -13.2)
          .lineTo(-9.7, -14)
          .lineTo(-1, -14)
          .lineTo(-1, -13.2)
          .lineTo(-1.3, -13.2)
          .curveTo(-2.4, -13.2, -2.9, -12.8)
          .curveTo(-3.2, -12.4, -3.2, -11.9)
          .lineTo(-3.1, -11.1)
          .lineTo(1.5, 5.2)
          .lineTo(5.9, -9.8)
          .lineTo(6.1, -11.1)
          .curveTo(6.1, -11.7, 5.8, -12.2)
          .curveTo(5.6, -12.6, 5.2, -12.9)
          .curveTo(4.7, -13.2, 3.7, -13.2)
          .lineTo(3.7, -14)
          .lineTo(9.7, -14)
          .lineTo(9.7, -13.2)
          .curveTo(8.6, -13, 7.9, -11.6)
          .curveTo(7.2, -10.4, 6.2, -6.9)
          .lineTo(-0.1, 13.9)
          .closePath();
        this.shape_31.setTransform(62.075, 107.35);
        this.shape_32 = new doc.a.Shape();
        this.shape_32.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.4, 12.9, -2.9, 12.5)
          .curveTo(-2.6, 12.3, -2.3, 11.5)
          .curveTo(-2.2, 11.1, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.4, -12.9, -4.1, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.6)
          .lineTo(4.8, -13.6)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.2, 2.3, -11.5)
          .curveTo(2.1, -11.1, 2.2, -9)
          .lineTo(2.2, 9)
          .curveTo(2.1, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.2, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_32.setTransform(10.05, 123.15);
        this.shape_33 = new doc.a.Shape();
        this.shape_33.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-0.5, 14)
          .lineTo(-6.7, -7.7)
          .curveTo(-7.9, -11.7, -8.2, -12.3)
          .curveTo(-8.6, -13.1, -9.7, -13.2)
          .lineTo(-9.7, -13.9)
          .lineTo(-1, -13.9)
          .lineTo(-1, -13.2)
          .lineTo(-1.2, -13.2)
          .curveTo(-2.4, -13.2, -2.9, -12.8)
          .curveTo(-3.2, -12.5, -3.2, -11.9)
          .lineTo(-3.1, -11.1)
          .lineTo(1.5, 5.2)
          .lineTo(5.1, -6.9)
          .curveTo(5.7, -8.8, 5.9, -9.9)
          .lineTo(6.1, -11.1)
          .curveTo(6.1, -11.8, 5.9, -12.1)
          .curveTo(5.6, -12.6, 5.2, -12.9)
          .curveTo(4.7, -13.2, 3.7, -13.2)
          .lineTo(3.7, -13.9)
          .lineTo(9.7, -13.9)
          .lineTo(9.7, -13.2)
          .curveTo(8.7, -13, 7.9, -11.6)
          .curveTo(7.4, -10.7, 6.2, -6.9)
          .lineTo(-0, 14)
          .closePath();
        this.shape_33.setTransform(-3.825, 123.45);
        this.shape_34 = new doc.a.Shape();
        this.shape_34.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.5)
          .curveTo(-2.6, 12.3, -2.4, 11.5)
          .curveTo(-2.2, 11.1, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.4, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.7)
          .lineTo(4.8, -13.7)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.2, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.1, -9)
          .lineTo(2.1, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 3, 12.5)
          .curveTo(3.5, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_34.setTransform(-46.45, 107.05);
        this.shape_35 = new doc.a.Shape();
        this.shape_35.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.4, 12.9, -2.9, 12.5)
          .curveTo(-2.5, 12.2, -2.3, 11.5)
          .curveTo(-2.2, 11.1, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.4, -12.9, -4.1, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.7)
          .lineTo(4.8, -13.7)
          .lineTo(4.8, -12.9)
          .lineTo(4.2, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.2, 2.4, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.4, 11.6)
          .curveTo(2.5, 12.1, 3, 12.5)
          .curveTo(3.4, 12.9, 4.2, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_35.setTransform(-55.75, 107.05);
        this.shape_36 = new doc.a.Shape();
        this.shape_36.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-0.5, 13.9)
          .lineTo(-6.7, -7.7)
          .curveTo(-7.9, -11.7, -8.2, -12.3)
          .curveTo(-8.6, -13.1, -9.7, -13.2)
          .lineTo(-9.7, -14)
          .lineTo(-0.9, -14)
          .lineTo(-0.9, -13.2)
          .lineTo(-1.2, -13.2)
          .curveTo(-2.4, -13.2, -2.8, -12.8)
          .curveTo(-3.2, -12.4, -3.2, -11.9)
          .lineTo(-3, -11.1)
          .lineTo(1.6, 5.2)
          .lineTo(5.9, -9.8)
          .lineTo(6.1, -11.1)
          .curveTo(6.1, -11.8, 5.9, -12.2)
          .curveTo(5.6, -12.6, 5.2, -12.9)
          .curveTo(4.7, -13.2, 3.7, -13.2)
          .lineTo(3.7, -14)
          .lineTo(9.7, -14)
          .lineTo(9.7, -13.2)
          .curveTo(8.7, -13, 7.9, -11.6)
          .curveTo(7.4, -10.8, 6.2, -6.9)
          .lineTo(-0, 13.9)
          .closePath();
        this.shape_36.setTransform(-69.625, 107.35);
        this.shape_37 = new doc.a.Shape();
        this.shape_37.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.7, 13.6)
          .lineTo(-4.7, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.4, 12.9, -2.8, 12.5)
          .curveTo(-2.5, 12.2, -2.3, 11.5)
          .curveTo(-2.2, 11.2, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.3, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.7, -12.9)
          .lineTo(-4.7, -13.6)
          .lineTo(4.7, -13.6)
          .lineTo(4.7, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.6, -12.3, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.2, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.7, 12.9)
          .lineTo(4.7, 13.6)
          .closePath();
        this.shape_37.setTransform(-86.75, 61.95);
        this.shape_38 = new doc.a.Shape();
        this.shape_38.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.5)
          .curveTo(-2.6, 12.3, -2.3, 11.5)
          .curveTo(-2.2, 11.1, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.6)
          .lineTo(4.8, -13.6)
          .lineTo(4.8, -12.9)
          .lineTo(4.2, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.6, -12.3, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.2, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.2, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_38.setTransform(-96.025, 61.95);
        this.shape_39 = new doc.a.Shape();
        this.shape_39.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.5)
          .curveTo(-2.6, 12.3, -2.4, 11.5)
          .curveTo(-2.2, 11.1, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.4, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.6)
          .lineTo(4.7, -13.6)
          .lineTo(4.7, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.6, -12.2, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.1, -9)
          .lineTo(2.1, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.2, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.7, 12.9)
          .lineTo(4.7, 13.6)
          .closePath();
        this.shape_39.setTransform(-105.3, 61.95);
        this.shape_40 = new doc.a.Shape();
        this.shape_40.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-0.5, 14)
          .lineTo(-6.7, -7.7)
          .curveTo(-7.9, -11.7, -8.2, -12.3)
          .curveTo(-8.6, -13.1, -9.7, -13.2)
          .lineTo(-9.7, -13.9)
          .lineTo(-1, -13.9)
          .lineTo(-1, -13.2)
          .lineTo(-1.2, -13.2)
          .curveTo(-2.4, -13.2, -2.9, -12.8)
          .curveTo(-3.2, -12.5, -3.2, -11.9)
          .lineTo(-3.1, -11)
          .lineTo(1.5, 5.2)
          .lineTo(5.1, -6.9)
          .curveTo(5.7, -8.8, 5.9, -9.9)
          .lineTo(6.1, -11.1)
          .curveTo(6.1, -11.8, 5.9, -12.1)
          .curveTo(5.6, -12.6, 5.2, -12.9)
          .curveTo(4.7, -13.2, 3.7, -13.2)
          .lineTo(3.7, -13.9)
          .lineTo(9.7, -13.9)
          .lineTo(9.7, -13.2)
          .curveTo(8.7, -13, 7.9, -11.6)
          .curveTo(7.4, -10.7, 6.2, -6.9)
          .lineTo(-0, 14)
          .closePath();
        this.shape_40.setTransform(-119.175, 62.25);
        this.shape_41 = new doc.a.Shape();
        this.shape_41.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(0.9, 13.6)
          .lineTo(0.9, 12.9)
          .curveTo(1.9, 12.8, 2.2, 12.4)
          .curveTo(2.6, 11.9, 2.6, 11.5)
          .lineTo(2.5, 10.9)
          .lineTo(-1.1, 2.7)
          .lineTo(-3.9, 7.8)
          .curveTo(-5.2, 10.2, -5.2, 10.9)
          .curveTo(-5.2, 11.5, -4.8, 12.1)
          .curveTo(-4.6, 12.5, -3.9, 12.7)
          .curveTo(-3.6, 12.9, -2.7, 12.9)
          .lineTo(-2.7, 13.6)
          .lineTo(-9.7, 13.6)
          .lineTo(-9.7, 12.9)
          .curveTo(-8.5, 12.6, -7.8, 11.9)
          .curveTo(-7.1, 11.2, -5.3, 8)
          .lineTo(-1.7, 1.5)
          .lineTo(-6.4, -8.7)
          .lineTo(-7.7, -11.6)
          .curveTo(-7.9, -12.2, -8.4, -12.5)
          .curveTo(-8.7, -12.7, -9.3, -12.9)
          .lineTo(-9.3, -13.7)
          .lineTo(-0.3, -13.7)
          .lineTo(-0.3, -12.9)
          .lineTo(-0.8, -12.9)
          .curveTo(-1.5, -12.9, -1.8, -12.6)
          .curveTo(-2.2, -12.2, -2.2, -11.6)
          .lineTo(-2.1, -10.9)
          .lineTo(1.1, -3.6)
          .lineTo(3, -7.1)
          .curveTo(4.5, -9.9, 4.5, -10.9)
          .curveTo(4.5, -11.3, 4.3, -11.9)
          .curveTo(4.1, -12.4, 3.7, -12.7)
          .curveTo(3.4, -12.9, 2.5, -12.9)
          .lineTo(2.5, -13.7)
          .lineTo(9.2, -13.7)
          .lineTo(9.2, -12.9)
          .curveTo(8.4, -12.9, 7.9, -12.6)
          .curveTo(7.5, -12.5, 6.9, -11.6)
          .lineTo(1.7, -2.3)
          .lineTo(6.7, 8.8)
          .curveTo(7.9, 11.6, 8.5, 12.2)
          .curveTo(9, 12.7, 9.7, 12.9)
          .lineTo(9.7, 13.6)
          .closePath();
        this.shape_41.setTransform(-117.225, -0.85);
        this.shape_42 = new doc.a.Shape();
        this.shape_42.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.4)
          .curveTo(-2.6, 12.3, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 8.9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11.1, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -2.9, -12.5)
          .curveTo(-3.3, -12.9, -4.1, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.7)
          .lineTo(4.8, -13.7)
          .lineTo(4.8, -12.9)
          .lineTo(4.2, -12.9)
          .curveTo(3.4, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.3, 2.3, -11.5)
          .curveTo(2.2, -11.1, 2.2, -9)
          .lineTo(2.2, 8.9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.2, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_42.setTransform(-131.125, -0.85);
        this.shape_43 = new doc.a.Shape();
        this.shape_43.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(0.8, 13.6)
          .lineTo(0.8, 12.9)
          .curveTo(1.9, 12.8, 2.3, 12.4)
          .curveTo(2.5, 12.1, 2.5, 11.5)
          .lineTo(2.5, 10.9)
          .lineTo(1.5, 8.6)
          .lineTo(-1.1, 2.7)
          .lineTo(-3.9, 7.8)
          .curveTo(-5.2, 10.1, -5.2, 11)
          .curveTo(-5.1, 11.6, -4.8, 12.1)
          .curveTo(-4.5, 12.5, -3.9, 12.8)
          .curveTo(-3.7, 12.9, -2.8, 12.9)
          .lineTo(-2.8, 13.6)
          .lineTo(-9.8, 13.6)
          .lineTo(-9.8, 12.9)
          .curveTo(-8.6, 12.7, -7.9, 11.9)
          .curveTo(-6.9, 11, -5.4, 8.1)
          .lineTo(-1.8, 1.5)
          .lineTo(-7.6, -11.5)
          .curveTo(-8, -12.1, -8.3, -12.5)
          .curveTo(-8.7, -12.8, -9.3, -12.9)
          .lineTo(-9.3, -13.6)
          .lineTo(-0.3, -13.6)
          .lineTo(-0.3, -12.9)
          .lineTo(-0.8, -12.9)
          .curveTo(-1.5, -12.9, -1.9, -12.5)
          .curveTo(-2.1, -12.1, -2.1, -11.6)
          .lineTo(-2, -10.8)
          .lineTo(1.1, -3.6)
          .lineTo(3.1, -7.1)
          .curveTo(4.5, -9.9, 4.5, -10.9)
          .curveTo(4.5, -11.5, 4.3, -11.9)
          .curveTo(4, -12.4, 3.7, -12.6)
          .curveTo(3.4, -12.9, 2.5, -12.9)
          .lineTo(2.5, -13.6)
          .lineTo(9.2, -13.6)
          .lineTo(9.2, -12.9)
          .curveTo(8.4, -12.9, 7.9, -12.6)
          .curveTo(7.4, -12.3, 6.9, -11.6)
          .curveTo(6.5, -11, 5.2, -8.6)
          .lineTo(1.7, -2.4)
          .lineTo(6.7, 8.8)
          .curveTo(8, 11.5, 8.5, 12.2)
          .curveTo(9.1, 12.8, 9.7, 12.9)
          .lineTo(9.7, 13.6)
          .closePath();
        this.shape_43.setTransform(-105.8, -62.375);
        this.shape_44 = new doc.a.Shape();
        this.shape_44.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.6)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.5)
          .curveTo(-2.5, 12.1, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11, -2.3, -11.6)
          .curveTo(-2.5, -12.2, -2.9, -12.5)
          .curveTo(-3.4, -12.9, -4.2, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.6)
          .lineTo(4.8, -13.6)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.3, -12.9, 2.9, -12.5)
          .curveTo(2.6, -12.2, 2.3, -11.5)
          .curveTo(2.2, -11, 2.2, -9)
          .lineTo(2.2, 9)
          .curveTo(2.2, 11.1, 2.3, 11.6)
          .curveTo(2.5, 12.1, 2.9, 12.5)
          .curveTo(3.3, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.6)
          .closePath();
        this.shape_44.setTransform(-52.125, -107.075);
        this.shape_45 = new doc.a.Shape();
        this.shape_45.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(0.9, 13.6)
          .lineTo(0.9, 12.9)
          .curveTo(1.9, 12.8, 2.2, 12.4)
          .curveTo(2.6, 12.1, 2.6, 11.5)
          .lineTo(2.5, 10.9)
          .lineTo(-1.1, 2.7)
          .lineTo(-3.9, 7.8)
          .curveTo(-5.2, 10.2, -5.2, 11)
          .curveTo(-5.2, 11.5, -4.8, 12.1)
          .curveTo(-4.5, 12.5, -3.9, 12.8)
          .curveTo(-3.7, 12.9, -2.7, 12.9)
          .lineTo(-2.7, 13.6)
          .lineTo(-9.8, 13.6)
          .lineTo(-9.8, 12.9)
          .curveTo(-8.6, 12.7, -7.9, 11.9)
          .curveTo(-7.1, 11.2, -5.4, 8.1)
          .lineTo(-1.8, 1.5)
          .lineTo(-7.7, -11.5)
          .curveTo(-8, -12.2, -8.4, -12.5)
          .curveTo(-8.7, -12.8, -9.3, -12.9)
          .lineTo(-9.3, -13.6)
          .lineTo(-0.3, -13.6)
          .lineTo(-0.3, -12.9)
          .lineTo(-0.8, -12.9)
          .curveTo(-1.6, -12.9, -1.8, -12.5)
          .curveTo(-2.1, -12.1, -2.1, -11.6)
          .lineTo(-2.1, -10.8)
          .lineTo(1.1, -3.6)
          .lineTo(3, -7.1)
          .curveTo(4.5, -9.8, 4.5, -10.9)
          .curveTo(4.5, -11.5, 4.3, -11.9)
          .curveTo(4.1, -12.4, 3.7, -12.6)
          .curveTo(3.3, -12.9, 2.5, -12.9)
          .lineTo(2.5, -13.6)
          .lineTo(9.2, -13.6)
          .lineTo(9.2, -12.9)
          .curveTo(8.4, -12.8, 7.9, -12.6)
          .curveTo(7.5, -12.3, 6.9, -11.6)
          .lineTo(1.7, -2.4)
          .lineTo(6.7, 8.8)
          .curveTo(8, 11.7, 8.4, 12.2)
          .curveTo(9.1, 12.8, 9.8, 12.9)
          .lineTo(9.8, 13.6)
          .closePath();
        this.shape_45.setTransform(-65.95, -107.075);
        this.shape_46 = new doc.a.Shape();
        this.shape_46.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.7)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.2, 12.9)
          .curveTo(-3.3, 12.9, -2.9, 12.4)
          .curveTo(-2.5, 12.1, -2.4, 11.5)
          .curveTo(-2.2, 11, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11, -2.4, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.3, -12.9, -4.2, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.7)
          .lineTo(4.8, -13.7)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.3, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.2, 2.3, -11.5)
          .curveTo(2.2, -11, 2.1, -9)
          .lineTo(2.1, 9)
          .curveTo(2.1, 11.1, 2.3, 11.5)
          .curveTo(2.5, 12.2, 2.9, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.7)
          .closePath();
        this.shape_46.setTransform(13.5, -123.4);
        this.shape_47 = new doc.a.Shape();
        this.shape_47.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.8, 13.7)
          .lineTo(-4.8, 12.9)
          .lineTo(-4.1, 12.9)
          .curveTo(-3.4, 12.9, -2.9, 12.4)
          .curveTo(-2.5, 12.1, -2.3, 11.5)
          .curveTo(-2.2, 11, -2.2, 9)
          .lineTo(-2.2, -9)
          .curveTo(-2.2, -11, -2.3, -11.6)
          .curveTo(-2.5, -12.1, -3, -12.5)
          .curveTo(-3.4, -12.9, -4.1, -12.9)
          .lineTo(-4.8, -12.9)
          .lineTo(-4.8, -13.7)
          .lineTo(4.8, -13.7)
          .lineTo(4.8, -12.9)
          .lineTo(4.1, -12.9)
          .curveTo(3.3, -12.9, 2.9, -12.5)
          .curveTo(2.5, -12.2, 2.4, -11.5)
          .curveTo(2.2, -11, 2.2, -9)
          .lineTo(2.2, 9)
          .curveTo(2.2, 11.1, 2.4, 11.5)
          .curveTo(2.5, 12.2, 3, 12.5)
          .curveTo(3.4, 12.9, 4.1, 12.9)
          .lineTo(4.8, 12.9)
          .lineTo(4.8, 13.7)
          .closePath();
        this.shape_47.setTransform(4.2, -123.4);
        this.shape_48 = new doc.a.Shape();
        this.shape_48.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(0.9, 13.7)
          .lineTo(0.9, 12.9)
          .curveTo(1.9, 12.7, 2.2, 12.4)
          .curveTo(2.5, 12, 2.5, 11.5)
          .lineTo(2.4, 10.9)
          .curveTo(2.3, 10.2, 1.5, 8.6)
          .lineTo(-1.1, 2.7)
          .lineTo(-3.9, 7.8)
          .curveTo(-5.2, 10.1, -5.2, 11)
          .curveTo(-5.2, 11.6, -4.9, 12.1)
          .curveTo(-4.5, 12.5, -3.9, 12.8)
          .curveTo(-3.6, 12.9, -2.7, 12.9)
          .lineTo(-2.7, 13.7)
          .lineTo(-9.7, 13.7)
          .lineTo(-9.7, 12.9)
          .curveTo(-8.5, 12.6, -7.9, 11.9)
          .curveTo(-7, 11.1, -5.3, 8.1)
          .lineTo(-1.7, 1.4)
          .lineTo(-7.7, -11.5)
          .curveTo(-8.1, -12.3, -8.4, -12.5)
          .curveTo(-8.7, -12.7, -9.3, -12.9)
          .lineTo(-9.3, -13.7)
          .lineTo(-0.3, -13.7)
          .lineTo(-0.3, -12.9)
          .lineTo(-0.8, -12.9)
          .curveTo(-1.6, -12.9, -1.9, -12.5)
          .curveTo(-2.2, -12.1, -2.2, -11.6)
          .lineTo(-2.1, -10.8)
          .lineTo(1.1, -3.6)
          .lineTo(3, -7.1)
          .curveTo(4.5, -9.8, 4.5, -10.9)
          .curveTo(4.5, -11.3, 4.3, -12)
          .curveTo(4.1, -12.4, 3.7, -12.6)
          .curveTo(3.4, -12.9, 2.5, -12.9)
          .lineTo(2.5, -13.7)
          .lineTo(9.2, -13.7)
          .lineTo(9.2, -12.9)
          .curveTo(8.4, -12.9, 7.9, -12.6)
          .curveTo(7.4, -12.4, 6.9, -11.6)
          .lineTo(5.1, -8.6)
          .lineTo(1.7, -2.3)
          .lineTo(6.7, 8.8)
          .curveTo(7.9, 11.5, 8.5, 12.1)
          .curveTo(9, 12.8, 9.7, 12.9)
          .lineTo(9.7, 13.7)
          .closePath();
        this.shape_48.setTransform(-9.625, -123.4);
        this.shape_49 = new doc.a.Shape();
        this.shape_49.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(1.4, 12.9)
          .lineTo(1.4, -3.8)
          .curveTo(1.4, -6.8, 1.5, -8.5)
          .lineTo(-3.5, -4.3)
          .lineTo(-5.5, -6.9)
          .lineTo(2.1, -12.9)
          .lineTo(5.5, -12.9)
          .lineTo(5.5, 12.9)
          .closePath();
        this.shape_49.setTransform(59.525, -106.85);
        this.shape_50 = new doc.a.Shape();
        this.shape_50.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-5.7, 12.9)
          .lineTo(4.5, -9.3)
          .lineTo(-8.9, -9.3)
          .lineTo(-8.9, -12.9)
          .lineTo(8.9, -12.9)
          .lineTo(8.9, -10)
          .lineTo(-1.2, 12.9)
          .closePath();
        this.shape_50.setTransform(-61.675, 106.55);
        this.shape_51 = new doc.a.Shape();
        this.shape_51.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-8.7, 13.1)
          .lineTo(-8.7, 9.9)
          .lineTo(-2.1, 3.3)
          .curveTo(1, 0.1, 1.8, -1)
          .curveTo(2.9, -2.3, 3.3, -3.4)
          .curveTo(3.6, -4.6, 3.6, -5.8)
          .curveTo(3.6, -7.5, 2.6, -8.5)
          .curveTo(1.5, -9.6, -0.3, -9.5)
          .curveTo(-1.8, -9.6, -3.1, -9)
          .curveTo(-4.4, -8.6, -6.4, -7)
          .lineTo(-8.6, -9.7)
          .curveTo(-6.4, -11.6, -4.5, -12.3)
          .curveTo(-2.3, -13.1, -0.1, -13.1)
          .curveTo(3.5, -13.1, 5.7, -11.2)
          .curveTo(7.9, -9.4, 7.8, -6.1)
          .curveTo(7.9, -4.4, 7.2, -2.9)
          .curveTo(6.6, -1.2, 5.3, 0.4)
          .curveTo(4.1, 1.9, 1, 5)
          .lineTo(-3.5, 9.3)
          .lineTo(-3.5, 9.5)
          .lineTo(8.7, 9.5)
          .lineTo(8.7, 13.1)
          .closePath();
        this.shape_51.setTransform(106.7, -61.95);
        this.shape_52 = new doc.a.Shape();
        this.shape_52.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-6.5, 11.4)
          .curveTo(-8.8, 9.7, -8.8, 6.4)
          .curveTo(-8.8, 4.2, -7.6, 2.4)
          .curveTo(-6.3, 0.7, -3.6, -0.6)
          .curveTo(-6, -2.1, -7, -3.6)
          .curveTo(-8, -5.1, -8, -7.1)
          .curveTo(-8, -10, -5.8, -11.6)
          .curveTo(-3.6, -13.2, -0, -13.2)
          .curveTo(3.7, -13.3, 5.8, -11.5)
          .curveTo(7.9, -9.9, 7.9, -7)
          .curveTo(7.9, -3.1, 3.2, -0.7)
          .curveTo(6.3, 0.9, 7.5, 2.4)
          .curveTo(8.8, 4.2, 8.8, 6.2)
          .curveTo(8.8, 9.4, 6.4, 11.3)
          .curveTo(4, 13.3, 0, 13.2)
          .curveTo(-4.1, 13.3, -6.5, 11.4)
          .closePath()
          .moveTo(-3.8, 3.4)
          .curveTo(-4.8, 4.6, -4.8, 6.2)
          .curveTo(-4.8, 8, -3.5, 9.1)
          .curveTo(-2.2, 10.1, -0, 10.1)
          .curveTo(2.3, 10.1, 3.5, 9.1)
          .curveTo(4.8, 8, 4.8, 6.2)
          .curveTo(4.8, 4.8, 3.6, 3.5)
          .curveTo(2.5, 2.4, 0.1, 1.4)
          .lineTo(-0.4, 1.2)
          .curveTo(-2.8, 2.2, -3.8, 3.4)
          .closePath()
          .moveTo(-2.9, -9.2)
          .curveTo(-4, -8.3, -4, -6.8)
          .curveTo(-4, -5.9, -3.6, -5.1)
          .curveTo(-3.1, -4.4, -2.5, -3.9)
          .curveTo(-1.8, -3.3, 0, -2.4)
          .curveTo(2.2, -3.4, 3, -4.4)
          .curveTo(3.9, -5.5, 3.9, -6.8)
          .curveTo(3.9, -8.3, 2.8, -9.2)
          .curveTo(1.7, -10.1, -0.1, -10.1)
          .curveTo(-1.8, -10.1, -2.9, -9.2)
          .closePath();
        this.shape_52.setTransform(-106.675, 61.45);
        this.shape_53 = new doc.a.Shape();
        this.shape_53.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-8.7, 11.9)
          .lineTo(-8.7, 8.2)
          .curveTo(-7.1, 9, -5.2, 9.5)
          .curveTo(-3.2, 9.9, -1.7, 9.9)
          .curveTo(1.4, 9.9, 2.8, 8.8)
          .curveTo(4.3, 7.6, 4.3, 5.3)
          .curveTo(4.3, 3.3, 2.6, 2.3)
          .curveTo(1.1, 1.3, -2.5, 1.3)
          .lineTo(-4.8, 1.3)
          .lineTo(-4.8, -2.1)
          .lineTo(-2.5, -2.1)
          .curveTo(3.7, -2.1, 3.7, -6.3)
          .curveTo(3.7, -7.9, 2.6, -8.9)
          .curveTo(1.6, -9.8, -0.6, -9.8)
          .curveTo(-2.2, -9.8, -3.4, -9.4)
          .curveTo(-5, -8.8, -6.6, -7.8)
          .lineTo(-8.6, -10.7)
          .curveTo(-5, -13.3, -0.4, -13.3)
          .curveTo(3.6, -13.3, 5.7, -11.6)
          .curveTo(7.9, -9.9, 7.9, -7)
          .curveTo(7.9, -4.6, 6.5, -2.9)
          .curveTo(5, -1.2, 2.5, -0.7)
          .lineTo(2.5, -0.5)
          .curveTo(5.6, -0.1, 7.1, 1.4)
          .curveTo(8.7, 2.9, 8.7, 5.5)
          .curveTo(8.7, 9.2, 6, 11.3)
          .curveTo(3.4, 13.3, -1.5, 13.3)
          .curveTo(-5.8, 13.3, -8.7, 11.9)
          .closePath();
        this.shape_53.setTransform(123.075, -0.175);
        this.shape_54 = new doc.a.Shape();
        this.shape_54.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-7, 13)
          .lineTo(-7, 9.5)
          .curveTo(-5.4, 9.9, -3.8, 9.9)
          .curveTo(0.5, 10, 2.5, 7.7)
          .curveTo(4.6, 5.4, 4.7, 0.6)
          .lineTo(4.5, 0.6)
          .curveTo(3.5, 2.1, 2, 2.9)
          .curveTo(0.5, 3.6, -1.4, 3.6)
          .curveTo(-4.9, 3.6, -6.8, 1.5)
          .curveTo(-8.8, -0.7, -8.8, -4.4)
          .curveTo(-8.8, -8.4, -6.5, -10.8)
          .curveTo(-4.3, -13.3, -0.3, -13.3)
          .curveTo(2.5, -13.3, 4.5, -11.9)
          .curveTo(6.6, -10.5, 7.6, -8)
          .curveTo(8.8, -5.4, 8.8, -1.9)
          .curveTo(8.8, 5.7, 5.7, 9.5)
          .curveTo(2.6, 13.3, -3.6, 13.3)
          .curveTo(-6.1, 13.2, -7, 13)
          .closePath()
          .moveTo(-3.6, -8.4)
          .curveTo(-4.7, -7, -4.7, -4.5)
          .curveTo(-4.7, -2.1, -3.6, -1)
          .curveTo(-2.6, 0.3, -0.4, 0.3)
          .curveTo(1.6, 0.3, 3.1, -1)
          .curveTo(4.6, -2.3, 4.6, -3.9)
          .curveTo(4.6, -5.5, 4, -6.9)
          .curveTo(3.4, -8.2, 2.3, -9)
          .curveTo(1.2, -9.8, -0.3, -9.8)
          .curveTo(-2.4, -9.8, -3.6, -8.4)
          .closePath();
        this.shape_54.setTransform(-123.225, -0.15);
        this.shape_55 = new doc.a.Shape();
        this.shape_55.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(2.2, 12.9)
          .lineTo(2.2, 7.3)
          .lineTo(-9.6, 7.3)
          .lineTo(-9.6, 4.1)
          .lineTo(2.2, -12.9)
          .lineTo(6.2, -12.9)
          .lineTo(6.2, 3.9)
          .lineTo(9.7, 3.9)
          .lineTo(9.7, 7.3)
          .lineTo(6.2, 7.3)
          .lineTo(6.2, 12.9)
          .closePath()
          .moveTo(0.6, -5.4)
          .lineTo(-5.8, 3.9)
          .lineTo(2.2, 3.9)
          .lineTo(2.2, -2.6)
          .curveTo(2.2, -6, 2.3, -8.3)
          .lineTo(2.2, -8.3)
          .curveTo(1.6, -6.9, 0.6, -5.4)
          .closePath();
        this.shape_55.setTransform(106.7, 61.4);
        this.shape_56 = new doc.a.Shape();
        this.shape_56.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-6.5, 9.9)
          .curveTo(-8.8, 6.6, -8.8, -0)
          .curveTo(-8.8, -6.8, -6.6, -10.1)
          .curveTo(-4.5, -13.3, -0, -13.3)
          .curveTo(4.4, -13.3, 6.5, -9.9)
          .curveTo(8.8, -6.5, 8.8, -0)
          .curveTo(8.8, 6.8, 6.6, 10)
          .curveTo(4.5, 13.3, -0, 13.3)
          .curveTo(-4.3, 13.3, -6.5, 9.9)
          .closePath()
          .moveTo(-3.5, -7.6)
          .curveTo(-4.6, -5.3, -4.6, -0)
          .curveTo(-4.6, 5.3, -3.5, 7.6)
          .curveTo(-2.4, 9.8, -0, 9.8)
          .curveTo(2.4, 9.8, 3.5, 7.5)
          .curveTo(4.6, 5.3, 4.6, -0)
          .curveTo(4.6, -5.3, 3.5, -7.5)
          .curveTo(2.3, -9.8, -0, -9.8)
          .curveTo(-2.4, -9.8, -3.5, -7.6)
          .closePath();
        this.shape_56.setTransform(-96.375, -61.75);
        this.shape_57 = new doc.a.Shape();
        this.shape_57.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(1.4, 12.9)
          .lineTo(1.4, -3.8)
          .curveTo(1.4, -6.8, 1.5, -8.5)
          .lineTo(-3.4, -4.3)
          .lineTo(-5.5, -7)
          .lineTo(2.1, -12.9)
          .lineTo(5.5, -12.9)
          .lineTo(5.5, 12.9)
          .closePath();
        this.shape_57.setTransform(-119.125, -61.725);
        this.shape_58 = new doc.a.Shape();
        this.shape_58.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-8.4, 11.7)
          .lineTo(-8.4, 7.9)
          .curveTo(-6.9, 8.8, -5.1, 9.2)
          .curveTo(-3.2, 9.6, -1.6, 9.7)
          .curveTo(1.2, 9.6, 2.7, 8.4)
          .curveTo(4.1, 7.1, 4.1, 4.7)
          .curveTo(4.1, 0.1, -1.8, 0.1)
          .lineTo(-3.8, 0.3)
          .lineTo(-6, 0.7)
          .lineTo(-7.8, -0.4)
          .lineTo(-6.8, -13.1)
          .lineTo(6.6, -13.1)
          .lineTo(6.6, -9.4)
          .lineTo(-3.2, -9.4)
          .lineTo(-3.8, -3)
          .lineTo(-0.1, -3.4)
          .curveTo(3.9, -3.4, 6.1, -1.3)
          .curveTo(8.4, 0.7, 8.4, 4.3)
          .curveTo(8.4, 8.5, 5.8, 10.8)
          .curveTo(3.2, 13.1, -1.5, 13.1)
          .curveTo(-5.9, 13.1, -8.4, 11.7)
          .closePath();
        this.shape_58.setTransform(61.675, 106.7);
        this.shape_59 = new doc.a.Shape();
        this.shape_59.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(1.4, 12.9)
          .lineTo(1.4, -3.8)
          .curveTo(1.4, -6.7, 1.5, -8.5)
          .lineTo(-3.4, -4.3)
          .lineTo(-5.5, -6.9)
          .lineTo(2.1, -12.9)
          .lineTo(5.5, -12.9)
          .lineTo(5.5, 12.9)
          .closePath();
        this.shape_59.setTransform(-53.375, -106.825);
        this.shape_60 = new doc.a.Shape();
        this.shape_60.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(1.4, 12.9)
          .lineTo(1.4, -3.8)
          .curveTo(1.4, -6.7, 1.5, -8.5)
          .lineTo(-3.4, -4.3)
          .lineTo(-5.5, -6.9)
          .lineTo(2.1, -12.9)
          .lineTo(5.5, -12.9)
          .lineTo(5.5, 12.9)
          .closePath();
        this.shape_60.setTransform(-74.025, -106.825);
        this.shape_61 = new doc.a.Shape();
        this.shape_61.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-4.5, 11.9)
          .curveTo(-6.5, 10.6, -7.7, 8.1)
          .curveTo(-8.8, 5.4, -8.8, 1.9)
          .curveTo(-8.8, -13.3, 3.6, -13.3)
          .curveTo(5.5, -13.3, 6.9, -12.9)
          .lineTo(6.9, -9.5)
          .curveTo(5.4, -9.9, 3.8, -9.9)
          .curveTo(-0.4, -9.9, -2.5, -7.7)
          .curveTo(-4.6, -5.4, -4.7, -0.5)
          .lineTo(-4.5, -0.5)
          .curveTo(-3.7, -1.9, -2.2, -2.7)
          .curveTo(-0.7, -3.5, 1.3, -3.5)
          .curveTo(4.9, -3.5, 6.8, -1.4)
          .curveTo(8.8, 0.8, 8.8, 4.5)
          .curveTo(8.8, 8.6, 6.5, 10.9)
          .curveTo(4.3, 13.2, 0.3, 13.3)
          .curveTo(-2.4, 13.3, -4.5, 11.9)
          .closePath()
          .moveTo(-2.1, 0.3)
          .curveTo(-3.2, 0.9, -3.9, 1.9)
          .curveTo(-4.6, 3, -4.6, 3.9)
          .curveTo(-4.6, 6.5, -3.2, 8.1)
          .curveTo(-1.8, 9.8, 0.3, 9.9)
          .curveTo(2.4, 9.8, 3.5, 8.4)
          .curveTo(4.7, 7.1, 4.7, 4.5)
          .curveTo(4.7, 2.4, 3.6, 1)
          .curveTo(2.5, -0.2, 0.4, -0.2)
          .curveTo(-0.9, -0.3, -2.1, 0.3)
          .closePath();
        this.shape_61.setTransform(0.075, 123.05);
        this.shape_62 = new doc.a.Shape();
        this.shape_62.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(-8.8, 13.1)
          .lineTo(-8.8, 10)
          .lineTo(-2.1, 3.2)
          .curveTo(0.8, 0.3, 1.8, -1.1)
          .curveTo(2.7, -2.2, 3.2, -3.4)
          .curveTo(3.7, -4.5, 3.7, -5.8)
          .curveTo(3.7, -7.6, 2.6, -8.5)
          .curveTo(1.6, -9.6, -0.3, -9.5)
          .curveTo(-1.9, -9.5, -3.2, -9)
          .curveTo(-4.6, -8.5, -6.4, -7)
          .lineTo(-8.6, -9.8)
          .curveTo(-6.4, -11.6, -4.4, -12.3)
          .curveTo(-2.4, -13.1, -0.1, -13.1)
          .curveTo(3.5, -13.1, 5.7, -11.2)
          .curveTo(7.9, -9.4, 7.9, -6.2)
          .curveTo(7.9, -4.6, 7.2, -2.9)
          .curveTo(6.6, -1.2, 5.3, 0.4)
          .curveTo(4.1, 2, 1, 4.9)
          .lineTo(-3.5, 9.3)
          .lineTo(-3.5, 9.4)
          .lineTo(8.8, 9.4)
          .lineTo(8.8, 13.1)
          .closePath();
        this.shape_62.setTransform(10.325, -123.5);
        this.shape_63 = new doc.a.Shape();
        this.shape_63.graphics
          .beginFill("#333333")
          .beginStroke()
          .moveTo(1.4, 12.9)
          .lineTo(1.4, -3.8)
          .curveTo(1.4, -6.7, 1.5, -8.5)
          .lineTo(-3.5, -4.3)
          .lineTo(-5.5, -7)
          .lineTo(2.1, -12.9)
          .lineTo(5.5, -12.9)
          .lineTo(5.5, 12.9)
          .closePath();
        this.shape_63.setTransform(-12.425, -123.325);
        this.shape_64 = new doc.a.Shape();
        this.shape_64.graphics
          .beginFill()
          .beginStroke("#333333")
          .setStrokeStyle(1)
          .moveTo(148, 0)
          .curveTo(148, 30.1, 136.4, 57.6)
          .curveTo(125.1, 84.1, 104.6, 104.6)
          .curveTo(84.1, 125.1, 57.6, 136.4)
          .curveTo(30.1, 148, 0, 148)
          .curveTo(-30.1, 148, -57.6, 136.4)
          .curveTo(-84.2, 125.1, -104.7, 104.6)
          .curveTo(-125.2, 84.1, -136.3, 57.6)
          .curveTo(-148, 30.1, -148, 0)
          .curveTo(-148, -30.1, -136.3, -57.6)
          .curveTo(-125.2, -84.2, -104.7, -104.7)
          .curveTo(-84.2, -125.2, -57.6, -136.3)
          .curveTo(-30.1, -148, 0, -148)
          .curveTo(30.1, -148, 57.6, -136.3)
          .curveTo(84.1, -125.2, 104.6, -104.7)
          .curveTo(125.1, -84.2, 136.4, -57.6)
          .curveTo(148, -30.1, 148, 0)
          .closePath();
        this.shape_65 = new doc.a.Shape();
        this.shape_65.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-57.6, 136.3)
          .curveTo(-84.1, 125.1, -104.7, 104.6)
          .curveTo(-125.1, 84.2, -136.4, 57.6)
          .curveTo(-148, 30.1, -148, -0)
          .curveTo(-148, -30.1, -136.4, -57.6)
          .curveTo(-125.1, -84.1, -104.7, -104.7)
          .curveTo(-84.1, -125.1, -57.6, -136.4)
          .curveTo(-30.1, -148, -0, -148)
          .curveTo(30.1, -148, 57.6, -136.4)
          .curveTo(84.2, -125.1, 104.6, -104.7)
          .curveTo(125.1, -84.1, 136.3, -57.6)
          .curveTo(148, -30.1, 148, -0)
          .curveTo(148, 30.1, 136.3, 57.6)
          .curveTo(125.1, 84.2, 104.6, 104.6)
          .curveTo(84.2, 125.1, 57.6, 136.3)
          .curveTo(30.1, 148, -0, 148)
          .curveTo(-30.1, 148, -57.6, 136.3)
          .closePath();
        this.shape_66 = new doc.a.Shape();
        this.shape_66.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-16.7, 159.1).lineTo(16.7, -159.1);
        this.shape_66.setTransform(-0.025, -0.025);
        this.shape_67 = new doc.a.Shape();
        this.shape_67.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-33.3, 156.5).lineTo(33.3, -156.5);
        this.shape_67.setTransform(-0.025, -0.025);
        this.shape_68 = new doc.a.Shape();
        this.shape_68.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-49.4, 152.2).lineTo(49.4, -152.2);
        this.shape_68.setTransform(-0.025, -0.025);
        this.shape_69 = new doc.a.Shape();
        this.shape_69.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-65.1, 146.2).lineTo(65.1, -146.2);
        this.shape_69.setTransform(-0.025, -0.025);
        this.shape_70 = new doc.a.Shape();
        this.shape_70.graphics.beginFill().beginStroke("#333333").setStrokeStyle(4).moveTo(-80, 138.6).lineTo(80, -138.6);
        this.shape_70.setTransform(-0.025, -0.025);
        this.shape_71 = new doc.a.Shape();
        this.shape_71.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-94, 129.4).lineTo(94, -129.4);
        this.shape_71.setTransform(-0.025, -0.025);
        this.shape_72 = new doc.a.Shape();
        this.shape_72.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-107.1, 118.9).lineTo(107.1, -118.9);
        this.shape_72.setTransform(-0.025, -0.025);
        this.shape_73 = new doc.a.Shape();
        this.shape_73.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-118.9, 107.1).lineTo(118.9, -107.1);
        this.shape_73.setTransform(-0.025, -0.025);
        this.shape_74 = new doc.a.Shape();
        this.shape_74.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-129.4, 94).lineTo(129.4, -94);
        this.shape_74.setTransform(-0.025, -0.025);
        this.shape_75 = new doc.a.Shape();
        this.shape_75.graphics.beginFill().beginStroke("#333333").setStrokeStyle(4).moveTo(-138.6, 80).lineTo(138.6, -80);
        this.shape_75.setTransform(-0.025, -0.025);
        this.shape_76 = new doc.a.Shape();
        this.shape_76.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-146.2, 65.1).lineTo(146.2, -65.1);
        this.shape_76.setTransform(-0.025, -0.025);
        this.shape_77 = new doc.a.Shape();
        this.shape_77.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-152.2, 49.4).lineTo(152.2, -49.4);
        this.shape_77.setTransform(-0.025, -0.025);
        this.shape_78 = new doc.a.Shape();
        this.shape_78.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-156.5, 33.3).lineTo(156.5, -33.3);
        this.shape_78.setTransform(-0.025, -0.025);
        this.shape_79 = new doc.a.Shape();
        this.shape_79.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-159.1, 16.7).lineTo(159.1, -16.7);
        this.shape_79.setTransform(-0.025, -0.025);
        this.shape_80 = new doc.a.Shape();
        this.shape_80.graphics.beginFill().beginStroke("#333333").setStrokeStyle(4).moveTo(-160, -0).lineTo(160, 0);
        this.shape_80.setTransform(0, -0.025);
        this.shape_81 = new doc.a.Shape();
        this.shape_81.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-159.1, -16.7).lineTo(159.1, 16.7);
        this.shape_81.setTransform(-0.025, -0.025);
        this.shape_82 = new doc.a.Shape();
        this.shape_82.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-156.5, -33.3).lineTo(156.5, 33.3);
        this.shape_82.setTransform(-0.025, -0.025);
        this.shape_83 = new doc.a.Shape();
        this.shape_83.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-152.2, -49.4).lineTo(152.2, 49.4);
        this.shape_83.setTransform(-0.025, -0.025);
        this.shape_84 = new doc.a.Shape();
        this.shape_84.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-146.2, -65.1).lineTo(146.2, 65.1);
        this.shape_84.setTransform(-0.025, -0.025);
        this.shape_85 = new doc.a.Shape();
        this.shape_85.graphics.beginFill().beginStroke("#333333").setStrokeStyle(4).moveTo(-138.6, -80).lineTo(138.6, 80);
        this.shape_85.setTransform(-0.025, -0.025);
        this.shape_86 = new doc.a.Shape();
        this.shape_86.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-129.4, -94).lineTo(129.4, 94);
        this.shape_86.setTransform(-0.025, -0.025);
        this.shape_87 = new doc.a.Shape();
        this.shape_87.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-118.9, -107.1).lineTo(118.9, 107.1);
        this.shape_87.setTransform(-0.025, -0.025);
        this.shape_88 = new doc.a.Shape();
        this.shape_88.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-107.1, -118.9).lineTo(107.1, 118.9);
        this.shape_88.setTransform(-0.025, -0.025);
        this.shape_89 = new doc.a.Shape();
        this.shape_89.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-94, -129.4).lineTo(94, 129.4);
        this.shape_89.setTransform(-0.025, -0.025);
        this.shape_90 = new doc.a.Shape();
        this.shape_90.graphics.beginFill().beginStroke("#333333").setStrokeStyle(4).moveTo(-80, -138.6).lineTo(80, 138.6);
        this.shape_90.setTransform(-0.025, -0.025);
        this.shape_91 = new doc.a.Shape();
        this.shape_91.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-65.1, -146.2).lineTo(65.1, 146.2);
        this.shape_91.setTransform(-0.025, -0.025);
        this.shape_92 = new doc.a.Shape();
        this.shape_92.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-49.4, -152.2).lineTo(49.4, 152.2);
        this.shape_92.setTransform(-0.025, -0.025);
        this.shape_93 = new doc.a.Shape();
        this.shape_93.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-33.3, -156.5).lineTo(33.3, 156.5);
        this.shape_93.setTransform(-0.025, -0.025);
        this.shape_94 = new doc.a.Shape();
        this.shape_94.graphics.beginFill().beginStroke("#333333").setStrokeStyle(1).moveTo(-16.7, -159.1).lineTo(16.7, 159.1);
        this.shape_94.setTransform(-0.025, -0.025);
        this.shape_95 = new doc.a.Shape();
        this.shape_95.graphics.beginFill().beginStroke("#333333").setStrokeStyle(4).moveTo(0, -160).lineTo(0, 160);
        this.shape_96 = new doc.a.Shape();
        this.shape_96.graphics
          .beginFill()
          .beginStroke("#333333")
          .setStrokeStyle(2)
          .moveTo(160, 0)
          .curveTo(160, 32.6, 147.4, 62.2)
          .curveTo(135.3, 91, 113.1, 113.1)
          .curveTo(91, 135.3, 62.2, 147.4)
          .curveTo(32.6, 160, 0, 160)
          .curveTo(-32.6, 160, -62.3, 147.4)
          .curveTo(-91, 135.3, -113.2, 113.1)
          .curveTo(-135.3, 91, -147.4, 62.2)
          .curveTo(-160, 32.6, -160, 0)
          .curveTo(-160, -32.6, -147.4, -62.3)
          .curveTo(-135.3, -91, -113.2, -113.2)
          .curveTo(-91, -135.3, -62.3, -147.4)
          .curveTo(-32.6, -160, 0, -160)
          .curveTo(32.6, -160, 62.2, -147.4)
          .curveTo(91, -135.3, 113.1, -113.2)
          .curveTo(135.3, -91, 147.4, -62.3)
          .curveTo(160, -32.6, 160, 0)
          .closePath();
        this.shape_97 = new doc.a.Shape();
        this.shape_97.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-62.3, 147.4)
          .curveTo(-91, 135.3, -113.2, 113.1)
          .curveTo(-135.3, 91, -147.4, 62.3)
          .curveTo(-160, 32.5, -160, -0)
          .curveTo(-160, -32.6, -147.4, -62.3)
          .curveTo(-135.3, -91, -113.2, -113.2)
          .curveTo(-91, -135.3, -62.3, -147.4)
          .curveTo(-32.6, -160, -0, -160)
          .curveTo(32.5, -160, 62.3, -147.4)
          .curveTo(91, -135.3, 113.1, -113.2)
          .curveTo(135.3, -91, 147.4, -62.3)
          .curveTo(160, -32.6, 160, -0)
          .curveTo(160, 32.5, 147.4, 62.3)
          .curveTo(135.3, 91, 113.1, 113.1)
          .curveTo(91, 135.3, 62.3, 147.4)
          .curveTo(32.5, 160, -0, 160)
          .curveTo(-32.6, 160, -62.3, 147.4)
          .closePath();
        this.shape_98 = new doc.a.Shape();
        this.shape_98.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.4)
          .lineTo(-3.9, 3.2)
          .curveTo(-3.2, 3.6, -2.4, 3.8)
          .curveTo(-1.7, 3.9, -0.8, 3.9)
          .curveTo(1.4, 4, 1.4, 2.1)
          .curveTo(1.4, 0.3, -0.9, 0.3)
          .lineTo(-2.7, 0.5)
          .lineTo(-3.7, 0.1)
          .lineTo(-3.3, -6)
          .lineTo(3.1, -6)
          .lineTo(3.1, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.5)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(2, -1.7, 2.9, -0.7)
          .curveTo(3.9, 0.2, 3.9, 1.9)
          .curveTo(3.9, 3.8, 2.7, 4.9)
          .curveTo(1.5, 6, -0.8, 6)
          .curveTo(-2.6, 6, -3.9, 5.4)
          .closePath();
        this.shape_98.setTransform(87.175, -150.85);
        this.shape_99 = new doc.a.Shape();
        this.shape_99.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .curveTo(-3.3, 3.5, -2.5, 3.7)
          .curveTo(-1.7, 3.9, -0.9, 3.9)
          .curveTo(1.4, 3.9, 1.4, 2.1)
          .curveTo(1.4, 0.3, -1, 0.3)
          .lineTo(-2.8, 0.6)
          .lineTo(-3.7, 0)
          .lineTo(-3.2, -6)
          .lineTo(3.1, -6)
          .lineTo(3.1, -3.8)
          .lineTo(-1.1, -3.8)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(1.9, -1.7, 2.9, -0.8)
          .curveTo(4, 0.3, 4, 1.8)
          .curveTo(4, 3.8, 2.7, 4.9)
          .curveTo(1.5, 6, -0.8, 6)
          .curveTo(-2.6, 6, -3.9, 5.3)
          .closePath();
        this.shape_99.setTransform(-82.4, 151.05);
        this.shape_100 = new doc.a.Shape();
        this.shape_100.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.1, 5.4)
          .lineTo(-4.1, 3.3)
          .curveTo(-3.4, 3.7, -2.6, 3.9)
          .curveTo(-1.8, 4.1, -0.9, 4.1)
          .curveTo(0.2, 4.1, 0.9, 3.7)
          .curveTo(1.5, 3.2, 1.5, 2.3)
          .curveTo(1.5, 1.5, 0.8, 1.1)
          .curveTo(-0, 0.8, -1.4, 0.8)
          .lineTo(-2.3, 0.8)
          .lineTo(-2.3, -1.1)
          .lineTo(-1.4, -1.1)
          .curveTo(0.1, -1.1, 0.6, -1.5)
          .curveTo(1.3, -1.8, 1.3, -2.7)
          .curveTo(1.3, -4.1, -0.4, -4.1)
          .lineTo(-1.6, -3.9)
          .curveTo(-2.3, -3.6, -2.9, -3.2)
          .lineTo(-4.1, -4.9)
          .curveTo(-2.4, -6.1, -0.2, -6.1)
          .curveTo(1.6, -6.1, 2.7, -5.3)
          .curveTo(3.7, -4.6, 3.7, -3.3)
          .curveTo(3.7, -2.2, 3.1, -1.4)
          .curveTo(2.4, -0.6, 1.2, -0.3)
          .lineTo(1.2, -0.3)
          .curveTo(2.6, -0.1, 3.3, 0.6)
          .curveTo(4.1, 1.3, 4.1, 2.5)
          .curveTo(4.1, 4.2, 2.8, 5.1)
          .curveTo(1.6, 6.1, -0.7, 6.1)
          .curveTo(-2.4, 6.1, -4.1, 5.4)
          .closePath();
        this.shape_100.setTransform(-91.875, 150.975);
        this.shape_101 = new doc.a.Shape();
        this.shape_101.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.1, 4.5)
          .curveTo(-4.1, 3, -4.1, -0)
          .curveTo(-4.1, -3.1, -3.1, -4.6)
          .curveTo(-2.1, -6.1, -0, -6.1)
          .curveTo(2, -6.1, 3.1, -4.5)
          .curveTo(4.1, -3, 4.1, -0)
          .curveTo(4.1, 3, 3.1, 4.6)
          .curveTo(2.1, 6.1, -0, 6.1)
          .curveTo(-2.1, 6.1, -3.1, 4.5)
          .closePath()
          .moveTo(-1.3, -3.1)
          .curveTo(-1.7, -2.1, -1.7, -0)
          .curveTo(-1.7, 2.1, -1.3, 3.1)
          .curveTo(-0.9, 4, -0, 4)
          .curveTo(0.9, 4, 1.2, 3.1)
          .curveTo(1.6, 2.3, 1.6, -0)
          .curveTo(1.6, -2.1, 1.2, -3.1)
          .curveTo(0.9, -4.1, -0, -4.1)
          .curveTo(-0.9, -4.1, -1.3, -3.1)
          .closePath();
        this.shape_101.setTransform(155.675, -87.125);
        this.shape_102 = new doc.a.Shape();
        this.shape_102.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(0.4, 5.9)
          .lineTo(0.5, -3.2)
          .lineTo(-1.7, -1.3)
          .lineTo(-2.9, -2.9)
          .lineTo(0.9, -5.9)
          .lineTo(2.9, -5.9)
          .lineTo(2.9, 5.9)
          .closePath();
        this.shape_102.setTransform(145.425, -87.15);
        this.shape_103 = new doc.a.Shape();
        this.shape_103.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.1, 4.5)
          .curveTo(-4.1, 3, -4.1, 0)
          .curveTo(-4.1, -3.2, -3.1, -4.6)
          .curveTo(-2.1, -6.1, -0, -6.1)
          .curveTo(2, -6.1, 3.1, -4.5)
          .curveTo(4.1, -2.9, 4.1, 0)
          .curveTo(4.1, 3.1, 3.1, 4.6)
          .curveTo(2.1, 6.1, -0, 6.1)
          .curveTo(-2.1, 6.1, -3.1, 4.5)
          .closePath()
          .moveTo(-1.3, -3.1)
          .curveTo(-1.7, -2.1, -1.7, 0)
          .curveTo(-1.7, 2.1, -1.3, 3.1)
          .curveTo(-0.9, 4.1, -0, 4.1)
          .curveTo(0.8, 4.1, 1.2, 3.1)
          .curveTo(1.6, 2.1, 1.6, 0)
          .curveTo(1.6, -2.1, 1.2, -3.1)
          .curveTo(0.8, -4.1, -0, -4.1)
          .curveTo(-0.9, -4.1, -1.3, -3.1)
          .closePath();
        this.shape_103.setTransform(-146.225, 87.175);
        this.shape_104 = new doc.a.Shape();
        this.shape_104.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(0.6, 5.9)
          .lineTo(0.6, 3.5)
          .lineTo(-4.5, 3.5)
          .lineTo(-4.5, 1.7)
          .lineTo(0.7, -5.9)
          .lineTo(3, -5.9)
          .lineTo(3, 1.5)
          .lineTo(4.4, 1.5)
          .lineTo(4.4, 3.5)
          .lineTo(3, 3.5)
          .lineTo(3, 5.9)
          .closePath()
          .moveTo(-0.1, -1.7)
          .lineTo(-2.2, 1.5)
          .lineTo(0.6, 1.5)
          .lineTo(0.7, -3)
          .lineTo(0.6, -3)
          .lineTo(-0.1, -1.7)
          .closePath();
        this.shape_104.setTransform(-155.65, 87.175);
        this.shape_105 = new doc.a.Shape();
        this.shape_105.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .lineTo(-2.5, 3.7)
          .curveTo(-1.7, 3.9, -0.9, 3.9)
          .curveTo(1.4, 3.9, 1.4, 2.1)
          .curveTo(1.4, 0.3, -1, 0.3)
          .lineTo(-2.7, 0.5)
          .lineTo(-3.7, 0)
          .lineTo(-3.2, -6)
          .lineTo(3.1, -6)
          .lineTo(3.1, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .curveTo(-0.7, -1.7, 0.2, -1.7)
          .curveTo(1.9, -1.7, 2.9, -0.8)
          .curveTo(4, 0.2, 4, 1.9)
          .curveTo(4, 3.8, 2.7, 4.9)
          .curveTo(1.6, 6, -0.8, 6)
          .curveTo(-2.6, 6, -3.9, 5.3)
          .closePath();
        this.shape_105.setTransform(179.05, 0.125);
        this.shape_106 = new doc.a.Shape();
        this.shape_106.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(0.4, 5.9)
          .lineTo(0.5, -3.3)
          .lineTo(-1.7, -1.4)
          .lineTo(-2.9, -2.9)
          .lineTo(0.9, -5.9)
          .lineTo(2.9, -5.9)
          .lineTo(2.9, 5.9)
          .closePath();
        this.shape_106.setTransform(168.775, 0.025);
        this.shape_107 = new doc.a.Shape();
        this.shape_107.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .curveTo(-3.2, 3.5, -2.5, 3.7)
          .curveTo(-1.7, 3.9, -0.8, 3.9)
          .curveTo(1.4, 3.9, 1.4, 2.1)
          .curveTo(1.4, 0.3, -0.9, 0.3)
          .lineTo(-2.7, 0.5)
          .lineTo(-3.7, 0)
          .lineTo(-3.3, -6)
          .lineTo(3.1, -6)
          .lineTo(3.1, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(2, -1.7, 2.9, -0.8)
          .curveTo(3.9, 0.2, 3.9, 1.9)
          .curveTo(3.9, 3.8, 2.7, 4.9)
          .curveTo(1.6, 6, -0.8, 6)
          .curveTo(-2.8, 6, -3.9, 5.3)
          .closePath();
        this.shape_107.setTransform(-169.575, 0.125);
        this.shape_108 = new doc.a.Shape();
        this.shape_108.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(0.6, 5.9)
          .lineTo(0.6, 3.4)
          .lineTo(-4.4, 3.4)
          .lineTo(-4.4, 1.7)
          .lineTo(0.7, -5.9)
          .lineTo(3, -5.9)
          .lineTo(3, 1.5)
          .lineTo(4.4, 1.5)
          .lineTo(4.4, 3.4)
          .lineTo(3, 3.4)
          .lineTo(3, 5.9)
          .closePath()
          .moveTo(-0.1, -1.8)
          .lineTo(-2.2, 1.5)
          .lineTo(0.6, 1.5)
          .lineTo(0.7, -3)
          .lineTo(0.6, -3)
          .closePath();
        this.shape_108.setTransform(-179.025, 0.05);
        this.shape_109 = new doc.a.Shape();
        this.shape_109.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.1, 4.5)
          .curveTo(-4.1, 3, -4.1, 0)
          .curveTo(-4.1, -3.2, -3.1, -4.6)
          .curveTo(-2.1, -6.1, -0, -6.1)
          .curveTo(2, -6.1, 3.1, -4.5)
          .curveTo(4.1, -2.9, 4.1, 0)
          .curveTo(4.1, 3.1, 3.1, 4.6)
          .curveTo(2.1, 6.1, -0, 6.1)
          .curveTo(-2.1, 6.1, -3.1, 4.5)
          .closePath()
          .moveTo(-1.3, -3.1)
          .curveTo(-1.7, -2.1, -1.7, 0)
          .curveTo(-1.7, 2.1, -1.3, 3.1)
          .curveTo(-0.9, 4.1, -0, 4.1)
          .curveTo(0.8, 4.1, 1.2, 3.1)
          .curveTo(1.6, 2.1, 1.6, 0)
          .curveTo(1.6, -2.1, 1.2, -3.1)
          .curveTo(0.8, -4.1, -0, -4.1)
          .curveTo(-0.9, -4.1, -1.3, -3.1)
          .closePath();
        this.shape_109.setTransform(155.675, 87.175);
        this.shape_110 = new doc.a.Shape();
        this.shape_110.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.1, 6)
          .lineTo(-4.1, 4.2)
          .lineTo(-1.1, 1.3)
          .lineTo(0.6, -0.6)
          .lineTo(1.2, -1.6)
          .lineTo(1.3, -2.5)
          .curveTo(1.3, -3.3, 0.9, -3.5)
          .curveTo(0.6, -3.9, -0.1, -3.9)
          .curveTo(-0.8, -3.9, -1.4, -3.6)
          .curveTo(-2.1, -3.3, -2.8, -2.7)
          .lineTo(-4.1, -4.3)
          .curveTo(-3.3, -5, -2.7, -5.3)
          .curveTo(-2.2, -5.7, -1.4, -5.8)
          .curveTo(-0.8, -6, 0.1, -6)
          .curveTo(1.1, -6, 2, -5.6)
          .curveTo(2.9, -5.1, 3.3, -4.4)
          .curveTo(3.8, -3.8, 3.8, -2.8)
          .curveTo(3.8, -2, 3.5, -1.3)
          .curveTo(3.2, -0.5, 2.6, 0.2)
          .curveTo(2.1, 0.9, 0.5, 2.3)
          .lineTo(-1, 3.8)
          .lineTo(-1, 3.9)
          .lineTo(4.1, 3.9)
          .lineTo(4.1, 6)
          .closePath();
        this.shape_110.setTransform(146.275, 87.1);
        this.shape_111 = new doc.a.Shape();
        this.shape_111.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.1, 4.5)
          .curveTo(-4.1, 3.1, -4.1, 0)
          .curveTo(-4.1, -3.2, -3.1, -4.6)
          .curveTo(-2.1, -6.1, -0, -6.1)
          .curveTo(2.1, -6.1, 3.1, -4.5)
          .curveTo(4.1, -2.9, 4.1, 0)
          .curveTo(4.1, 3.1, 3.1, 4.6)
          .curveTo(2.2, 6.1, -0, 6.1)
          .curveTo(-2, 6.1, -3.1, 4.5)
          .closePath()
          .moveTo(-1.3, -3.1)
          .curveTo(-1.6, -2.1, -1.6, 0)
          .curveTo(-1.6, 2.1, -1.3, 3.1)
          .curveTo(-0.8, 4.1, -0, 4.1)
          .curveTo(0.9, 4.1, 1.2, 3.1)
          .curveTo(1.6, 2.1, 1.7, 0)
          .curveTo(1.6, -2.1, 1.2, -3.1)
          .curveTo(0.9, -4.1, -0, -4.1)
          .curveTo(-0.8, -4.1, -1.3, -3.1)
          .closePath();
        this.shape_111.setTransform(-146.25, -87.125);
        this.shape_112 = new doc.a.Shape();
        this.shape_112.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .lineTo(-2.4, 3.7)
          .curveTo(-1.7, 3.9, -0.9, 3.9)
          .curveTo(1.5, 3.9, 1.5, 2.1)
          .curveTo(1.5, 0.3, -1, 0.3)
          .lineTo(-1.9, 0.4)
          .lineTo(-2.7, 0.6)
          .lineTo(-3.7, 0)
          .lineTo(-3.2, -6)
          .lineTo(3.2, -6)
          .lineTo(3.2, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(1.9, -1.7, 3, -0.8)
          .curveTo(3.9, 0.2, 4, 1.9)
          .curveTo(4, 3.8, 2.7, 4.9)
          .curveTo(1.5, 6, -0.8, 6)
          .curveTo(-2.8, 6, -3.9, 5.3)
          .closePath();
        this.shape_112.setTransform(-155.65, -87.025);
        this.shape_113 = new doc.a.Shape();
        this.shape_113.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .curveTo(-3.5, 3.5, -2.4, 3.7)
          .curveTo(-1.7, 3.9, -0.8, 3.9)
          .curveTo(1.4, 3.9, 1.4, 2.1)
          .curveTo(1.4, 0.3, -0.9, 0.3)
          .lineTo(-1.9, 0.4)
          .lineTo(-2.7, 0.6)
          .lineTo(-3.7, 0)
          .lineTo(-3.3, -6)
          .lineTo(3.1, -6)
          .lineTo(3.1, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(2, -1.7, 2.9, -0.8)
          .curveTo(3.9, 0.2, 3.9, 1.9)
          .curveTo(3.9, 3.8, 2.7, 4.9)
          .curveTo(1.5, 6, -0.8, 6)
          .curveTo(-2.8, 6, -3.9, 5.3)
          .closePath();
        this.shape_113.setTransform(91.875, 151.075);
        this.shape_114 = new doc.a.Shape();
        this.shape_114.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.1, 6)
          .lineTo(-4.1, 4.2)
          .lineTo(-1.1, 1.3)
          .lineTo(0.6, -0.6)
          .lineTo(1.2, -1.6)
          .lineTo(1.3, -2.5)
          .curveTo(1.3, -3.3, 0.9, -3.6)
          .curveTo(0.6, -3.9, -0.1, -3.9)
          .curveTo(-0.8, -3.9, -1.4, -3.6)
          .curveTo(-2.1, -3.3, -2.8, -2.7)
          .lineTo(-4.1, -4.3)
          .curveTo(-3.3, -5, -2.7, -5.4)
          .curveTo(-2.2, -5.6, -1.4, -5.8)
          .curveTo(-0.8, -6, 0.1, -6)
          .curveTo(1.1, -6, 2, -5.6)
          .curveTo(2.9, -5.1, 3.3, -4.5)
          .curveTo(3.8, -3.7, 3.8, -2.8)
          .curveTo(3.8, -2, 3.5, -1.3)
          .curveTo(3.2, -0.5, 2.6, 0.2)
          .curveTo(2.1, 0.9, 0.5, 2.4)
          .lineTo(-1, 3.8)
          .lineTo(-1, 3.9)
          .lineTo(4.1, 3.9)
          .lineTo(4.1, 6)
          .closePath();
        this.shape_114.setTransform(82.475, 150.9);
        this.shape_115 = new doc.a.Shape();
        this.shape_115.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .curveTo(-3.5, 3.5, -2.5, 3.7)
          .curveTo(-1.7, 3.9, -0.9, 3.9)
          .curveTo(1.4, 3.9, 1.4, 2.1)
          .curveTo(1.4, 0.3, -0.9, 0.3)
          .lineTo(-1.9, 0.4)
          .lineTo(-2.7, 0.6)
          .lineTo(-3.7, 0)
          .lineTo(-3.3, -6)
          .lineTo(3.1, -6)
          .lineTo(3.1, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(2, -1.7, 2.9, -0.8)
          .curveTo(3.9, 0.2, 3.9, 1.9)
          .curveTo(3.9, 3.8, 2.7, 4.9)
          .curveTo(1.5, 6, -0.8, 6)
          .curveTo(-2.8, 6, -3.9, 5.3)
          .closePath();
        this.shape_115.setTransform(-82.425, -150.825);
        this.shape_116 = new doc.a.Shape();
        this.shape_116.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.9, 5.3)
          .lineTo(-3.9, 3.2)
          .curveTo(-3.4, 3.5, -2.5, 3.7)
          .curveTo(-1.7, 3.9, -0.9, 3.9)
          .curveTo(1.5, 3.9, 1.5, 2.1)
          .curveTo(1.5, 0.3, -1, 0.3)
          .lineTo(-1.9, 0.4)
          .lineTo(-2.7, 0.6)
          .lineTo(-3.7, 0)
          .lineTo(-3.2, -6)
          .lineTo(3.2, -6)
          .lineTo(3.2, -3.9)
          .lineTo(-1.1, -3.9)
          .lineTo(-1.3, -1.6)
          .lineTo(-1, -1.6)
          .lineTo(0.2, -1.7)
          .curveTo(1.9, -1.7, 2.9, -0.8)
          .curveTo(4, 0.2, 4, 1.9)
          .curveTo(4, 3.8, 2.7, 4.9)
          .curveTo(1.5, 6, -0.8, 6)
          .curveTo(-2.8, 6, -3.9, 5.3)
          .closePath();
        this.shape_116.setTransform(-91.85, -150.825);
        this.shape_117 = new doc.a.Shape();
        this.shape_117.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.1, 4.5)
          .curveTo(-4.1, 3.1, -4.1, 0)
          .curveTo(-4.1, -3.2, -3.1, -4.6)
          .curveTo(-2.1, -6.1, -0, -6.1)
          .curveTo(2.1, -6.1, 3.1, -4.5)
          .curveTo(4.1, -2.9, 4.1, 0)
          .curveTo(4.1, 3.1, 3.1, 4.6)
          .curveTo(2.1, 6.1, -0, 6.1)
          .curveTo(-2, 6.1, -3.1, 4.5)
          .closePath()
          .moveTo(-1.2, -3.1)
          .curveTo(-1.7, -2.1, -1.7, 0)
          .curveTo(-1.7, 2.1, -1.2, 3.1)
          .curveTo(-0.8, 4.1, -0, 4.1)
          .curveTo(0.9, 4.1, 1.2, 3.1)
          .curveTo(1.7, 2.1, 1.7, 0)
          .curveTo(1.7, -2.1, 1.2, -3.1)
          .curveTo(0.9, -4.1, -0, -4.1)
          .curveTo(-0.8, -4.1, -1.2, -3.1)
          .closePath();
        this.shape_117.setTransform(4.7, 174.325);
        this.shape_118 = new doc.a.Shape();
        this.shape_118.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-4.1, 5.4)
          .lineTo(-4.1, 3.3)
          .lineTo(-2.6, 3.9)
          .curveTo(-1.8, 4.1, -1, 4.1)
          .curveTo(0.3, 4.1, 0.9, 3.7)
          .curveTo(1.5, 3.2, 1.5, 2.3)
          .curveTo(1.5, 1.5, 0.8, 1.2)
          .curveTo(0.1, 0.8, -1.4, 0.8)
          .lineTo(-2.3, 0.8)
          .lineTo(-2.3, -1.1)
          .lineTo(-1.4, -1.1)
          .curveTo(0.1, -1.1, 0.6, -1.5)
          .curveTo(1.3, -1.8, 1.3, -2.7)
          .curveTo(1.3, -4, -0.4, -4)
          .curveTo(-1, -4, -1.6, -3.8)
          .curveTo(-2, -3.7, -2.9, -3.2)
          .lineTo(-4.1, -4.9)
          .curveTo(-2.5, -6.1, -0.2, -6.1)
          .curveTo(1.6, -6.1, 2.7, -5.3)
          .curveTo(3.7, -4.6, 3.7, -3.2)
          .curveTo(3.7, -2.2, 3.1, -1.4)
          .curveTo(2.4, -0.6, 1.2, -0.3)
          .lineTo(1.2, -0.3)
          .curveTo(2.6, -0.1, 3.3, 0.6)
          .curveTo(4.1, 1.3, 4.1, 2.5)
          .curveTo(4.1, 4.2, 2.8, 5.1)
          .curveTo(1.7, 6.1, -0.7, 6.1)
          .curveTo(-2.7, 6.1, -4.1, 5.4)
          .closePath();
        this.shape_118.setTransform(-4.725, 174.325);
        this.shape_119 = new doc.a.Shape();
        this.shape_119.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-3.1, 4.5)
          .curveTo(-4.1, 3, -4.1, 0)
          .curveTo(-4.1, -3.1, -3.1, -4.6)
          .curveTo(-2.1, -6.1, 0, -6.1)
          .curveTo(2, -6.1, 3.1, -4.5)
          .curveTo(4.1, -2.9, 4.1, 0)
          .curveTo(4.1, 3.1, 3.1, 4.6)
          .curveTo(2.2, 6.1, 0, 6.1)
          .curveTo(-2, 6.1, -3.1, 4.5)
          .closePath()
          .moveTo(-1.2, -3.1)
          .curveTo(-1.6, -2.3, -1.6, 0)
          .curveTo(-1.6, 2.2, -1.3, 3.1)
          .curveTo(-0.9, 4.1, 0, 4.1)
          .curveTo(0.9, 4.1, 1.3, 3.1)
          .curveTo(1.7, 2.1, 1.7, 0)
          .curveTo(1.7, -2.1, 1.3, -3.1)
          .curveTo(0.9, -4.1, 0, -4.1)
          .curveTo(-0.8, -4.1, -1.2, -3.1)
          .closePath();
        this.shape_119.setTransform(4.675, -174.275);
        this.shape_120 = new doc.a.Shape();
        this.shape_120.graphics
          .beginFill("#FFFFFF")
          .beginStroke()
          .moveTo(-2.1, 5.5)
          .curveTo(-3.1, 4.8, -3.6, 3.7)
          .curveTo(-4.2, 2.5, -4.2, 0.9)
          .curveTo(-4.2, -2.6, -2.7, -4.3)
          .curveTo(-1.2, -6, 1.8, -6)
          .lineTo(3.3, -5.9)
          .lineTo(3.3, -4)
          .curveTo(2.7, -4.1, 1.9, -4.1)
          .curveTo(0.7, -4.1, -0.2, -3.7)
          .curveTo(-1, -3.4, -1.4, -2.5)
          .curveTo(-1.8, -1.9, -1.9, -0.4)
          .lineTo(-1.8, -0.4)
          .curveTo(-0.9, -1.8, 0.8, -1.8)
          .curveTo(2.4, -1.8, 3.3, -0.8)
          .curveTo(4.2, 0.2, 4.2, 2)
          .curveTo(4.2, 3.8, 3.1, 4.9)
          .curveTo(2.1, 6, 0.2, 6)
          .curveTo(-1.1, 6, -2.1, 5.5)
          .closePath()
          .moveTo(-1.1, 0.6)
          .curveTo(-1.7, 1.1, -1.7, 1.8)
          .curveTo(-1.7, 2.7, -1.2, 3.4)
          .curveTo(-0.7, 4, 0.1, 4)
          .curveTo(0.9, 4, 1.3, 3.5)
          .curveTo(1.8, 3, 1.8, 2)
          .curveTo(1.8, 1.2, 1.4, 0.6)
          .curveTo(0.9, 0.2, 0.2, 0.2)
          .curveTo(-0.6, 0.1, -1.1, 0.6)
          .closePath();
        this.shape_120.setTransform(-4.725, -174.25);
        this.shape_121 = new doc.a.Shape();
        this.shape_121.graphics
          .beginFill()
          .beginStroke("#333333")
          .setStrokeStyle(2)
          .moveTo(190, 0)
          .curveTo(190, 38.7, 175.1, 73.9)
          .curveTo(160.6, 108.1, 134.4, 134.4)
          .curveTo(108.1, 160.6, 73.9, 175.1)
          .curveTo(38.7, 190, 0, 190)
          .curveTo(-38.7, 190, -74, 175.1)
          .curveTo(-108, 160.6, -134.3, 134.4)
          .curveTo(-160.7, 108.1, -175.1, 73.9)
          .curveTo(-190, 38.7, -190, 0)
          .curveTo(-190, -38.7, -175.1, -74)
          .curveTo(-160.7, -108, -134.3, -134.3)
          .curveTo(-108, -160.7, -74, -175.1)
          .curveTo(-38.7, -190, 0, -190)
          .curveTo(38.7, -190, 73.9, -175.1)
          .curveTo(108.1, -160.7, 134.4, -134.3)
          .curveTo(160.6, -108, 175.1, -74)
          .curveTo(190, -38.7, 190, 0)
          .closePath();
        this.shape_122 = new doc.a.Shape();
        this.shape_122.graphics
          .beginFill("#555555")
          .beginStroke()
          .moveTo(-73.9, 175)
          .curveTo(-108.1, 160.7, -134.4, 134.4)
          .curveTo(-160.6, 108.1, -175.1, 74)
          .curveTo(-190, 38.7, -190, -0)
          .curveTo(-190, -38.6, -175.1, -73.9)
          .curveTo(-160.6, -108.1, -134.4, -134.4)
          .curveTo(-108.1, -160.6, -73.9, -175.1)
          .curveTo(-38.6, -190, -0, -190)
          .curveTo(38.7, -190, 74, -175.1)
          .curveTo(108.1, -160.6, 134.4, -134.4)
          .curveTo(160.7, -108.1, 175, -73.9)
          .curveTo(190, -38.6, 190, -0)
          .curveTo(190, 38.7, 175, 74)
          .curveTo(160.7, 108.1, 134.4, 134.4)
          .curveTo(108.1, 160.7, 74, 175)
          .curveTo(38.7, 190, -0, 190)
          .curveTo(-38.6, 190, -73.9, 175)
          .closePath();
      })();
      var after =
        ((border = new doc.a.Shape()),
        (descriptionBackground = new doc.a.Shape()),
        (shape = new doc.a.Shape()),
        (fulcrum = new doc.a.Shape()),
        (BUTTON_BACKGROUND_BORDER_COLOR = "rgba(170, 170, 170, 0.6)"),
        border.graphics
          .beginFill(BUTTON_BACKGROUND_BORDER_COLOR)
          .beginStroke()
          .moveTo(-4, 66.5)
          .lineTo(-11, -25.5)
          .curveTo(-3, -28.2, -3, -37.5)
          .lineTo(-3, -72.5)
          .curveTo(-3, -74.1, -2.3, -75.2)
          .curveTo(-1.4, -76.5, -0, -76.5)
          .curveTo(1.4, -76.5, 2.2, -75.2)
          .curveTo(3, -74, 3, -72.5)
          .lineTo(3, -37.5)
          .curveTo(3, -28.2, 11, -25.5)
          .lineTo(4, 66.5)
          .lineTo(-0, 76.5)
          .closePath(),
        border.setTransform(0, -76.5),
        descriptionBackground.graphics
          .beginFill(BUTTON_BACKGROUND_BORDER_COLOR)
          .beginStroke()
          .moveTo(-8.5, 8.5)
          .curveTo(-12, 5, -12, -0)
          .curveTo(-12, -5, -8.5, -8.5)
          .curveTo(-5, -12, -0, -12)
          .curveTo(5, -12, 8.5, -8.5)
          .curveTo(12, -5, 12, -0)
          .curveTo(12, 5, 8.5, 8.5)
          .curveTo(5, 12, -0, 12)
          .curveTo(-5, 12, -8.5, 8.5)
          .closePath(),
        shape.graphics
          .beginFill(BUTTON_BACKGROUND_BORDER_COLOR)
          .beginStroke()
          .moveTo(-5.4, 43)
          .lineTo(-13, -17)
          .curveTo(-7.3, -19.9, -5, -23.1)
          .curveTo(-3, -26, -3, -30.5)
          .lineTo(-3, -51)
          .curveTo(-3, -52.6, -2.3, -53.7)
          .curveTo(-1.4, -55, -0, -55)
          .curveTo(1.4, -55, 2.2, -53.7)
          .curveTo(3, -52.6, 3, -51)
          .lineTo(3, -30.5)
          .curveTo(3, -26, 5, -23.1)
          .curveTo(7.2, -19.9, 13, -17)
          .lineTo(5.4, 43)
          .lineTo(-0, 55)
          .closePath(),
        shape.setTransform(0, -55),
        fulcrum.graphics
          .beginFill(BUTTON_BACKGROUND_BORDER_COLOR)
          .beginStroke()
          .moveTo(-9.9, 9.9)
          .curveTo(-14, 5.8, -14, -0)
          .curveTo(-14, -5.8, -9.9, -9.9)
          .curveTo(-5.8, -14, -0, -14)
          .curveTo(5.8, -14, 9.9, -9.9)
          .curveTo(14, -5.8, 14, -0)
          .curveTo(14, 5.8, 9.9, 9.9)
          .curveTo(5.8, 14, -0, 14)
          .curveTo(-5.8, 14, -9.9, 9.9)
          .closePath(),
        func({
          shape_0: border,
          shape_1: descriptionBackground,
          shape_2: shape,
          shape_3: fulcrum,
        }));
      jasmine.Clock = {
        bounds: {
          x: -191,
          y: -191,
          width: 382,
          height: 382,
        },
      };
      jasmine.Clock.rawGraphics = func(toFloat);
      jasmine.Clock.SecondHand = insert(jasmine.Clock.rawGraphics, req.a.range(0, 3));
      jasmine.Clock.MinuteHandHit = jasmine.Clock.rawGraphics[3];
      jasmine.Clock.MinuteHandLabel = insert(jasmine.Clock.rawGraphics, req.a.range(4, 10));
      jasmine.Clock.MinuteHand = insert(jasmine.Clock.rawGraphics, req.a.range(10, 12));
      jasmine.Clock.MinuteHandDisabled = insert(after, req.a.range(0, 1));
      jasmine.Clock.HourHandLabel = insert(jasmine.Clock.rawGraphics, req.a.range(12, 16));
      jasmine.Clock.HourHandHit = jasmine.Clock.rawGraphics[16];
      jasmine.Clock.HourHand = insert(jasmine.Clock.rawGraphics, req.a.range(17, 19));
      jasmine.Clock.HourHandDisabled = insert(after, req.a.range(2, 3));
      jasmine.Clock.Window = jasmine.Clock.rawGraphics[19];
      jasmine.Clock.WindowHighlight = jasmine.Clock.rawGraphics[20];
      jasmine.Clock.Gear = insert(jasmine.Clock.rawGraphics, req.a.range(21, 23));
      jasmine.Clock.RomanNumerals = insert(jasmine.Clock.rawGraphics, req.a.range(23, 49));
      jasmine.Clock.ArabicNumerals = insert(jasmine.Clock.rawGraphics, req.a.range(49, 64));
      jasmine.Clock.Face = insert(jasmine.Clock.rawGraphics, req.a.range(64, 98));
      jasmine.Clock.FiveLabels = insert(jasmine.Clock.rawGraphics, req.a.range(98, 123));
      var cat = $("SL7T");
      var canvas = $("Rh6l");
      var $music = $("qBZb");
      var logos_obj = $("JhVI");
      /** @type {string} */
      var name = "14px " + _this.d.DEFAULT_FONT_FAMILY;
      Particle.prototype = mutation()(_this.c.prototype);
      Particle.prototype.constructor = _this.c;
      /** @type {function(?, string): undefined} */
      var Tabs = Particle;
      /**
       * @param {string} obj2
       * @return {undefined}
       */
      Particle.prototype._setupDisplayComponents = function (obj2) {
        var methodsToOverwrite;
        var self = this._setupHourCounter();
        this.toggleHandle = this._setupToggleHandle(obj2);
        this.minuteHand = this._setupMinuteHand();
        this.hourHand = this._setupHourHand();
        this.fillWedge = this._setupFillWedge();
        this.hourCounterDisplay = self.display;
        this.hourCounter = self.text;
        this.hourCounterBacking = self.backing;
        /** @type {!Array} */
        methodsToOverwrite = [this.hourHand.display, this.minuteHand.display, this.fillWedge, this.toggleHandle.display, this.hourCounterDisplay];
        req.a.each(
          methodsToOverwrite,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this._placeComponents();
      };
      /**
       * @param {string} val
       * @return {?}
       */
      Particle.prototype._setupToggleHandle = function (val) {
        var area = this;
        return new _this.v(null, {
          initialState: val.active,
          draw: {
            init: function () {
              var m;
              var newNodeLists;
              this.defaultBacking = new doc.a.Bitmap(cat);
              /** @type {number} */
              this.defaultBacking.regX = 20;
              /** @type {number} */
              this.defaultBacking.regY = 35;
              this.defaultIcon = new doc.a.Bitmap(canvas);
              /** @type {number} */
              this.defaultIcon.regX = 12;
              /** @type {number} */
              this.defaultIcon.regY = 12;
              this.activeBacking = new doc.a.Bitmap($music);
              /** @type {number} */
              this.activeBacking.regX = 20;
              /** @type {number} */
              this.activeBacking.regY = 35;
              this.activeIcon = new doc.a.Bitmap(logos_obj);
              /** @type {number} */
              this.activeIcon.regX = 12;
              /** @type {number} */
              this.activeIcon.regY = 12;
              /** @type {!Array} */
              newNodeLists = [this.defaultBacking, this.activeBacking, this.defaultIcon, this.activeIcon];
              (m = this.display).addChild.apply(m, Object(event.a)(newNodeLists));
              this.display.hitArea = this.defaultBacking;
            },
            callback: function () {
              /** @type {number} */
              this.defaultIcon.rotation = -area.startAngle;
              /** @type {number} */
              this.defaultIcon.x = 0;
              /** @type {number} */
              this.defaultIcon.y = -15;
              /** @type {number} */
              this.activeIcon.rotation = -area.startAngle;
              /** @type {number} */
              this.activeIcon.x = 0;
              /** @type {number} */
              this.activeIcon.y = -15;
              /** @type {boolean} */
              this.defaultBacking.visible = !this.stateActive;
              /** @type {boolean} */
              this.defaultIcon.visible = !this.stateActive;
              this.activeBacking.visible = this.stateActive;
              this.activeIcon.visible = this.stateActive;
            },
          },
          clickCallback: function () {
            /** @type {boolean} */
            this.stateActive = !this.stateActive;
            /** @type {boolean} */
            area.active = this.stateActive;
            if (!area.active) {
              area.startAngle = area.endAngle;
            }
            area._placeComponents();
            area.draw();
          },
        });
      };
      /**
       * @return {?}
       */
      Particle.prototype._setupMinuteHand = function () {
        return new LogEntry(null, {
          handGraphics: scope.Clock.MinuteHandDisabled,
        });
      };
      /**
       * @return {?}
       */
      Particle.prototype._setupHourHand = function () {
        return new LogEntry(null, {
          handGraphics: scope.Clock.HourHandDisabled,
        });
      };
      /**
       * @return {?}
       */
      Particle.prototype._setupFillWedge = function () {
        return new doc.a.Shape();
      };
      /**
       * @return {?}
       */
      Particle.prototype._setupHourCounter = function () {
        var self = new doc.a.Container();
        var g = this._setupHourCounterText();
        var a = this._setupHourCounterBacking();
        return (
          self.addChild(a),
          self.addChild(g),
          {
            display: self,
            text: g,
            backing: a,
          }
        );
      };
      /**
       * @return {?}
       */
      Particle.prototype._setupHourCounterText = function () {
        var ctx = new doc.a.Text("", name, "white");
        return (ctx.textAlign = "center"), (ctx.textBaseline = "middle"), (ctx.regY = -2), ctx;
      };
      /**
       * @return {?}
       */
      Particle.prototype._setupHourCounterBacking = function () {
        return new doc.a.Shape();
      };
      /**
       * @return {undefined}
       */
      Particle.prototype._placeComponents = function () {
        var e;
        var diffZoom;
        /** @type {number} */
        e = this.radius - data.MINIMUM_CLOCK_RADIUS + 30;
        /** @type {number} */
        e = e / (data.MAXIMUM_CLOCK_RADIUS - data.MINIMUM_CLOCK_RADIUS);
        /** @type {number} */
        diffZoom = 10 + (e = e * 45);
        /** @type {number} */
        this.hourHand.angle = this.startAngle / 12;
        this.minuteHand.angle = this.startAngle; //Vikas-- Note: Angle of hands...
        this.toggleHandle.display.regY = this.radius + diffZoom;
        this.toggleHandle.display.rotation = this.startAngle;
        /** @type {number} */
        this.hourCounterDisplay.regY = this.radius - -15 + diffZoom;
        this.hourCounterDisplay.rotation = this.endAngle;
        /** @type {number} */
        this.hourCounter.rotation = -this.endAngle;
      };
      /**
       * @param {number} width
       * @return {undefined}
       */
      Particle.prototype.setRadius = function (width) {
        /** @type {number} */
        this.radius = width;
        /** @type {number} */
        this.hourHand.display.scaleX = width / (data.DEFAULT_CLOCK_RADIUS - data.GENERAL_CLOCK_FACE_RADIUS_PADDING);
        /** @type {number} */
        this.hourHand.display.scaleY = width / (data.DEFAULT_CLOCK_RADIUS - data.GENERAL_CLOCK_FACE_RADIUS_PADDING);
        /** @type {number} */
        this.minuteHand.display.scaleX = width / (data.DEFAULT_CLOCK_RADIUS - data.GENERAL_CLOCK_FACE_RADIUS_PADDING);
        /** @type {number} */
        this.minuteHand.display.scaleY = width / (data.DEFAULT_CLOCK_RADIUS - data.GENERAL_CLOCK_FACE_RADIUS_PADDING);
        this._placeComponents();
      };
      /**
       * @return {undefined}
       */
      Particle.prototype.draw = function () {
        //console.log("ASFSDFSF", Particle.prototype.draw.caller);//Vikas-- Note: Particle draw
        /** @type {string} */
        var color = this.startAngle <= this.endAngle ? "rgb(17, 138, 13)" : "rgb(179, 17, 18)";
        var i = parse()((this.endAngle - this.startAngle) / 360);
        var newItem = this.active && 0 !== i;
        this.hourHand.display.visible = this.active;
        this.minuteHand.display.visible = this.active;
        this.hourHand.draw();
        this.minuteHand.draw();
        this.toggleHandle.draw();
        this.fillWedge.visible = this.active;
        this._drawFillWedge();
        this.hourCounterBacking.visible = newItem;
        this.hourCounterBacking.graphics
          .clear()
          .beginFill(color)
          .drawCircle(0, 0, 15)
          .setStrokeStyle(1.5)
          .beginStroke("rgba(255, 255, 255, .5)")
          .drawCircle(0, 0, 14.25);
        this.hourCounter.visible = newItem;
        /** @type {string} */
        this.hourCounter.text = (i > 0 ? "+" : "") + i;
      };
      /**
       * @return {undefined}
       */
      Particle.prototype._drawFillWedge = function () {
        var TABS_ACTIVE_FILL_COLOR;
        var TABS_INACTIVE_FILL_COLOR;
        /** @type {number} */
        var n = this.endAngle - this.startAngle;
        /** @type {number} */
        var left = n % 720;
        if (this.startAngle === this.endAngle) {
          this.fillWedge.graphics
            .clear()
            .beginFill("rgba(17, 138, 13, .25)")
            .moveTo(0, 0)
            .arc(
              0,
              0,
              this.radius,
              ((this.startAngle % 360) - 90) * data.DEGREES_TO_RADIANS,
              ((this.startAngle % 360) + 10 - 90) * data.DEGREES_TO_RADIANS,
              false
            );
          this.fillWedge.graphics
            .beginFill("rgba(179, 17, 18, .25)")
            .moveTo(0, 0)
            .arc(
              0,
              0,
              this.radius,
              ((this.startAngle % 360) - 10 - 90) * data.DEGREES_TO_RADIANS,
              ((this.startAngle % 360) - 90) * data.DEGREES_TO_RADIANS,
              false
            );
        } else {
          if ((this.endAngle - this.startAngle) % 360 == 0) {
            if (this.endAngle - this.startAngle < 0) {
              /** @type {string} */
              TABS_ACTIVE_FILL_COLOR = Math.abs(left) < 360 ? "rgba(179, 17, 18, .50)" : "rgba(179, 17, 18, .25)";
              this.fillWedge.graphics
                .clear()
                .beginFill(TABS_ACTIVE_FILL_COLOR)
                .moveTo(0, 0)
                .arc(
                  0,
                  0,
                  this.radius,
                  ((this.startAngle % 360) - 90) * data.DEGREES_TO_RADIANS,
                  ((this.startAngle % 360) - 360 - 90) * data.DEGREES_TO_RADIANS,
                  this.endAngle - this.startAngle < 0
                );
            } else {
              /** @type {string} */
              TABS_ACTIVE_FILL_COLOR = Math.abs(left) < 360 ? "rgba(17, 138, 13, .50)" : "rgba(17, 138, 13, .25)";
              this.fillWedge.graphics
                .clear()
                .beginFill(TABS_ACTIVE_FILL_COLOR)
                .moveTo(0, 0)
                .arc(
                  0,
                  0,
                  this.radius,
                  ((this.startAngle % 360) - 90) * data.DEGREES_TO_RADIANS,
                  ((this.startAngle % 360) + 360 - 90) * data.DEGREES_TO_RADIANS,
                  this.endAngle - this.startAngle < 0
                );
            }
          } else {
            if (Math.abs(left) < 360) {
              if (n > 0) {
                /** @type {string} */
                TABS_ACTIVE_FILL_COLOR = "rgba(17, 138, 13, .25)";
                /** @type {string} */
                TABS_INACTIVE_FILL_COLOR = "rgba(17, 138, 13, .50)";
              } else {
                /** @type {string} */
                TABS_ACTIVE_FILL_COLOR = "rgba(179, 17, 18, .25)";
                /** @type {string} */
                TABS_INACTIVE_FILL_COLOR = "rgba(179, 17, 18, .50)";
              }
            } else {
              if (n > 0) {
                /** @type {string} */
                TABS_ACTIVE_FILL_COLOR = "rgba(17, 138, 13, .50)";
                /** @type {string} */
                TABS_INACTIVE_FILL_COLOR = "rgba(17, 138, 13, .25)";
              } else {
                /** @type {string} */
                TABS_ACTIVE_FILL_COLOR = "rgba(179, 17, 18, .50)";
                /** @type {string} */
                TABS_INACTIVE_FILL_COLOR = "rgba(179, 17, 18, .25)";
              }
            }
            this.fillWedge.graphics
              .clear()
              .beginFill(TABS_ACTIVE_FILL_COLOR)
              .moveTo(0, 0)
              .arc(
                0,
                0,
                this.radius,
                ((this.startAngle % 360) - 90) * data.DEGREES_TO_RADIANS,
                ((this.startAngle % 360) + (left % 360) - 90) * data.DEGREES_TO_RADIANS,
                this.endAngle - this.startAngle < 0
              );
            if (Math.abs(n) > 360) {
              this.fillWedge.graphics
                .beginFill(TABS_INACTIVE_FILL_COLOR)
                .moveTo(0, 0)
                .arc(
                  0,
                  0,
                  this.radius,
                  ((this.startAngle % 360) + (left % 360) - 90) * data.DEGREES_TO_RADIANS,
                  ((this.startAngle % 360) - 90) * data.DEGREES_TO_RADIANS,
                  this.endAngle - this.startAngle < 0
                );
            }
          }
        }
      };
      /**
       * @return {?}
       */
      Particle.prototype.getSaveData = function () {
        return {
          shown: this.display.visible,
          active: this.active,
          startTime: {
            hourAngle: (this.startAngle / 12) * data.DEGREES_TO_RADIANS,
            minuteAngle: this.startAngle * data.DEGREES_TO_RADIANS,
            secondAngle: 0,
          },
          endTime: {
            hourAngle: 0,
            minuteAngle: this.endAngle * data.DEGREES_TO_RADIANS,
            secondAngle: 0,
          },
        };
      };
      var accept = $("FLGM");
      var ok = $.n(accept);
      var __WEBPACK_IMPORTED_MODULE_14_date_fns_set_hours__ = $("/FZm");
      var isLeftButton = $.n(__WEBPACK_IMPORTED_MODULE_14_date_fns_set_hours__);
      var Colors = {
        Red: "#cf2828",
        Orange: "#e87300",
        Yellow: "#f5d800",
        Green: "#19ba00",
        Blue: "#0090de",
        Purple: "#990099",
        Transparent: "#ffffff",
      };
      var Foo = {
        Bar: "bar",
        Circle: "circle",
      };
      /** @type {string} */
      var Bar = Foo.Bar;
      start.prototype = mutation()(_this.c.prototype);
      start.prototype.constructor = _this.c;
      /** @type {function(?, ?): undefined} */
      var Array = start;
      /**
       * @param {string} data
       * @return {undefined}
       */
      start.prototype._setupDisplayComponents = function (data) {
        var comboPathName;
        /** @type {!Array} */
        var cell = [];
        this.border = new doc.a.Shape();
        this.fragments = this._setupFragments(data);
        this.fragmentOutlines = ok()((comboPathName = this.fragments)).call(comboPathName, function () {
          return new doc.a.Shape();
        });
        cell.push(this.border);
        req.a.each(req.a.pluck(this.fragments, "shape"), function (prisoner) {
          cell.push(prisoner);
        });
        cell.push.apply(cell, Object(event.a)(this.fragmentOutlines));
        req.a.each(
          cell,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
      };
      /**
       * @param {string} response
       * @return {?}
       */
      start.prototype._setupFragments = function (response) {
        var resolveShape;
        /** @type {!Array} */
        var data = [];
        return (
          req.a.isNumber(response.initialFragments)
            ? req.a.each(req.a.range(response.initialFragments), function () {
                resolveShape = new doc.a.Shape();
                data.push({
                  shape: resolveShape,
                  color: Colors.Transparent,
                });
              })
            : req.a.each(response.initialFragments, function (state) {
                resolveShape = new doc.a.Shape();
                data.push({
                  shape: resolveShape,
                  color: state.color,
                });
              }),
          data
        );
      };
      /**
       * @param {number} obj
       * @return {undefined}
       */
      start.prototype._refragment = function (obj) {
        var p;
        var shape1;
        var gradient;
        var overlapsEndcoor = req.a.isObject(obj) ? req.a.pluck(obj, "color") : {};
        var o = req.a.isNumber(obj) ? obj : obj.length;
        req.a.each(
          this.fragments,
          function (object) {
            this.display.removeChild(object.shape);
            delete object.shape;
          },
          this
        );
        req.a.each(
          this.fragmentOutlines,
          function (warning) {
            this.display.removeChild(warning);
          },
          this
        );
        /** @type {!Array} */
        this.fragments = [];
        /** @type {!Array} */
        this.fragmentOutlines = [];
        /** @type {number} */
        p = 0;
        for (; p < o; p++) {
          shape1 = new doc.a.Shape();
          gradient = new doc.a.Shape();
          this.fragments.push({
            shape: shape1,
            color: overlapsEndcoor[p] || Colors.Transparent,
          });
          this.fragmentOutlines.push(gradient);
          this.display.addChild(shape1);
          this.display.addChild(gradient);
        }
        this.fragmentCount = o;
      };
      /**
       * @return {undefined}
       */
      start.prototype._bindDispatcherEvents = function () {
        _this.f.on(
          data.Events.FRACTION_ENTITY_SET_FRAGMENT_COUNT,
          function (options) {
            if (req.a.contains(options.ids, this.id)) {
              this._refragment(options.newFragments);
              this.draw();
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            }
          },
          this
        );
      };
      /**
       * @return {undefined}
       */
      start.prototype.draw = function () {
        this.border.graphics.clear().setStrokeStyle(1).beginStroke("black");
        if (this.unitType === Foo.Bar) {
          this.border.graphics.drawRect(0, 0, this.width, this.height);
          this._drawBarFragments();
        } else {
          if (this.unitType === Foo.Circle) {
            this._drawCircleFragments();
          }
        }
      };
      /**
       * @return {undefined}
       */
      start.prototype._drawBarFragments = function () {
        /** @type {number} */
        var w = this.width / this.fragmentCount;
        req.a.each(
          this.fragments,
          function (node, index) {
            var color = node.color;
            if (node.color === Colors.Transparent) {
              node.shape.alpha = pipe()(data.TRANSPARENT_ALPHA_AFFIX, 0.0625);
            } else {
              node.shape.alpha = pipe()(data.COLOR_ALPHA_AFFIX, 0.0625);
            }
            node.shape.graphics
              .clear()
              .beginFill(color)
              .drawRect(index * w, 0, w, this.height);
            this.fragmentOutlines[index].graphics
              .clear()
              .setStrokeStyle(0.5)
              .beginStroke("black")
              .drawRect(index * w, 0, w, this.height);
          },
          this
        );
      };
      /**
       * @return {undefined}
       */
      start.prototype._drawCircleFragments = function () {
        var angleEndCurrent;
        var angleStartCurrent;
        /** @type {number} */
        var SLIDE_PAGE_ITEMS = this.fragmentCount > 0 ? 360 / this.fragmentCount : 0;
        req.a.each(
          this.fragments,
          function (node, i) {
            var shape = this.fragmentOutlines[i];
            var color = node.color;
            if (node.color === Colors.Transparent) {
              /** @type {number} */
              node.shape.alpha = pipe()(data.TRANSPARENT_ALPHA_AFFIX, 16) / 256;
            } else {
              /** @type {number} */
              node.shape.alpha = pipe()(data.COLOR_ALPHA_AFFIX, 16) / 256;
            }
            /** @type {number} */
            angleEndCurrent = (i * SLIDE_PAGE_ITEMS - 90) * data.DEGREES_TO_RADIANS;
            /** @type {number} */
            angleStartCurrent = ((i + 1) * SLIDE_PAGE_ITEMS - 90) * data.DEGREES_TO_RADIANS;
            node.shape.graphics.clear().beginFill(color);
            shape.graphics.clear().setStrokeStyle(0.5).beginStroke("black");
            if (1 !== this.fragmentCount) {
              node.shape.graphics.moveTo(this.width / 2, this.height / 2);
              shape.graphics.moveTo(this.width / 2, this.height / 2);
            }
            node.shape.graphics.arc(this.width / 2, this.height / 2, this.width / 2, angleEndCurrent, angleStartCurrent);
            shape.graphics.arc(this.width / 2, this.height / 2, this.width / 2, angleEndCurrent, angleStartCurrent);
            if (1 !== this.fragmentCount) {
              node.shape.graphics.lineTo(this.width / 2, this.height / 2);
              shape.graphics.lineTo(this.width / 2, this.height / 2);
            }
          },
          this
        );
      };
      /**
       * @param {!Object} data
       * @param {!Object} key
       * @return {?}
       */
      start.prototype._getFragmentsAlongLine = function (data, key) {
        return require()(req.a).call(
          req.a,
          this.fragments,
          function (tilesPerTexture, navSettings) {
            return this._lineIntersectsFragment(data, key, tilesPerTexture, navSettings);
          },
          this
        );
      };
      /**
       * @param {!Object} type
       * @param {!Object} s
       * @param {!Object} n
       * @param {number} settings
       * @return {?}
       */
      start.prototype._lineIntersectsFragment = function (type, s, n, settings) {
        var b = this._getFragmentLines(n, settings);
        return req.a.any(
          b,
          function (line3d) {
            return this._lineIntersectsLine(type, s, line3d.a, line3d.b);
          },
          this
        );
      };
      /**
       * @param {!Object} e
       * @param {number} params
       * @return {?}
       */
      start.prototype._getFragmentLines = function (e, params) {
        /** @type {!Array} */
        var idx = [];
        switch (this.unitType) {
          case Foo.Bar:
            idx = this._getBarFragmentLines(e, params);
            break;
          case Foo.Circle:
            idx = this._getCircleFragmentLines(e, params);
        }
        return idx;
      };
      /**
       * @param {!Object} o
       * @return {?}
       */
      start.prototype._getBarFragmentLines = function (o) {
        /** @type {!Array} */
        var pixelBuffer = [
          o.display.localToGlobal(o.x + o.range.start, o.y),
          o.display.localToGlobal(o.x + o.range.stop, o.y),
          o.display.localToGlobal(o.x + o.range.stop, o.y + o.height),
          o.display.localToGlobal(o.x + o.range.start, o.y + o.height),
        ];
        return [
          {
            a: pixelBuffer[0],
            b: pixelBuffer[1],
          },
          {
            a: pixelBuffer[1],
            b: pixelBuffer[2],
          },
          {
            a: pixelBuffer[2],
            b: pixelBuffer[3],
          },
          {
            a: pixelBuffer[3],
            b: pixelBuffer[0],
          },
        ];
      };
      /**
       * @param {!Object} radius
       * @param {number} l
       * @return {?}
       */
      start.prototype._getCircleFragmentLines = function (radius, l) {
        var bearingRad;
        var newangle2;
        var pos;
        /** @type {number} */
        var oldw = this.fragmentCount > 0 ? 360 / this.fragmentCount : 0;
        return (
          (bearingRad = (l * oldw - 90) * data.DEGREES_TO_RADIANS),
          (newangle2 = ((l + 1) * oldw - 90) * data.DEGREES_TO_RADIANS),
          [
            {
              a: (pos = this.display.localToGlobal(this.x, this.y)),
              b: this.display.localToGlobal(
                (this.width / 2) * Math.cos(bearingRad) + this.width / 2,
                (this.height / 2) * Math.sin(bearingRad) + this.height / 2
              ),
            },
            {
              a: pos,
              b: this.display.localToGlobal(
                (this.width / 2) * Math.cos(newangle2) + this.width / 2,
                (this.height / 2) * Math.sin(newangle2) + this.height / 2
              ),
            },
          ]
        );
      };
      /**
       * @param {!Object} event
       * @param {!Object} item
       * @param {!Object} element
       * @param {!Object} screen
       * @return {?}
       */
      start.prototype._lineIntersectsLine = function (event, item, element, screen) {
        var beginAngle;
        var height;
        /** @type {boolean} */
        var xGrid = false;
        /** @type {number} */
        var r = (item.x - event.x) * (screen.y - element.y) - (item.y - event.y) * (screen.x - element.x);
        /** @type {number} */
        var beginDistance = (event.y - element.y) * (screen.x - element.x) - (event.x - element.x) * (screen.y - element.y);
        /** @type {number} */
        var width = (event.y - element.y) * (item.x - event.x) - (event.x - element.x) * (item.y - event.y);
        return (
          0 !== r && ((height = width / r), (xGrid = (beginAngle = beginDistance / r) >= 0 && beginAngle <= 1 && height >= 0 && height <= 1)), xGrid
        );
      };
      /**
       * @return {?}
       */
      start.prototype.clone = function () {
        return new start(null, this._copyCriticalProperties());
      };
      /**
       * @return {?}
       */
      start.prototype._copyCriticalProperties = function () {
        return {
          unitType: this.unitType,
          position: {
            x: this.x,
            y: this.y,
            z: this.display.parent ? action()(req.a).call(req.a, this.display.parent.children, this.display) : 0,
          },
          dimensions: {
            width: this.width,
            height: this.height,
          },
          fillMode: this.fillMode,
          initialFragments: this.fragments,
        };
      };
      start.FragmentColors = Colors;
      start.UnitTypes = Foo;
      var url = $("Fo0n");
      var map = {
        Red: "#cf2828",
        Orange: "#e87300",
        Yellow: "#f5d800",
        Green: "#19ba00",
        Blue: "#0090de",
        Purple: "#990099",
        Transparent: "#ffffff",
      };
      /** @type {string} */
      var spatialreference = map.Transparent;
      Circle.prototype = mutation()(_this.c.prototype);
      Circle.prototype.constructor = _this.c;
      /** @type {function(?, number): undefined} */
      var CIRCLE = Circle;
      /**
       * @param {string} obj
       * @return {undefined}
       */
      Circle.prototype._setupDisplayComponents = function (obj) {
        var methodsToOverwrite;
        this.toggleHandle = this._setupRotationHandle();
        this.handleConnector = new doc.a.Shape();
        this.fraction = this._setupFraction(obj);
        this.cover = this._setupFractionCover();
        /** @type {!Array} */
        methodsToOverwrite = [this.toggleHandle.display, this.handleConnector, this.fraction.display, this.cover];
        req.a.each(
          methodsToOverwrite,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        this._placeComponents();
      };
      /**
       * @return {?}
       */
      Circle.prototype._setupRotationHandle = function () {
        var particle = this;
        return new _this.j(this.display, {
          dimensions: {
            width: 50,
            height: 50,
          },
          draw: {
            init: function () {
              this.icon = new doc.a.Bitmap(url);
              /** @type {number} */
              this.icon.regX = this.width / 2;
              /** @type {number} */
              this.icon.regY = this.height / 2;
              this.display.addChild(this.icon);
              this.display.hitArea = this.icon;
            },
            callback: function () {
              /** @type {number} */
              this.icon.rotation = -this.display.rotation;
            },
          },
          mousedown: function () {},
          pressmove: function () {
            var x = this.x;
            var y = this.y;
            var startPoint = this.interactionState.previousPosition;
            var box = this.interactionState.currentPosition;
            /** @type {number} */
            var nsdfc = Math.atan2(y - startPoint.y, x - startPoint.x);
            /** @type {number} */
            var delta = Math.atan2(y - box.y, x - box.x) - nsdfc;
            /** @type {number} */
            delta = delta * data.RADIANS_TO_DEGREES;
            particle.angle += delta;
            particle._placeComponents(); //Vikas--Note: add all info about colck hands
            particle.draw();
          },
          pressup: function () {
            particle.snapFraction();
          },
        });
      };
      /**
       * @param {!Object} properties
       * @return {?}
       */
      Circle.prototype._setupFraction = function (properties) {
        var splitter;
        var g;
        return (
          (g = {
            unitType: Array.UnitTypes.Circle,
            dimensions: {
              width: 2 * properties.radius,
              height: 2 * properties.radius,
            },
            fillMode: properties.fillMode,
            initialFragments: properties.initialFragments,
          }),
          ((splitter = new Array(null, g)).display.regX = properties.radius),
          (splitter.display.regY = properties.radius),
          splitter
        );
      };
      /**
       * @return {?}
       */
      Circle.prototype._setupFractionCover = function () {
        return new doc.a.Shape();
      };
      /**
       * @return {undefined}
       */
      Circle.prototype._bindDispatcherEvents = function () {
        _this.f.on(
          data.Events.FRACTION_ENTITY_SET_FRAGMENT_COUNT,
          function (options) {
            if (req.a.contains(options.ids, this.fraction.id)) {
              this.draw();
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            }
          },
          this
        );
        _this.f.on(
          data.Events.FRACTION_PICK_PALETTE_SHOW,
          function () {
            this._tempFragments = this.fraction.fragments;
          },
          this
        );
        _this.f.on(
          data.Events.FRACTION_PICK_PALETTE_HIDE,
          function () {
            delete this._tempFragments;
          },
          this
        );
      };
      /**
       * @return {undefined}
       */
      Circle.prototype._placeComponents = function () {
        this.toggleHandle.x = this.radius;
        this.toggleHandle.y = this.radius;
        /** @type {number} */
        this.toggleHandle.icon.y = -this.toggleHandle.height / 2 - this.radius - 20;
        this.toggleHandle.display.rotation = this.angle;
        this.fraction.x = this.radius;
        this.fraction.y = this.radius;
        this.fraction.display.rotation = this.angle;
      };
      /**
       * @param {number} radius
       * @return {undefined}
       */
      Circle.prototype.setRadius = function (radius) {
        /** @type {number} */
        this.radius = radius;
        /** @type {number} */
        this.width = 2 * this.radius;
        /** @type {number} */
        this.height = 2 * this.radius;
        /** @type {number} */
        this.fraction.width = 2 * this.radius;
        /** @type {number} */
        this.fraction.height = 2 * this.radius;
        this.fraction.display.regX = this.radius;
        this.fraction.display.regY = this.radius;
        this._placeComponents();
      };
      /**
       * @param {string} val
       * @param {string} color
       * @return {undefined}
       */
      Circle.prototype.setColorMode = function (val, color) {
        var num_elements;
        if (req.a.isBoolean(val)) {
          /** @type {string} */
          this.fillMode = val;
          this.fraction.fillMode = this.fillMode;
          this.fraction.display.mouseEnabled = this.fillMode;
        }
        if (req.a.isString(color)) {
          num_elements = req.a.findKey(Array.FragmentColors, function (excludedColor) {
            return excludedColor === color;
          });
          /** @type {string} */
          this.fraction.fillColor = color;
          this.coverFillColor = map[num_elements];
        }
      };
      /**
       * @return {undefined}
       */
      Circle.prototype.snapFraction = function () {
        /** @type {number} */
        var angle = 6 * Math.round(this.angle / 6);
        /** @type {number} */
        this.angle = angle;
        this._placeComponents();
      };
      /**
       * @return {?}
       */
      Circle.prototype.getFragmentCount = function () {
        return this.fraction.fragments.length;
      };
      /**
       * @return {undefined}
       */
      Circle.prototype.draw = function () {
        var pane3 = _this.c.getFirstParentEntity(this.display.parent);
        /** @type {number} */
        var angleRadians = (this.angle + -90) * data.DEGREES_TO_RADIANS;
        this.toggleHandle.display.visible = pane3.selected && this.getFragmentCount() > 0;
        this.toggleHandle.draw();
        this.handleConnector.graphics.clear();
        if (this.toggleHandle.display.visible) {
          this.handleConnector.graphics
            .beginStroke("black")
            .moveTo(Math.cos(angleRadians) * this.radius + this.width / 2, Math.sin(angleRadians) * this.radius + this.height / 2)
            .lineTo(Math.cos(angleRadians) * (this.radius + 20) + this.width / 2, Math.sin(angleRadians) * (this.radius + 20) + this.height / 2);
        }
        /** @type {boolean} */
        this.fraction.visible = this.getFragmentCount() > 0;
        this.fraction.draw();
        this.cover.visible = !(this.getFragmentCount() > 0) && this.fillMode;
        /** @type {number} */
        this.cover.alpha = pipe()(20, 16) / 256;
        this.cover.graphics.clear().beginFill(this.coverFillColor).drawCircle(this.radius, this.radius, this.radius);
      };
      /**
       * @return {?}
       */
      Circle.prototype.clone = function () {
        return new Circle(null, this._copyCriticalProperties());
      };
      /**
       * @return {?}
       */
      Circle.prototype.getSaveData = function () {
        var value;
        return {
          angle: this.angle * data.DEGREES_TO_RADIANS,
          fragments: ok()((value = this.fraction.fragments)).call(value, function (state) {
            return {
              color: state.color,
            };
          }),
          shown: this.display.visible,
        };
      };
      /**
       * @return {?}
       */
      Circle.prototype._copyCriticalProperties = function () {
        var e = this.fraction._copyCriticalProperties();
        return {
          initialAngle: this.angle,
          initialFragments: e.initialFragments,
          radius: this.radius,
          fillMode: this.fillMode,
        };
      };
      var modifier = {
        None: "none",
        ElapsedTime: "elapsedTime",
        FractionControl: "fractionControl",
      };
      /** @type {string} */
      var modifiers = modifier.None;
      /** @type {number} */
      var currentAnime = data.DEFAULT_CLOCK_RADIUS;
      var fill = data.COLOR_NEUTRAL_BASE;
      /** @type {string} */
      var Et = Array.FragmentColors.Red;
      var rules = {
        Arabic: "arabic",
        Blank: "blank",
        Increments: "increments",
        Roman: "roman",
      };
      /** @type {string} */
      var rulelength = rules.Arabic;
      options.prototype = mutation()(_this.s.prototype);
      options.prototype.constructor = _this.s;
      /** @type {function(?, !Object): undefined} */
      var selection = options;
      /**
       * @return {undefined}
       */
      options.prototype.bindDispatcherEvents = function () {
        _this.f.on(
          data.Events.HAND_CHANGED,
          function (e) {
            if (e.id === this.minuteHand.id || e.id === this.hourHand.id) {
              if ((e.animated ? this._animateHandChanged(e) : this._jumpHandChanged(e), 0 !== this.secondHand.angle)) {
                var c = new doc.a.Event(data.Events.SET_RUN_STATE);
                c.set({
                  ids: [this.runJumpControl.runControl.id],
                  newState: CatchEntry.RunStates.RESET,
                  isHandChanging: true,
                });
                _this.f.dispatchEvent(c);
              }
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            }
          },
          this
        );
        _this.f.on(
          data.Events.SET_SELECTION_CLOCK_TYPE,
          function (options) {
            if (req.a.contains(options.ids, this.id)) {
              this.setClockType(options.clockType);
            }
          },
          this
        );
        _this.f.on(
          data.Events.SET_SELECTION_CLOCK_HAND_VISIBILITY,
          function (options) {
            if (req.a.contains(options.ids, this.id)) {
              this.setHandVisibility(options.hand, options.setTo);
            }
          },
          this
        );
        _this.f.on(
          data.Events.SET_SELECTION_CLOCK_HAND_LABEL_VISIBILITY,
          function (options) {
            if (req.a.contains(options.ids, this.id)) {
              this.setHandLabelVisibility(options.setTo);
            }
          },
          this
        );
        _this.f.on(
          data.Events.DIGITAL_READOUT_ADJUSTMENT,
          function (itemToRemove) {
            if (itemToRemove.id === this.digitalReadout.id) {
              this._handleReadoutAdjustment(itemToRemove);
            }
          },
          this
        );
        _this.f.on(
          data.Events.TOGGLE_SELECTION_DIGITAL_READOUT_MODE,
          function (options) {
            if (req.a.contains(options.id, this.id)) {
              /** @type {boolean} */
              this.handleActive = false;
              this.digitalReadoutMode = req.a.isBoolean(options.setTo) ? options.setTo : !this.digitalReadoutMode;
              this._placeComponents();
              this.draw();
            }
          },
          this
        );
        _this.f.on(
          data.Events.TOGGLE_SELECTION_RUN_JUMP_MODE,
          function (options) {
            var deviceOrientationEvent;
            if (req.a.contains(options.id, this.id)) {
              /** @type {boolean} */
              this.handleActive = false;
              this.runJumpMode = req.a.isBoolean(options.setTo) ? options.setTo : !this.runJumpMode;
              if (!this.runJumpMode) {
                (deviceOrientationEvent = new doc.a.Event(data.Events.SET_RUN_STATE)).set({
                  ids: [this.runJumpControl.runControl.id],
                  newState: CatchEntry.RunStates.RESET,
                });
                _this.f.dispatchEvent(deviceOrientationEvent);
              }
              this._placeComponents();
              this.draw();
            }
          },
          this
        );
        _this.f.on(
          data.Events.TOGGLE_SELECTION_ELAPSED_TIME_MODE,
          function (options) {
            if (req.a.contains(options.id, this.id)) {
              /** @type {boolean} */
              this.handleActive = false;
              this.elapsedTimeMode = req.a.isBoolean(options.setTo) ? options.setTo : !this.elapsedTimeMode;
              if (this.elapsedTimeMode) {
                /** @type {string} */
                this.activeMajorControl = modifier.ElapsedTime;
              }
              /** @type {boolean} */
              this.digitalReadout.active = false;
              /** @type {boolean} */
              this.digitalReadout.enabled = !this.elapsedTimeMode;
              this._placeComponents();
              this.draw();
            }
          },
          this
        );
        _this.f.on(
          data.Events.TOGGLE_SELECTION_TELL_TIME_MODE,
          function (options) {
            if (req.a.contains(options.id, this.id)) {
              /** @type {boolean} */
              this.handleActive = false;
              this.tellTimeMode = req.a.isBoolean(options.setTo) ? options.setTo : !this.tellTimeMode;
              this._placeComponents();
              this.draw();
            }
          },
          this
        );

        _this.f.on(
          data.Events.FRACTION_PICK_PALETTE_SHOW,
          function (message) {
            if (message.targetEntity === this) {
              /** @type {boolean} */
              this.handleActive = false;
              /** @type {string} */
              this.activeMajorControl = modifier.FractionControl;
              this.draw();
            }
          },
          this
        );
        _this.f.on(
          data.Events.FRACTION_PICK_PALETTE_HIDE,
          function () {
            this.draw();
          },
          this
        );
        _this.f.on(
          data.Events.TOGGLE_SELECTION_FRACTION_MODE,
          function (options) {
            if (req.a.contains(options.id, this.id)) {
              this.fractionMode = req.a.isBoolean(options.setTo) ? options.setTo : !this.fractionMode;
              /** @type {boolean} */
              this.digitalReadout.active = false;
              this._placeComponents();
              this.draw();
            }
          },
          this
        );
        _this.f.on(
          data.Events.TOGGLE_FRACTION_FILL_MODE,
          function (options) {
            this.fractionFillMode = req.a.isBoolean(options.setTo) ? options.setTo : !this.fractionFillMode;
            this.setColorMode(options.newColor);
          },
          this
        );
        _this.f.on(
          data.Events.DIGITAL_READOUT_INPUT_TEXT_CHANGE,
          function (params) {
            if (params.id === this.digitalReadout.id) {
              if ("hours" === params.hoursOrMinutes) {
                this.setTime(params.newTime, this.getReadableMinutes());
              } else {
                if ("minutes" === params.hoursOrMinutes) {
                  this.setTime(this.getHours(), params.newTime);
                }
              }
            }
          },
          this
        );
        _this.f.on(
          data.Events.TELL_TIME_BUTTON_CLICK,
          function (params) {
            if (params.id === this.tellTime.id) {
              this.tellTime.timeEnabled = ! this.tellTime.timeEnabled;
              this.tellTime._setupDisplayComponents();
              var h = parseInt(this.digitalReadout.hours.text),
                  m = parseInt(this.digitalReadout.minutes.text);
              this.tellTime.setTime(h,m);
              this.draw();
              //_this.f.dispatchEvent(_this.d.STAGE_UPDATE);  
              }
          },
          this
        );
        _this.f.on(
          data.Events.JUMP_BY_AMOUNT,
          function (data) {
            var m;
            var kobetuesi_;
            if (req.a.contains(data.ids, this.runJumpControl.jumpControl.id)) {
              m = this.getHours();
              kobetuesi_ = this.getReadableMinutes();
              this.setTime(m, kobetuesi_ + data.jumpAmount);
              this.draw();
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            }
          },
          this
        );
        _this.f.on(
          data.Events.SET_RUN_STATE,
          function (event) {
            var nb_class;
            if (req.a.contains(event.ids, this.runJumpControl.runControl.id)) {
              this.runningState = event.newState;
              if (this.runningState === CatchEntry.RunStates.PLAY) {
                (function init(ctx) {
                  var phiDelta;
                  var angle = ctx.secondHand.angle;
                  doc.a.Tween.get(ctx.secondHand, {
                    onChange: function () {
                      /** @type {number} */
                      phiDelta = ctx.secondHand.angle - angle;
                      angle = ctx.secondHand.angle;
                      ctx._jumpHandChanged({
                        id: ctx.minuteHand.id,
                        newAngle: ctx.minuteHand.angle + phiDelta / 60,
                      });
                      ctx.draw();
                      _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
                    },
                    onComplete: function () {
                      ctx.draw();
                      _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
                      if (ctx.runningState === CatchEntry.RunStates.PLAY) {
                        init(ctx);
                      }
                    },
                  }).to(
                    {
                      angle: ctx.secondHand.angle + 360,
                    },
                    6e4
                  );
                })(this);
              } else {
                if (this.runningState === CatchEntry.RunStates.RESET) {
                  update_nb_class((nb_class = this));
                  /** @type {number} */
                  nb_class.secondHand.angle = 0;
                  nb_class.runningState = CatchEntry.STOP;
                  if (!event.isHandChanging) {
                    this.snapHands();
                  }
                } else {
                  update_nb_class(this);
                }
              }
            }
          },
          this
        );
      };
      /**
       * @return {undefined}
       */
      options.prototype.bindDisplayEvents = function () {
        this.display.on(
          _this.d.SELECT_EVENT,
          function (options) {
            if (!req.a.contains(options.ids, this.id)) {
              var c = new doc.a.Event(data.Events.DIGITAL_READOUT_TOGGLE_ACTIVE);
              c.set({
                ids: [this.digitalReadout.id],
                setTo: false,
              });
              _this.f.dispatchEvent(c);
            }
            var c = new doc.a.Event(data.Events.JUMP_TOGGLE_ACTIVE);
            c.set({
              ids: [this.runJumpControl.jumpControl.id],
              setTo: req.a.contains(options.ids, this.id),
            });
            _this.f.dispatchEvent(c);
          },
          this
        );
      };
      /**
       * @param {!Object} e
       * @return {undefined}
       */
      options.prototype.setupDisplayComponents = function (e) {
        //console.log("step 1: options.prototype.setupDisplayComponents");
        var m;
        var clock = this.setupClockHands(e);
        var i = this.setupGearBox();
        var this_area = this.setupDigitalReadout(e); //Vikas Step: 1
        var tell_time = this.setupTellTime(e); //Vikas Note: Step1 for tell time
        var intervalGroups = this.setupRunJumpControl(e);
        var elapsedTime = this.setupElapsedTime(e);
        var sourceatt = this.setupFractionControl(e);
        this.selectionHighlight = new doc.a.Shape(this.createSelectionHighlightGraphics());
        this.handle = this.setupResizeHandle();
        this.fiveLabels = new doc.a.Shape(scope.Clock.FiveLabels);
        this.face = new doc.a.Shape(scope.Clock.Face);
        this.arabicNumerals = new doc.a.Shape(scope.Clock.ArabicNumerals);
        this.romanNumerals = new doc.a.Shape(scope.Clock.RomanNumerals);
        this.gearBox = i;
        this.digitalReadout = this_area;
        this.runJumpControl = intervalGroups;
        this.elapsedTime = elapsedTime;
        this.tellTime = tell_time;
        this.fractionControl = sourceatt;
        this.hourHand = clock.hourHand;
        this.minuteHand = clock.minuteHand;
        this.secondHand = clock.secondHand;
        this.clockFaceContainer = new doc.a.Container();
        /** @type {!Array} */
        this.clockFaceComponents = [];
        this.clockFaceComponents = req.a.union(this.clockFaceComponents, [
          this.fiveLabels,
          this.face,
          this.arabicNumerals,
          this.romanNumerals,
          this.gearBox.display,
        ]);
        this.clockFaceComponents = req.a.union(this.clockFaceComponents, req.a.pluck(this.minorTicks, "display"));
        this.clockFaceComponents = req.a.union(this.clockFaceComponents, req.a.pluck(this.majorTicks, "display"));
        req.a.each(
          this.clockFaceComponents,
          function (_childName) {
            this.clockFaceContainer.addChild(_childName);
          },
          this
        );
        this.clockHandsContainer = new doc.a.Container();
        /** @type {!Array} */
        this.clockHandsComponents = [];
        this.clockHandsComponents = req.a.union(this.clockHandsComponents, [this.hourHand.display, this.minuteHand.display, this.secondHand.display]);
        req.a.each(
          this.clockHandsComponents,
          function (_childName) {
            this.clockHandsContainer.addChild(_childName);
          },
          this
        );
        /** @type {!Array} */
        var searchPipeline = [
          this.selectionHighlight,
          this.handle.display,
          this.clockFaceContainer,
          this.elapsedTime.display,
          this.clockHandsContainer,
          this.fractionControl.display,
          this.runJumpControl.display,
          this.digitalReadout.display,
          this.tellTime.display, //Vikas Note: added for tell time
        ];
        (m = this.display).addChild.apply(m, searchPipeline);
      };
      /**
       * @return {?}
       */
      options.prototype.createSelectionHighlightGraphics = function () {
        var g = new doc.a.Graphics();
        var radius = this.radius + 10;
        return (
          this.clockType !== rules.Increments && (radius = radius - data.GENERAL_CLOCK_FACE_RADIUS_PADDING * this.scale),
          g
            .setStrokeStyle(12)
            .beginStroke("#6697c4") //Color of clock selection
            .drawCircle(this.radius, this.radius, radius),
          g
        );
      };
      /**
       * @return {?}
       */
      options.prototype.setupResizeHandle = function () {
        var e = this;
        return new _this.j(this.display, {
          topmostParent: this.topmostParent,
          dimensions: {
            width: 45,
            height: 40,
          },
          fillColor: fill,
          strokeThickness: 0,
          draw: {
            init: function () {
              this.corner = new doc.a.Shape();
              this.display.addChild(this.corner);
              /** @type {string} */
              this.display.cursor = "pointer";
            },
            callback: function () {
              /** @type {number} */
              var x = 0.25 * this.width + 9;
              /** @type {number} */
              var startX = 0.8 * this.width - 9;
              this.corner.graphics.clear();
              this.corner.graphics.beginFill(this.fillColor);
              this.corner.graphics.drawRoundRectComplex(0, -this.height / 2, this.width, this.height, 0, 20, 20, 0);
              this.corner.graphics
                .setStrokeStyle(5)
                .beginStroke("white")
                .moveTo(x - 1, 0)
                .lineTo(startX + 1, 0)
                .endStroke();
              this.corner.graphics
                .beginFill("white")
                .moveTo(x, 9)
                .lineTo(x - 9, 0)
                .lineTo(x, -9)
                .endFill();
              this.corner.graphics
                .beginFill("white")
                .moveTo(startX, 9)
                .lineTo(startX + 9, 0)
                .lineTo(startX, -9)
                .endFill();
              this.corner.rotation = this.angle;
            },
          },
          mousedown: function () {},
          pressmove: function (eventData) {
            var event = {};
            var deltaX = this.interactionState.deltaX;
            var deltaY = this.interactionState.deltaY;
            /** @type {number} */
            var button = deltaX / -Math.cos(this.angle * _this.d.DEGREES_TO_RADIANS);
            /** @type {number} */
            var undefined = deltaY / -Math.sin(this.angle * _this.d.DEGREES_TO_RADIANS);
            /** @type {number} */
            var newValue = Math.abs(deltaX) > Math.abs(deltaY) ? button : undefined;
            /** @type {!Object} */
            event.nativeEvent = eventData;
            event.deltaX = deltaX;
            event.deltaY = deltaY;
            /** @type {number} */
            event.amountX = button;
            /** @type {number} */
            event.amountY = undefined;
            /** @type {number} */
            event.amount = newValue;
            event.handle = this;
            e.resize(event);
          },
          pressup: function () {
            e.display.dispatchEvent(_this.d.RELEASE_ENTITY_EVENT);
          },
        });
      };
      /**
       * @param {!Object} a22
       * @return {?}
       */
      options.prototype.setupClockHands = function (a22) {
        return {
          minuteHand: new LogEntry(null, {
            handGraphics: scope.Clock.MinuteHand,
            handLabel: scope.Clock.MinuteHandLabel,
            labelOn: a22.handLabelsOn,
            handHitArea: scope.Clock.MinuteHandHit,
            topmostParent: this.topmostParent,
          }),
          hourHand: new LogEntry(null, {
            handGraphics: scope.Clock.HourHand,
            handLabel: scope.Clock.HourHandLabel,
            labelOn: a22.handLabelsOn,
            handHitArea: scope.Clock.HourHandHit,
            topmostParent: this.topmostParent,
          }),
          secondHand: new LogEntry(null, {
            handGraphics: scope.Clock.SecondHand,
            topmostParent: this.topmostParent,
          }),
        };
      };
      /**
       * @return {?}
       */
      options.prototype.setupGearBox = function () {
        return new K(null, {
          gearGraphics: scope.Clock.Gear,
          highlightGraphics: scope.Clock.WindowHighlight,
          maskGraphics: scope.Clock.Window,
        });
      };
      /**
       * @param {!Object} a22
       * @return {?}
       */
      options.prototype.setupDigitalReadout = function (a22) {
        //console.log("Step 2: options.prototype.setupDigitalReadout");
        //console.log(options.prototype.setupDigitalReadout.caller);
        return new DirSearchPathEntry(null, {
          readoutDisplayMode: a22.readoutDisplayMode,
          enabled: !a22.elapsedTimeMode,
        });
      };
      options.prototype.setupTellTime = function (a22) {
        //console.log("Step 2: options.prototype.setupTellTime: ", a22); //Vikas Step: 2
        return new testTellTime(null, {
          tellTimeDisplayMode: a22.tellTimeMode,
          enabled: !a22.elapsedTimeMode,
        });
      };
      /**
       * @param {!Object} a22
       * @return {?}
       */
      options.prototype.setupRunJumpControl = function (a22) {
        return new MOUSEDOWN(null, {
          controlMode: a22.runJumpActiveTab,
          initialJumpStep: a22.initialJumpStep,
        });
      };
      /**
       * @param {!Object} settings
       * @return {?}
       */
      options.prototype.setupElapsedTime = function (settings) {
        //console.log("call partilce....",  options.prototype.setupElapsedTime.caller);// Vikas-- Note: This calls particle
        /** @type {number} */
        var current_radius = settings.radius - (data.GENERAL_CLOCK_FACE_RADIUS_PADDING * settings.radius) / (scope.Clock.bounds.width / 2);
        //Vikas-- Note: following code calls Particle....
        return new Tabs(null, {
          active: settings.elapsedTimeActive,
          startAngle: settings.elapsedTimeStart,
          endAngle: settings.elapsedTimeEnd,
          radius: current_radius,
        });
      };
      /**
       * @param {!Object} instance
       * @return {?}
       */
      options.prototype.setupFractionControl = function (instance) {
        return new CIRCLE(null, {
          initialFragments: instance.initialFragments,
          initialAngle: instance.fractionInitialAngle,
          radius: instance.radius,
          fillMode: instance.fractionFillMode,
        });
      };
      /**
       * @return {undefined}
       */
      options.prototype._placeComponents = function () {
        this._placeHandle();
        this._placeDigitalReadout();
        this._placeRunJumpControl();
        this._placeElapsedTime();
        this._placeTellTime();
        this._placeFractionControl();
      };
      /**
       * @return {undefined}
       */
      options.prototype._placeHandle = function () {
        var x;
        var y;
        var offset;
        if (this.clockType === rules.Increments) {
          x = Math.cos(225 * _this.d.DEGREES_TO_RADIANS) * this.radius + (this.radius + 2);
          y = Math.sin(225 * _this.d.DEGREES_TO_RADIANS) * this.radius + (this.radius + 2);
        } else {
          /** @type {number} */
          offset = data.GENERAL_CLOCK_FACE_RADIUS_PADDING * (this.radius / data.DEFAULT_CLOCK_RADIUS);
          x = Math.cos(225 * _this.d.DEGREES_TO_RADIANS) * (this.radius - offset) + (this.radius + 2);
          y = Math.sin(225 * _this.d.DEGREES_TO_RADIANS) * (this.radius - offset) + (this.radius + 2);
        }
        this.handle.x = x;
        this.handle.y = y;
        /** @type {number} */
        this.handle.angle = 225;
        this.handle.display.hitArea = this.handle.corner;
      };
      /**
       * @return {undefined}
       */
      options.prototype._placeDigitalReadout = function () {
        /** @type {number} */
        this.digitalReadout.x = this.radius - this.digitalReadout.width / 2;
        /** @type {number} */
        this.digitalReadout.y = 2 * this.radius + 25;
      };
      /**
       * @return {undefined}
       */
      options.prototype._placeRunJumpControl = function () {
        /** @type {number} */
        this.runJumpControl.x = this.radius - this.runJumpControl.width / 2;
        /** @type {number} */
        this.runJumpControl.y = 2 * this.radius + 25;
        if (this.digitalReadoutMode) {
          this.runJumpControl.y += this.digitalReadout.height + 6;
        }
      };
      /**
       * @return {undefined}
       */
      options.prototype._placeElapsedTime = function () {
        this.elapsedTime.x = this.radius;
        this.elapsedTime.y = this.radius;
      };

      options.prototype._placeTellTime = function () {
        /** @type {number} */
       // console.log(this.elapsedTimeMode, this.tellTime);
        this.tellTime.x = this.radius - this.tellTime.width / 2;
        /** @type {number} */
        this.tellTime.y = 2 * this.radius + 25;
        if (this.digitalReadoutMode) {
          this.tellTime.y += this.digitalReadout.height + 10;
        }
      };

      /**
       * @return {undefined}
       */
      options.prototype._placeFractionControl = function () {
        /** @type {number} */
        this.fractionControl.x = data.GENERAL_CLOCK_FACE_RADIUS_PADDING * this.scale;
        /** @type {number} */
        this.fractionControl.y = data.GENERAL_CLOCK_FACE_RADIUS_PADDING * this.scale;
      };
      /**
       * @return {undefined}
       */
      options.prototype.draw = function () {
        //console.clear();
        //console.log("OPTIONS: ", this);
        this.selectionHighlight.visible = this.selected;
        /** @type {number} */
        this.selectionHighlight.alpha = 0.5;
        this.selectionHighlight.graphics = this.createSelectionHighlightGraphics();
        /** @type {boolean} */
        this.arabicNumerals.visible = this.clockType === rules.Arabic || this.clockType === rules.Increments;
        /** @type {boolean} */
        this.romanNumerals.visible = this.clockType === rules.Roman;
        /** @type {boolean} */
        this.fiveLabels.visible = this.clockType === rules.Increments;
        this.minuteHand.display.visible = this.minuteHandOn;
        this.minuteHand.draw();
        this.hourHand.display.visible = this.hourHandOn;
        this.hourHand.draw();
        this.secondHand.draw();
        this.secondHand.display.visible = this.runJumpMode && this.runJumpControl.controlMode === MOUSEDOWN.ControlModes.RUN;
        this.handle.display.visible = this.selected && this.handleActive;
        this.handle.draw();
        this.gearBox.display.visible = this.isGeared();
        this.digitalReadout.display.visible = this.digitalReadoutMode && this.isGeared();
        this.digitalReadout.draw();
        this.tellTime.display.visible = this.tellTimeMode && this.isGeared();
        this.tellTime.draw();
        this.runJumpControl.display.visible = this.runJumpMode && this.isGeared();
        this.runJumpControl.draw();
        this.elapsedTime.display.visible = this.elapsedTimeMode && this.isGeared() && this.activeMajorControl === modifier.ElapsedTime;
        this.elapsedTime.draw();
        /** @type {boolean} */
        this.fractionControl.display.visible = this.activeMajorControl !== modifier.ElapsedTime;
        this.fractionControl.draw();
      };
      /**
       * @param {!Object} event
       * @return {undefined}
       */
      options.prototype.resize = function (event) {
        /** @type {number} */
        var d = Math.floor(event.amount);
        if (this.radius - d < data.MINIMUM_CLOCK_RADIUS) {
          /** @type {number} */
          d = this.radius - data.MINIMUM_CLOCK_RADIUS;
        }
        if (this.radius - d > this.maxRadius) {
          /** @type {number} */
          d = this.radius - this.maxRadius;
        }
        this.setRadius(this.radius - d);
        this.x += d;
        this.y += d;
        this.draw();
        options.LastRadius = this.radius;
      };
      /**
       * @param {number} radius
       * @return {undefined}
       */
      options.prototype.setRadius = function (radius) {
        /** @type {number} */
        this.radius = radius;
        /** @type {number} */
        this.scale = this.radius / (scope.Clock.bounds.width / 2);
        /** @type {number} */
        this.clockFaceContainer.scaleX = this.scale;
        /** @type {number} */
        this.clockFaceContainer.scaleY = this.scale;
        /** @type {number} */
        this.clockHandsContainer.scaleX = this.scale;
        /** @type {number} */
        this.clockHandsContainer.scaleY = this.scale;
        this.display.setBounds(0, 0, 2 * this.radius, 2 * this.radius);
        /** @type {number} */
        this.width = 2 * this.radius;
        /** @type {number} */
        this.height = 2 * this.radius;
        this.clockFaceContainer.x = this.radius;
        this.clockFaceContainer.y = this.radius;
        this.clockHandsContainer.x = this.radius;
        this.clockHandsContainer.y = this.radius;
        this.elapsedTime.setRadius(this.radius - data.GENERAL_CLOCK_FACE_RADIUS_PADDING * this.scale);
        this.fractionControl.setRadius(this.radius - data.GENERAL_CLOCK_FACE_RADIUS_PADDING * this.scale);
        this._placeComponents();
      };
      /**
       * @return {undefined}
       */
      options.prototype.snapHands = function () {
        /** @type {number} */
        var e = 6 * Math.round(this.minuteHand.angle / 6);
        var c = new doc.a.Event(data.Events.SET_RUN_STATE);
        c.set({
          ids: [this.runJumpControl.runControl.id],
          newState: CatchEntry.RunStates.RESET,
          isHandChanging: true,
        });
        _this.f.dispatchEvent(c);
        this._animateHandChanged({
          id: this.minuteHand.id,
          newAngle: e,
          animated: true,
        });
      };
      /**
       * @param {number} v
       * @param {number} pos
       * @param {number} value
       * @return {undefined}
       */
      options.prototype.setTime = function (v, pos, value) {
        var currentColumn;
        var a;
        var deviceOrientationEvent;
        if (this.gearedHands) {
          a = new doc.a.Event(data.Events.HAND_CHANGED);
          /** @type {number} */
          currentColumn = v > 0 ? 30 * Math.floor(v) : 30 * Math.ceil(v);
          /** @type {number} */
          currentColumn = currentColumn + (Math.round(pos) / 60) * 30;
          a.set({
            id: this.hourHand.id,
            newAngle: currentColumn,
            animated: false,
          });
          _this.f.dispatchEvent(a);
        } else {
          (a = new doc.a.Event(data.Events.HAND_CHANGED)).set({
            id: this.hourHand.id,
            newAngle: 30 * v,
            animated: false,
          });
          (deviceOrientationEvent = new doc.a.Event(data.Events.HAND_CHANGED)).set({
            id: this.minuteHand.id,
            newAngle: 6 * pos,
            animated: false,
          });
          _this.f.dispatchEvent(a);
          _this.f.dispatchEvent(deviceOrientationEvent);
        }
        if (req.a.isNumber(value)) {
          /** @type {number} */
          this.secondHand.angle = value;
        }
      };
      /**
       * @return {?}
       */
      options.prototype.getGrid = function () {
        return [];
      };
      /**
       * @return {?}
       */
      options.prototype.getMinutes = function () {
        /** @type {number} */
        var context = (this.minuteHand.angle / 360) * 60;
        return this.gearedHands && (context = parse()(context)), context;
      };
      /**
       * @return {?}
       */
      options.prototype.getReadableMinutes = function () {
        /** @type {number} */
        var i = ((this.minuteHand.angle % 360) / 360) * 60;
        return this.gearedHands && (i = parse()(i)), i < 0 && (i = i + 60), i;
      };
      /**
       * @return {?}
       */
      options.prototype.getHours = function () {
        /** @type {number} */
        var daywidth = (this.hourHand.angle / 720) * 24;
        return this.gearedHands && (daywidth = Math.floor(daywidth)), daywidth;
      };
      /**
       * @return {?}
       */
      options.prototype.getReadableHours = function () {
        /** @type {number} */
        var value = ((this.hourHand.angle % 720) / 720) * 24;
        return this.gearedHands && (value = Math.floor(value)), value < 0 && (value = 24 + value), value;
      };
      /**
       * @param {string} val
       * @return {undefined}
       */
      options.prototype.setColorMode = function (val) {
        this.fractionControl.setColorMode(this.fractionFillMode, val);
        /** @type {boolean} */
        this.digitalReadout.active = false;
        this._placeComponents();
        this.draw();
      };
      /**
       * @param {string} e
       * @return {undefined}
       */
      options.prototype.setClockType = function (e) {
        if (req.a.contains(rules, e)) {
          /** @type {string} */
          this.clockType = e;
          this._placeComponents();
          this.draw();
        } else {
          console.error("Clock type '%s' is not supported.", e);
        }
      };
      /**
       * @param {string} mirror
       * @param {string} obj
       * @return {undefined}
       */
      options.prototype.setHandVisibility = function (mirror, obj) {
        if ("minute" === mirror) {
          this.minuteHandOn = req.a.isBoolean(obj) ? obj : !this.minuteHandOn;
          this._placeComponents();
          this.draw();
        } else {
          if ("hour" === mirror) {
            this.hourHandOn = req.a.isBoolean(obj) ? obj : !this.hourHandOn;
            this._placeComponents();
            this.draw();
          } else {
            console.error("Hand type '%s' is not supported.", mirror);
          }
        }
      };
      /**
       * @param {string} opt_round
       * @return {undefined}
       */
      options.prototype.setHandLabelVisibility = function (opt_round) {
        this.handLabelsOn = req.a.isBoolean(opt_round) ? opt_round : !this.handLabelsOn;
        this.hourHand.labelOn = this.handLabelsOn;
        this.minuteHand.labelOn = this.handLabelsOn;
        this._placeComponents();
        this.draw();
      };
      /**
       * @return {?}
       */
      options.prototype.isGeared = function () {
        return this.gearedHands && this.minuteHandOn && this.hourHandOn;
      };
      /**
       * @return {?}
       */
      options.prototype.clone = function () {
        return new options(null, this._copyCriticalProperties());
      };
      /**
       * @param {!Object} g
       * @return {undefined}
       */
      options.prototype._animateHandChanged = function (g) {
        var d;
        var m = this;
        if (g.id === this.minuteHand.id) {
          doc.a.Tween.get(this.minuteHand, {
            onChange: function () {
              m.draw();
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            },
            onComplete: function () {
              m.draw();
              m.digitalReadout.setTime(null, m.getReadableMinutes());
              _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
            },
          }).to(
            {
              angle: g.newAngle,
            },
            150
          );
          if (this.gearedHands) {
            doc.a.Tween.get(this.hourHand, {
              onChange: function () {
                m.draw();
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              },
              onComplete: function () {
                m.draw();
                m.digitalReadout.setTime(m.getReadableHours(), null);
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              },
            }).to(
              {
                angle: g.newAngle / 12,
              },
              150
            );
            (d = {}).endAngle = g.newAngle;
            if (!this.elapsedTime.active) {
              d.startAngle = g.newAngle;
            }
            doc.a.Tween.get(this.elapsedTime, {
              onChange: function () {
                m.elapsedTime._placeComponents();
                m.elapsedTime.draw();
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              },
              onComplete: function () {
                m.elapsedTime._placeComponents();
                m.elapsedTime.draw();
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              },
            }).to(d, 150);
          }
        } else {
          if (g.id === this.hourHand.id) {
            doc.a.Tween.get(this.minuteHand, {
              onChange: function () {
                m.draw();
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              },
              onComplete: function () {
                m.draw();
                m.digitalReadout.setTime(m.getReadableHours(), null);
                _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
              },
            }).to(
              {
                angle: 12 * g.newAngle,
              },
              150
            );
            if (this.gearedHands) {
              doc.a.Tween.get(this.hourHand, {
                onChange: function () {
                  m.draw();
                  _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
                },
                onComplete: function () {
                  m.draw();
                  m.digitalReadout.setTime(null, m.getReadableMinutes());
                  _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
                },
              }).to(
                {
                  angle: g.newAngle,
                },
                150
              );
              /** @type {number} */
              (d = {}).endAngle = 12 * g.newAngle;
              if (!this.elapsedTime.active) {
                /** @type {number} */
                d.startAngle = 12 * g.newAngle;
              }
              doc.a.Tween.get(this.elapsedTime, {
                onChange: function () {
                  m.elapsedTime._placeComponents();
                  m.elapsedTime.draw();
                  _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
                },
                onComplete: function () {
                  m.elapsedTime._placeComponents();
                  m.elapsedTime.draw();
                  _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
                },
              }).to(d, 150);
            }
          }
        }
      };
      /**
       * @param {!Object} b
       * @return {undefined}
       */
      options.prototype._jumpHandChanged = function (b) {
        if (b.id === this.minuteHand.id) {
          this.minuteHand.angle = b.newAngle;
          if (this.gearedHands) {
            /** @type {number} */
            this.hourHand.angle = b.newAngle / 12;
            /** @type {number} */
            this.gearBox.gear.rotation = b.newAngle / 24;
          }
        } else {
          if (b.id === this.hourHand.id) {
            this.hourHand.angle = b.newAngle;
            if (this.gearedHands) {
              /** @type {number} */
              this.minuteHand.angle = 12 * b.newAngle;
              /** @type {number} */
              this.gearBox.gear.rotation = b.newAngle / 2;
            }
          }
        }
        if (!this.elapsedTime.active) {
          this.elapsedTime.startAngle = this.minuteHand.angle;
        }
        this.elapsedTime.endAngle = this.minuteHand.angle;
        this.minuteHand.draw();
        this.hourHand.draw();
        this.digitalReadout.setTime(this.getReadableHours(), this.getReadableMinutes());
        this.tellTime.setTime(this.getReadableHours(), this.getReadableMinutes());

        this.elapsedTime._placeComponents();
      };
      /**
       * @param {string} item
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustment = function (item) {
        var _funcmap = {};
        _funcmap[DirSearchPathEntry.AdjustmentTypes.HOURS_UP] = this._handleReadoutAdjustmentHoursUp;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.HOURS_DOWN] = this._handleReadoutAdjustmentHoursDown;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.MINUTES_UNITS_UP] = this._handleReadoutAdjustmentMinutesUnitsUp;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.MINUTES_UNITS_DOWN] = this._handleReadoutAdjustmentMinutesUnitsDown;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.MINUTES_FIVES_UP] = this._handleReadoutAdjustmentMinutesFivesUp;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.MINUTES_FIVES_DOWN] = this._handleReadoutAdjustmentMinutesFivesDown;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.PERIOD_UP] = this._handleReadoutAdjustmentPeriodUp;
        _funcmap[DirSearchPathEntry.AdjustmentTypes.PERIOD_DOWN] = this._handleReadoutAdjustmentPeriodDown;
        _funcmap[item.adjustmentType].call(this);
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentHoursUp = function () {
        this.setTime(this.getReadableHours() + 1, this.getReadableMinutes());
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentHoursDown = function () {
        this.setTime(this.getReadableHours() - 1, this.getReadableMinutes());
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentMinutesUnitsUp = function () {
        this.setTime(this.getReadableHours(), this.getReadableMinutes() + 1);
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentMinutesUnitsDown = function () {
        this.setTime(this.getReadableHours(), this.getReadableMinutes() - 1);
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentMinutesFivesUp = function () {
        this.setTime(this.getReadableHours(), this.getReadableMinutes() + 5);
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentMinutesFivesDown = function () {
        this.setTime(this.getReadableHours(), this.getReadableMinutes() - 5);
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentPeriodUp = function () {
        this.setTime(this.getReadableHours() + 12, this.getReadableMinutes());
      };
      /**
       * @return {undefined}
       */
      options.prototype._handleReadoutAdjustmentPeriodDown = function () {
        this.setTime(this.getReadableHours() - 12, this.getReadableMinutes());
      };
      /**
       * @return {?}
       */
      options.prototype.getConstraintBounds = function () {
        return {
          x: this.x - 16,
          y: this.y - 16,
          width: 2 * this.radius + 32,
          height: 2 * this.radius + 32,
        };
      };
      /**
       * @return {?}
       */
      options.prototype.getSaveData = function () {
        var o = this._copyCriticalProperties();
        return (
          (o.center = {
            x: o.position.x + o.radius + 16,
            y: o.position.y + o.radius + 16,
            z: o.position.z,
          }),
          delete o.position,
          (o.radius += 32),
          (o.time = {
            hourAngle: this.hourHand.angle * data.DEGREES_TO_RADIANS,
            minuteAngle: this.minuteHand.angle * data.DEGREES_TO_RADIANS,
            secondAngle: o.initialTime.second * data.DEGREES_TO_RADIANS,
          }),
          delete o.initialTime,
          (o.clockFace = o.clockType),
          delete o.clockType,
          (o.showMinuteHand = o.minuteHandOn),
          delete o.minuteHandOn,
          (o.showHourHand = o.hourHandOn),
          delete o.hourHandOn,
          (o.showHandLabels = o.handLabelsOn),
          delete o.handLabelsOn,
          (o.gearedMode = o.gearedHands),
          delete o.gearedHands,
          (o.showDigitalDisplay = o.digitalReadoutMode),
          delete o.digitalReadoutMode,
          (o.runJumpDisplay = this.runJumpControl.getSaveData()),
          (o.elapsedTimeDisplay = this.elapsedTime.getSaveData()),
          (o.fractionDisplay = this.fractionControl.getSaveData()),
          delete o.activeMajorControl,
          delete o.runJumpMode,
          delete o.runJumpActiveTab,
          delete o.initialJumpStep,
          delete o.elapsedTimeMode,
          delete o.elapsedTimeActive,
          delete o.elapsedTimeStart,
          delete o.elapsedTimeEnd,
          delete o.fractionMode,
          delete o.fractionFillMode,
          delete o.fractionFillMode,
          delete o.fractionInitialAngle,
          delete o.initialFragments,
          {
            type: "clock",
            data: o,
          }
        );
      };
      /**
       * @return {?}
       */
      options.prototype._copyCriticalProperties = function () {
        var e = this.fractionControl._copyCriticalProperties();
        return {
          position: {
            x: this.x,
            y: this.y,
            z: this.display.parent ? action()(req.a).call(req.a, this.display.parent.children, this.display) : 0,
          },
          activeMajorControl: this.activeMajorControl,
          clockType: this.clockType,
          minuteHandOn: this.minuteHandOn,
          hourHandOn: this.hourHandOn,
          handLabelsOn: this.handLabelsOn,
          gearedHands: this.gearedHands,
          digitalReadoutMode: this.digitalReadoutMode,
          runJumpMode: this.runJumpMode,
          runJumpActiveTab: this.runJumpControl.controlMode,
          initialJumpStep: this.runJumpControl.jumpControl.fakeInputText.text,
          elapsedTimeMode: this.elapsedTimeMode,
          elapsedTimeActive: this.elapsedTime.active,
          elapsedTimeStart: this.elapsedTime.startAngle,
          elapsedTimeEnd: this.elapsedTime.endAngle,
          fractionMode: this.fractionMode,
          fractionFillMode: this.fractionFillMode,
          fractionInitialAngle: this.fractionControl.angle,
          initialFragments: e.initialFragments,
          radius: this.radius,
          initialTime: {
            hour: this.getHours(),
            minute: this.getReadableMinutes(),
            second: this.secondHand.angle,
          },
        };
      };
      /**
       * @return {undefined}
       */
      options.prototype.delete = function () {
        this.digitalReadout.delete();
        this.runJumpControl.delete();
      };
      options.ClockTypes = rules;
      /** @type {number} */
      options.LastRadius = currentAnime;
      /** @type {number} */
      options.CONSTRAINT_PADDING = 16;
      options.MajorControls = modifier;
      var w = $("x1GB");
      var i = $.n(w);
      var tile = $("KYsz");
      var t = $.n(tile);
      var __WEBPACK_IMPORTED_MODULE_18_date_fns_add_hours__ = $("+oHS");
      var parseTemplate = $.n(__WEBPACK_IMPORTED_MODULE_18_date_fns_add_hours__);
      var useragent = {};
      var Data = useragent;
      /**
       * @return {?}
       */
      useragent.checkDownloadSupport = function () {
        return void 0 !== document.createElement("a").download;
      };
      /**
       * @return {?}
       */
      useragent.checkSaveBlobSupport = function () {
        return req.a.isFunction(navigator.msSaveBlob);
      };
      /**
       * @param {string} dataURL
       * @return {?}
       */
      useragent.dataURLToBlob = function (dataURL) {
        var arr = dataURL.split(",");
        var GET_USER_PROFILE_SUCCESS = arr[0].match(/:(.*?);/)[1];
        /** @type {string} */
        var byteString = atob(arr[1]);
        /** @type {number} */
        var i = byteString.length;
        /** @type {!Uint8Array} */
        var view = new Uint8Array(i);
        for (; i--; ) {
          /** @type {number} */
          view[i] = byteString.charCodeAt(i);
        }
        return new Blob([view], {
          type: GET_USER_PROFILE_SUCCESS,
        });
      };
      /**
       * @param {!Array} obj
       * @param {?} event
       * @return {?}
       */
      useragent.inExclusionList = function (obj, event) {
        return req.a.any(event.parentSelectors, function (requiredContext) {
          return req.a.contains(obj, requiredContext);
        });
      };
      /**
       * @return {?}
       */
      useragent.isChromeOS = function () {
        var tokens;
        return trigger()((tokens = navigator.userAgent)).call(tokens, "CrOS");
      };
      /**
       * @return {?}
       */
      useragent.isCPA = function () {
        return "true" === data.IS_CPA;
      };
      /**
       * @param {?} element
       * @param {?} template
       * @return {undefined}
       */
      useragent.checkSaveProperties = function (element, template) {
        var tokens;
        console.trace("checking save properties...");
        cb()(element).call(element, function (e) {
          var tokens;
          if (trigger()((tokens = parseTemplate()(template))).call(tokens, e)) {
            console.log("HAS", e);
          } else {
            console.log("NEEDS", e);
          }
        });
        cb()((tokens = parseTemplate()(template))).call(tokens, function (t) {
          if (!trigger()(element).call(element, t)) {
            console.log("REMOVE", t);
          }
        });
      };
      var isolatedNodeComponent = new _this.o("#fraction-fill-box", {
        openEvent: data.Events.FRACTION_FILL_PALETTE_SHOW,
        closeEvent: data.Events.FRACTION_FILL_PALETTE_HIDE,
        id: "fraction-fill-base",
        classes: "popup",
        backgroundClose: true,
        appendTo: document.querySelector(data.FRACTION_FILL_SELECTOR).parentElement,
      });
      var koyomi = isolatedNodeComponent;
      /** @type {!Array} */
      var r = ["#ffffff", "#ffffff"]; //color
      var EVENT = {
        Red: "rgb(241, 217, 218)",
        Orange: "rgb(245, 228, 215)",
        Yellow: "rgb(247, 243, 217)",
        Green: "rgb(213, 239, 216)",
        Blue: "rgb(213, 232, 244)",
        Purple: "rgb(233, 211, 234)",
      };
      _this.f.on(data.Events.FRACTION_FILL_PALETTE_TOGGLE, create_proxy_with_event_dispatch);
      _this.f.on(data.Events.FRACTION_FILL_PALETTE_SHOW, eventHandler);
      _this.f.on(data.Events.FRACTION_FILL_PALETTE_HIDE, back);
      _this.f.on(data.Events.SET_FRACTION_FILL_COLOR, create);
      _this.f.on(_this.d.START_OVER_EVENT, function () {
        return _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
      });
      _this.f.on(_this.d.START_OVER_SAVESTATE_EVENT, function () {
        return _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
      });
      var CC1P = new _this.o("#edit-clock-box", {
        openEvent: data.Events.EDIT_CLOCK_PALETTE_SHOW,
        closeEvent: data.Events.EDIT_CLOCK_PALETTE_HIDE,
        id: "edit-clock-base",
        classes: "popup",
        backgroundClose: true,
        appendTo: "body",
      });
      View.prototype = mutation()(_this.q.prototype);
      View.prototype.constructor = _this.q;
      /** @type {function(?, number): undefined} */
      var Plugin = View;
      /**
       * @return {undefined}
       */
      View.prototype.draw = function () {};
      /**
       * @param {string} side
       * @param {number} value
       * @return {undefined}
       */
      View.prototype.indicator = function (side, value) {
        //console.clear();
        /* console.log("This: ", this);
        console.log("Side: ", side);
        console.log("Value: ", value);
        console.log("caller 1",View.prototype.indicator.caller);
        console.log("caller 2",View.prototype.indicator.caller.caller); */
        if (req.a.isNumber(value)) {
          /** @type {number} */
          this.baseElement.y = value - this.height / 2;
        }
        if ("left" === side) {
          this.baseElement.htmlElement.classList.add("tail-left");
          this.baseElement.htmlElement.classList.remove("tail-right");
        }
        if ("right" === side) {
          this.baseElement.htmlElement.classList.add("tail-right");
          this.baseElement.htmlElement.classList.remove("tail-left");
        }
      };
      /**
       * @param {number} key
       * @return {undefined}
       */
      View.prototype._setupDisplay = function (key) {
        var p5Instance;
        var methodsToOverwrite;
        var _this = this._setupHTMLButtons();
        this.baseElement = this._setupHTMLDisplay(key);
        this.radioButtons = _this.radioButtons;
        this.checkboxButtons = _this.checkboxButtons;
        this.basicButtons = _this.basicButtons;
        /** @type {!Array} */
        methodsToOverwrite = [this.baseElement];
        req.a.each(
          methodsToOverwrite,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
        p5Instance = this.baseElement.getBounds();
        this.width = p5Instance.width;
        this.height = p5Instance.height;
      };
      /**
       * @param {!Function} scope
       * @return {?}
       */
      View.prototype._setupHTMLDisplay = function (scope) {
        var c = scope.base.$element;
        var inDesignable = new doc.a.DOMElement(c[0]);
        return inDesignable.setBounds(0, 0, c.width(), c.height()), inDesignable;
      };
      /**
       * @return {?}
       */
      View.prototype._setupHTMLButtons = function () {
        var _this = {};
        return (
          (_this.radioButtons = this._setupRadioButtons()),
          (_this.checkboxButtons = this._setupCheckboxButtons()),
          (_this.basicButtons = this._setupBasicButtons()),
          _this
        );
      };
      /**
       * @return {?}
       */
      View.prototype._setupRadioButtons = function () {
        var e = {};
        return (
          (e.incrementsRadio = new _this.e("#face-button-increments", {
            clickEvent: data.Events.SET_CLOCK_TYPE,
            parameters: {
              clockType: selection.ClockTypes.Increments,
            },
          })),
          (e.arabicRadio = new _this.e("#face-button-arabic", {
            clickEvent: data.Events.SET_CLOCK_TYPE,
            parameters: {
              clockType: selection.ClockTypes.Arabic,
            },
          })),
          (e.romanRadio = new _this.e("#face-button-roman", {
            clickEvent: data.Events.SET_CLOCK_TYPE,
            parameters: {
              clockType: selection.ClockTypes.Roman,
            },
          })),
          (e.blankRadio = new _this.e("#face-button-blank", {
            clickEvent: data.Events.SET_CLOCK_TYPE,
            parameters: {
              clockType: selection.ClockTypes.Blank,
            },
          })),
          e
        );
      };
      /**
       * @return {?}
       */
      View.prototype._setupCheckboxButtons = function () {
        var e = {};
        return (
          (e.hourCheckbox = new _this.e("#check-hour", {
            clickEvent: data.Events.SET_CLOCK_HAND_VISIBILITY,
            parameters: {
              hand: "hour",
            },
          })),
          (e.minuteCheckbox = new _this.e("#check-minute", {
            clickEvent: data.Events.SET_CLOCK_HAND_VISIBILITY,
            parameters: {
              hand: "minute",
            },
          })),
          (e.labelsCheckbox = new _this.e("#check-labels", {
            clickEvent: data.Events.SET_CLOCK_HAND_LABEL_VISIBILITY,
          })),
          e
        );
      };
      /**
       * @return {?}
       */
      View.prototype._setupBasicButtons = function () {
        var Reply = {};
        return (
          (Reply.OK = new _this.e("#edit-clock-done", {
            clickEvent: data.Events.EDIT_CLOCK_PALETTE_HIDE,
          })),
          Reply
        );
      };
      /**
       * @return {undefined}
       */
      View.prototype._bindEvents = function () {
        _this.f.on(data.Events.EDIT_CLOCK_PALETTE_TOGGLE, this._toggleVisibility, this);
        _this.f.on(data.Events.EDIT_CLOCK_PALETTE_SHOW, this._show, this);
        _this.f.on(data.Events.EDIT_CLOCK_PALETTE_HIDE, this._hide, this);
      };
      /**
       * @return {undefined}
       */
      View.prototype._toggleVisibility = function () {
        console.log("View visibility.......");

        /** @type {string} */
        var deviceOrientationEvent = data.Events.EDIT_CLOCK_PALETTE_SHOW;
        if (this.display.visible) {
          /** @type {string} */
          deviceOrientationEvent = data.Events.EDIT_CLOCK_PALETTE_HIDE;
        }
        _this.f.dispatchEvent(deviceOrientationEvent);
      };
      /**
       * @param {?} message
       * @return {undefined}
       */
      View.prototype._show = function (message) {
        this._updatePaletteToClockState(message.targetEntity);
        /** @type {boolean} */
        this.display.visible = true;
        _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
      };
      /**
       * @return {undefined}
       */
      View.prototype._hide = function () {
        /** @type {boolean} */
        this.display.visible = false;
        _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
      };
      /**
       * @param {?} i
       * @return {undefined}
       */
      View.prototype._updatePaletteToClockState = function (i) {
        if (i) {
          req.a.each(this.radioButtons, function (lessonView) {
            /** @type {boolean} */
            lessonView.$el[0].checked = lessonView.$el[0].value === i.clockType;
          });
          this.checkboxButtons.hourCheckbox.$el[0].checked = i.hourHandOn;
          this.checkboxButtons.minuteCheckbox.$el[0].checked = i.minuteHandOn;
          this.checkboxButtons.labelsCheckbox.$el[0].checked = i.handLabelsOn;
        }
      };
      var __WEBPACK_IMPORTED_MODULE_19_date_fns_add_seconds__ = $("j6J1");
      var __WEBPACK_IMPORTED_MODULE_19_date_fns_add_seconds___default = $.n(__WEBPACK_IMPORTED_MODULE_19_date_fns_add_seconds__);
      var element = $("o+MX");
      var renderer = $.n(element);
      var states = {
        DEFAULT: "300 40px " + _this.d.KEYPAD_FONT_FAMILY,
        HEADER: "400 26px " + _this.d.KEYPAD_FONT_FAMILY,
        PARTS: "400 20px " + _this.d.KEYPAD_FONT_FAMILY,
        NONE: "400 22px " + _this.d.KEYPAD_FONT_FAMILY,
        OK: "400 22px " + _this.d.KEYPAD_FONT_FAMILY,
      };
      var marker_shadow = new doc.a.Shadow(_this.d.SHADOW_COLOR, 0, 0, _this.d.PALETTE_SHADOW_RADIUS);
      Palette.prototype = mutation()(_this.q.prototype);
      Palette.prototype.constructor = _this.q;
      /** @type {function(?, number): undefined} */
      var WebSocket = Palette;
      /**
       * @return {undefined}
       */
      Palette.prototype.draw = function () {
        this.backing.graphics
          .clear()
          .beginFill("#233239")
          .drawRoundRect(0, 0, this.width - 2, this.height - 2, 12);
      };
      /**
       * @param {string} value
       * @param {number} i
       * @return {undefined}
       */
      Palette.prototype.indicator = function (value, i) {
        if ("left" === value) {
          /** @type {boolean} */
          this.indicatorLeft.visible = true;
          /** @type {boolean} */
          this.indicatorRight.visible = false;
        }
        if ("right" === value) {
          /** @type {boolean} */
          this.indicatorLeft.visible = false;
          /** @type {boolean} */
          this.indicatorRight.visible = true;
        }
        if (req.a.isNumber(i)) {
          /** @type {number} */
          this.indicatorLeft.y = i;
          /** @type {number} */
          this.indicatorRight.y = i;
        }
      };
      /**
       * @return {undefined}
       */
      Palette.prototype._bindEvents = function () {
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_TOGGLE, this._toggleVisibility, this);
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_SHOW, this._show, this);
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_HIDE, this._hide, this);
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT, this._updatePartsIndicator, this);
      };
      /**
       * @param {?} htOptions
       * @return {undefined}
       */
      Palette.prototype._toggleVisibility = function (htOptions) {
        console.log("Palette visibility.......");
        /** @type {string} */
        var name = data.Events.FRACTION_PICK_PALETTE_SHOW;
        if (this.display.visible) {
          /** @type {string} */
          name = data.Events.FRACTION_PICK_PALETTE_HIDE;
        }
        var event = new doc.a.Event(name);
        event.set({
          targetEntity: htOptions.targetEntity,
        });
        _this.f.dispatchEvent(event);
      };
      /**
       * @param {?} message
       * @return {undefined}
       */
      Palette.prototype._show = function (message) {
        req.a.each(this.keyButtons, function (consideration) {
          /** @type {boolean} */
          consideration.stateActive = consideration.partsValue === message.targetEntity.fractionControl.getFragmentCount();
          consideration.draw();
        });
        /** @type {boolean} */
        this.display.visible = true;
        _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
      };
      /**
       * @return {undefined}
       */
      Palette.prototype._hide = function () {
        /** @type {boolean} */
        this.display.visible = false;
        _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
      };
      /**
       * @param {number} saveNum
       * @return {undefined}
       */
      Palette.prototype._updatePartsIndicator = function (saveNum) {
        /** @type {number} */
        
        var t = 0;
        if (saveNum && saveNum.value) {
          /** @type {number} */
          t = 60 / saveNum.value;
          /** @type {string} */
          console.log(this.partsIndicator);
          this.partsIndicator.color = "#fff"
          this.partsIndicator.text = 1 === t ? t + " minute each" : t + " minutes each";
        } else {
          /** @type {string} */
          this.partsIndicator.text = "";
        }

        //new doc.a.Text("How many parts?", states.HEADER, "#fff");
      };
      /**
       * @return {undefined}
       */
      Palette.prototype._setupDisplay = function () {
        /** @type {!Array} */
        var source = [];
        var anchorBoundingBoxViewport = this._setupIndicators();
        this.backing = new doc.a.Shape();
        this.backing.shadow = marker_shadow;
        this.indicatorLeft = anchorBoundingBoxViewport.left;
        this.indicatorRight = anchorBoundingBoxViewport.right;
        /** @type {number} */
        this.indicatorLeft.x = 0;
        this.indicatorRight.x = this.width;
        this.header = new doc.a.Text("How many parts?", states.HEADER, "#fff");
        /** @type {string} */
        this.header.textAlign = "center";
        /** @type {string} */
        this.header.textBaseline = "top";
        /** @type {number} */
        this.header.x = this.width / 2;
        /** @type {number} */
        this.header.y = 38 - this.header.getMeasuredHeight() / 2;
        this.partsIndicator = new doc.a.Text("", states.PARTS, "#000");
        /** @type {string} */
        this.partsIndicator.textAlign = "center";
        /** @type {string} */
        this.partsIndicator.textBaseline = "top";
        /** @type {number} */
        this.partsIndicator.x = 105;
        /** @type {number} */
        this.partsIndicator.y = this.height - 12 - 25 - this.partsIndicator.getMeasuredHeight() / 2;
        this.keyButtons = this._createButtons();
        /** @type {!Array} */
        source = [this.backing, this.indicatorLeft, this.indicatorRight, this.header, this.partsIndicator];
        source = renderer()(source).call(source, req.a.pluck(this.keyButtons, "display"));
        req.a.each(
          source,
          function (name) {
            this.display.addChild(name);
          },
          this
        );
      };
      /**
       * @return {?}
       */
      Palette.prototype._setupIndicators = function () {
        var border = new doc.a.Shape();
        var backColor = new doc.a.Shape();
        return (
          border.graphics.clear(),
          border.graphics.beginFill("#233239").moveTo(1, -25).lineTo(-25, 0).lineTo(1, 25).endStroke(),
          backColor.graphics.clear(),
          backColor.graphics.beginFill("#233239").moveTo(-2, -25).lineTo(25, 0).lineTo(-2, 25).endStroke(),
          {
            left: border,
            right: backColor,
          }
        );
      };
      /**
       * @return {?}
       */
      Palette.prototype._createButtons = function () {
        /** @type {!Array} */
        var myHooks = [];
        return (
          myHooks.push.apply(myHooks, Object(event.a)(this._createPartsButtons())),
          myHooks.push(this._createNoneButton(0, 1, 4)),
          myHooks.push(this._createOKButton(3, 5, 1)),
          myHooks
        );
      };
      /**
       * @param {!Object} data
       * @param {!Object} event
       * @param {number} a
       * @param {number} keyName
       * @param {boolean} config
       * @return {?}
       */
      Palette.prototype._createGenericButton = function (data, event, a, keyName, config) {
        var definition;
        var json = config ? req.a.clone(config) : {};
        return (
          req.a.defaults(json, {
            buttonType: _this.b.ButtonTypes.TEXT,
            buttonText: req.a.isObject(data) ? data.displayText : data,
            textColor: _this.d.COLOR_SECONDARY_DARK,
            borderColor: "transparent",
            fillColor: "#e8e8e8",
            activeColor: "#f3f3f3",
            borderRadius: 0,
            font: states.DEFAULT,
            smallText: false,
            position: {
              x: Math.floor(62 * a + 12),
              y: Math.floor(52 * keyName + 12),
            },
            dimensions: {
              width: Math.floor(json.width || 60),
              height: Math.floor(json.height || 50),
            },
            clickCallback: function () {
              var deviceOrientationEvent;
              if (event.eventName) {
                (deviceOrientationEvent = new doc.a.Event(event.eventName)).set(event);
                _this.f.dispatchEvent(deviceOrientationEvent);
              }
            },
          }),
          (definition = new _this.b(null, json)).draw(),
          definition
        );
      };
      /**
       * @param {number} val
       * @param {!Object} data
       * @param {number} keys
       * @param {number} fn
       * @param {boolean} config
       * @return {?}
       */
      Palette.prototype._createPartsButton = function (val, data, keys, fn, config) {
        var definition;
        var json = config ? req.a.clone(config) : {};
        return (
          req.a.defaults(json, {
            buttonType: _this.b.ButtonTypes.TEXT,
            buttonText: req.a.isObject(val) ? val.displayText : val,
            textColor: _this.d.COLOR_SECONDARY_DARK,
            borderColor: "transparent",
            fillColor: "#e8e8e8",
            activeColor: "#f3f3f3",
            borderRadius: 0,
            font: states.DEFAULT,
            smallText: false,
            position: {
              x: Math.floor(62 * keys + 12),
              y: Math.floor(52 * fn + 12),
            },
            dimensions: {
              width: Math.floor(json.width || 60),
              height: Math.floor(json.height || 50),
            },
            clickCallback: function () {
              var deviceOrientationEvent;
              if (data.eventName) {
                (deviceOrientationEvent = new doc.a.Event(data.eventName)).set(data);
                _this.f.dispatchEvent(deviceOrientationEvent);
              }
            },
          }),
          ((definition = new _this.v(null, json)).partsValue = data.value),
          definition.draw(),
          definition
        );
      };
      /**
       * @return {?}
       */
      Palette.prototype._createPartsButtons = function () {
        var s;
        var cache = {};
        return (
          req.a.each(
            [
              [1, 2, 3, 4],
              [5, 6, 10, 12],
              [15, 20, 30, 60],
            ],
            function (arrRequiredPermissions, i) {
              req.a.each(
                arrRequiredPermissions,
                function (n, canCreateDiscussions) {
                  /** @type {string} */
                  s = String(n);
                  cache[s] = this._createPartsButton(
                    s,
                    {
                      eventName: data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
                      value: n,
                    },
                    0 + canCreateDiscussions,
                    2 + i,
                    {
                      font: states.DEFAULT,
                      fillColor: "#50879F",
                      activeColor: "#97DBF8",
                    }
                  );
                },
                this
              );
            },
            this
          ),
          req.a.each(cache, function (e, value) {
            _this.f.on(
              data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
              function (instance) {
                if (instance.value === pipe()(value, 10)) {
                  /** @type {boolean} */
                  this.stateActive = true;
                } else {
                  /** @type {boolean} */
                  this.stateActive = false;
                }
                this.draw();
              },
              e
            );
          }),
          __WEBPACK_IMPORTED_MODULE_19_date_fns_add_seconds___default()(req.a).call(req.a, cache)
        );
      };
      /**
       * @param {number} select
       * @param {number} options
       * @param {number} ignoreClockTick
       * @return {?}
       */
      Palette.prototype._createNoneButton = function (select, options, ignoreClockTick) {
        var opt = this._createPartsButton(
          "NONE",
          {
            eventName: data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
            value: 0,
          },
          select,
          options,
          {
            font: states.NONE,
            fillColor: "#50879F",
            activeColor: "#50879F",
            width: 62 * ignoreClockTick - 2,
            stateActive: true,
          }
        );
        return (
          _this.f.on(
            data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
            function (select_ele) {
              if (select_ele.value === pipe()(0, 10)) {
                /** @type {boolean} */
                this.stateActive = true;
              } else {
                /** @type {boolean} */
                this.stateActive = false;
              }
              this.draw();
            },
            opt
          ),
          opt
        );
      };
      /**
       * @param {number} y2
       * @param {number} t
       * @param {number} isTangent
       * @return {?}
       */
      Palette.prototype._createOKButton = function (y2, t, isTangent) {
        return this._createGenericButton(
          "OK",
          {
            eventName: data.Events.FRACTION_PICK_PALETTE_TOGGLE,
          },
          y2,
          t,
          {
            font: states.OK,
            fillColor: "#0281c6",
            activeColor: "#80c0e2",
            textColor: _this.d.COLOR_NEUTRAL_PALE,
            width: 62 * isTangent - 2,
          }
        );
      };
      var p;
      var e;
      var item;
      var c;
      var obj;
      var uiFiles = $("RC+S");
      var allI18nFiles = $("Ic0E");
      var inputel = $("1v75");
      var $unusedPanel = $("d6Hy");
      var img = $("HpR4");
      var srcString = $("v+RB");
      var detailViewItem = $("Myji");
      var result = $("+Nh4");
      var largeiconViewItem = $("zyPW");
      var f = $("dBWY");
      var resultid = $("OnMd");
      var src = $("9jHf");
      var toolbarDiv = $("+jE+");
      var image = $("DudV");
      var _msgSibling = $("+ugO");
      /** @type {null} */
      var bounds = null;
      var utils = {};
      var ctx = utils;
      /** @type {!Array} */
      var GET_AUTH_URL_TIMEOUT = [
        {
          src: avatarSrc,
        },
        {
          src: uiFiles,
        },
        {
          src: allI18nFiles,
        },
        {
          src: inputel,
        },
        {
          src: $unusedPanel,
        },
        {
          src: img,
        },
        {
          src: srcString,
        },
        {
          src: detailViewItem,
        },
        {
          src: result,
        },
        {
          src: largeiconViewItem,
        },
        {
          src: f,
        },
        {
          src: src,
        },
        {
          src: toolbarDiv,
        },
        {
          src: image,
        },
      ];
      /** @type {!Array} */
      var artistTrack = [
        {
          src: _msgSibling,
        },
      ];
      _this.n.defineManifest("draw-tools", GET_AUTH_URL_TIMEOUT, data.CACHEBUST_BASEPATH);
      _this.n.defineManifest("equation-tools", artistTrack, data.CACHEBUST_BASEPATH);
      /**
       * @param {string} v
       * @return {undefined}
       */
      utils.init = function (v) {
        !(function (x) {
          var staveBar2 = _this.u.getBounds();
          var element = {
            position: {
              x: 0,
              y: 0,
            },
            closeDefault: _this.n.getResult("draw-tools", avatarSrc),
            closeActive: _this.n.getResult("draw-tools", uiFiles),
            freehandDefault: _this.n.getResult("draw-tools", allI18nFiles),
            freehandActive: _this.n.getResult("draw-tools", inputel),
            lineDefault: _this.n.getResult("draw-tools", $unusedPanel),
            lineActive: _this.n.getResult("draw-tools", img),
            colorPickerDefault: _this.n.getResult("draw-tools", srcString),
            colorPickerActive: _this.n.getResult("draw-tools", detailViewItem),
            eraseDefault: _this.n.getResult("draw-tools", result),
            eraseActive: _this.n.getResult("draw-tools", largeiconViewItem),
            eraseAllDefault: _this.n.getResult("draw-tools", f),
            eraseAllActive: _this.n.getResult("draw-tools", resultid),
            colorDefault: _this.n.getResult("draw-tools", src),
            colorActive: _this.n.getResult("draw-tools", toolbarDiv),
            handleRibs: _this.n.getResult("draw-tools", image),
          };
          /** @type {string} */
          (p = new _this.g(x, element)).bindingContainer = x;
          /** @type {number} */
          p.x = staveBar2.width + staveBar2.x - p.width - 25;
          /** @type {number} */
          p.y = 25;
          p.updateMenuDirection();
          p.draw();
          _this.f.dispatchEvent(_this.d.DRAW_TOOLS_HIDE_EVENT);
        })(v);
        (function (x) {
          var props = {
            position: {
              x: 500,
              y: 30,
            },
            backspaceImage: _this.n.getResult("equation-tools", _msgSibling),
          };
          /** @type {string} */
          (e = new _this.i(x, props)).bindingContainer = x;
          e.draw();
          _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
        })(v);
        (function (p1) {
          /** @type {string} */
          (
            item = new _this.x(p1, {
              position: {
                x: 500,
                y: 30,
              },
            })
          ).bindingContainer = p1;
          item.draw();
          _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
        })(v);
        (function (a) {
          /** @type {string} */
          (
            c = new WebSocket(a, {
              position: {
                x: 500,
                y: 30,
              },
            })
          ).bindingContainer = a;
          c.draw();
          _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
        })(v);
        (function (name) {
          /** @type {string} */
          (
            obj = new Plugin(name, {
              position: {
                x: 500,
                y: 30,
              },
              base: CC1P,
            })
          ).bindingContainer = name;
          obj.draw();
          _this.f.dispatchEvent(data.Events.EDIT_CLOCK_PALETTE_HIDE);
        })(v);
        _this.f.on(_this.d.DRAW_TOOLS_SHOW_EVENT, function () {
          if (e.display.visible) {
            _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
          }
          if (item.display.visible) {
            _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
          }
          if (c.display.visible) {
            _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
          }
          _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
        });
        _this.f.on(_this.d.STAGE_UPDATE, draw);
        _this.f.on(_this.d.EQUATION_TOOLS_TEXT_CHANGE, function (action) {
          if (utils.isTargetEntity(_this.h)) {
            bounds.updateText(action.newText);
          }
        });
        _this.f.on(_this.d.EQUATION_TOOLS_COLOR_CHANGE, function (e) {
          if (utils.isTargetEntity(_this.h)) {
            bounds.updateColor(e.text);
          }
        });
        _this.f.on(_this.d.EQUATION_TOOLS_HIDE, function () {
          if (utils.isTargetEntity(_this.h)) {
            /** @type {null} */
            bounds = null;
          }
        });
        _this.f.on(_this.d.EQUATION_TOOLS_SHOW, function (item) {
          bounds = item.targetEntity;
          draw();
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
          });
          e.display.dispatchEvent(beat);
          var eventStart = new doc.a.Event(_this.d.DRAW_TOOLS_MODE_CHANGE_EVENT);
          eventStart.set({
            newMode: _this.g.DrawMode.NONE,
          });
          _this.f.dispatchEvent(eventStart);
        });
        _this.f.on(_this.d.DRAW_TOOLS_MODE_CHANGE_EVENT, function (dataNode) {
          if (dataNode.newMode !== _this.g.DrawMode.NONE && e.display.visible) {
            _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
          }
        });
        _this.f.on(_this.d.DELETE_SELECTION_EVENT, function (dataNode) {
          if (dataNode.newMode !== _this.g.DrawMode.NONE && e.display.visible) {
            _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
          }
        });
        _this.f.on(data.Events.SPAWN_EQUATION_REQUEST, function () {
          if (e.display.visible || item.display.visible) {
            _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
            _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
            _this.f.dispatchEvent(_this.d.SPAWN_EQUATION_EVENT);
          } else {
            _this.f.dispatchEvent(_this.d.SPAWN_EQUATION_EVENT);
          }
        });
        _this.f.on(_this.d.STAGE_UPDATE, checkBounds);
        _this.f.on(data.Events.SPAWN_TEXT_REQUEST, function () {
          if (e.display.visible || item.display.visible) {
            _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
            _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
            _this.f.dispatchEvent(_this.d.SPAWN_TEXT_EVENT);
          } else {
            _this.f.dispatchEvent(_this.d.SPAWN_TEXT_EVENT);
          }
        });
        _this.f.on(_this.d.TEXT_TOOLS_TEXT_CHANGE, function (action) {
          if (utils.isTargetEntity(_this.w)) {
            bounds.updateText(action.newText);
          }
        });
        _this.f.on(_this.d.TEXT_TOOLS_COLOR_CHANGE, function (e) {
          if (utils.isTargetEntity(_this.w)) {
            bounds.updateColor(e.text);
          }
        });
        _this.f.on(_this.d.TEXT_TOOLS_HIDE, function () {
          if (utils.isTargetEntity(_this.w)) {
            /** @type {null} */
            bounds = null;
          }
        });
        _this.f.on(_this.d.TEXT_TOOLS_SHOW, function (result) {
          bounds = result.targetEntity;
          draw();
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
          });
          item.display.dispatchEvent(beat);
          var eventStart = new doc.a.Event(_this.d.DRAW_TOOLS_MODE_CHANGE_EVENT);
          eventStart.set({
            newMode: _this.g.DrawMode.NONE,
          });
          _this.f.dispatchEvent(eventStart);
        });
        _this.f.on(_this.d.DRAW_TOOLS_MODE_CHANGE_EVENT, function (dataNode) {
          if (dataNode.newMode !== _this.g.DrawMode.NONE && item.display.visible) {
            _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
          }
        });
        _this.f.on(_this.d.DELETE_SELECTION_EVENT, function (dataNode) {
          if (dataNode.newMode !== _this.g.DrawMode.NONE && item.display.visible) {
            _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
          }
        });
        _this.f.on(_this.d.RESIZE_EVENT, function () {
          //console.log(" RESIZE_EVENT ");//NNO
          var beat = new doc.a.Event(_this.d.CONSTRAIN_ENTITY_EVENT);
          beat.set({
            skipAnimation: true,
            skipConstrainOffset: true,
          });
          p.display.dispatchEvent(beat);
        });
        _this.f.on(_this.d.STAGE_UPDATE, initialize);
        _this.f.on(data.Events.EDIT_CLOCK_PALETTE_SHOW, function (item) {
          //console.log("Edit clock", item); //Vikas
          bounds = item.targetEntity;
          initialize();
          var beat = new doc.a.Event(_this.d.DRAW_TOOLS_MODE_CHANGE_EVENT);
          beat.set({
            newMode: _this.g.DrawMode.NONE,
          });
          _this.f.dispatchEvent(beat);
        });
        _this.f.on(data.Events.TOGGLE_EDIT_MODE, function () {
          //console.log("Toggle edit mode...");//Vikas
          var beat;
          var bl;
          var value;
          if (obj.display.visible) {
            beat = new doc.a.Event(data.Events.EDIT_CLOCK_PALETTE_HIDE);
          } else {
            beat = new doc.a.Event(data.Events.EDIT_CLOCK_PALETTE_SHOW);
            if (
              (bl = require()((value = root.getSelectedEntities(selection))).call(value, function (bounds) {
                return bounds instanceof selection;
              })).length > 0
            ) {
              beat.set({
                targetEntity: bl[0],
              });
            }
            _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
          }
          _this.f.dispatchEvent(beat);
        });
        _this.f.on(data.Events.SET_CLOCK_TYPE, function (dateFormat) {
          var c;
          var id;
          if (bounds) {
            var selector;
            c = new doc.a.Event(data.Events.SET_SELECTION_CLOCK_TYPE);
            var attrs = require()((selector = root.getSelectedEntities())).call(selector, function (bounds) {
              return bounds instanceof selection;
            });
            id = req.a.pluck(attrs, "id");
            c.set({
              ids: id,
              clockType: dateFormat.clockType,
            });
            _this.f.dispatchEvent(c);
          }
        });
        _this.f.on(data.Events.SET_CLOCK_HAND_VISIBILITY, function (options) {
          var c;
          var id;
          if (bounds) {
            var selector;
            c = new doc.a.Event(data.Events.SET_SELECTION_CLOCK_HAND_VISIBILITY);
            var attrs = require()((selector = root.getSelectedEntities())).call(selector, function (bounds) {
              return bounds instanceof selection;
            });
            id = req.a.pluck(attrs, "id");
            c.set({
              ids: id,
              hand: options.hand,
              setTo: options.setTo,
            });
            _this.f.dispatchEvent(c);
          }
        });
        _this.f.on(data.Events.SET_CLOCK_HAND_LABEL_VISIBILITY, function (options) {
          var c;
          var id;
          if (bounds) {
            var selector;
            c = new doc.a.Event(data.Events.SET_SELECTION_CLOCK_HAND_LABEL_VISIBILITY);
            var attrs = require()((selector = root.getSelectedEntities())).call(selector, function (bounds) {
              return bounds instanceof selection;
            });
            id = req.a.pluck(attrs, "id");
            c.set({
              ids: id,
              setTo: options.setTo,
            });
            _this.f.dispatchEvent(c);
          }
        });
        _this.f.on(_this.d.STAGE_UPDATE, load);
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_SHOW, function (item) {
          bounds = item.targetEntity;
          load();
        });
        _this.f.on(data.Events.TOGGLE_FRACTION_MODE, function () {
          var beat;
          var deviceOrientationEvent;
          var docLoadedEvent;
          if (c.display.visible) {
            beat = new doc.a.Event(data.Events.FRACTION_PICK_PALETTE_HIDE);
          } else {
            var htmlDocument;
            beat = new doc.a.Event(data.Events.FRACTION_PICK_PALETTE_SHOW);
            var a = require()((htmlDocument = root.getSelectedEntities())).call(htmlDocument, function (bounds) {
              return bounds instanceof selection;
            });
            if (a.length > 0) {
              beat.set({
                targetEntity: a[0],
              });
              (deviceOrientationEvent = new doc.a.Event(data.Events.TOGGLE_SELECTION_ELAPSED_TIME_MODE)).set({
                id: req.a.pluck(a, "id"),
                setTo: false,
              });
              (docLoadedEvent = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT)).set({
                ids: [a[0].id],
              });
            }
            _this.f.dispatchEvent(data.Events.EDIT_CLOCK_PALETTE_HIDE);
          }
          if (deviceOrientationEvent) {
            _this.f.dispatchEvent(deviceOrientationEvent);
          }
          if (docLoadedEvent) {
            _this.f.dispatchEvent(docLoadedEvent);
          }
          _this.f.dispatchEvent(beat);
        });
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT, function (s) {
          var c;
          var id;
          var value;
          var sel_text;
          var config;
          if (bounds) {
            var level;
            c = new doc.a.Event(data.Events.FRACTION_ENTITY_SET_FRAGMENT_COUNT);
            var tiles = require()((level = root.getSelectedEntities())).call(level, function (bounds) {
              return bounds instanceof selection;
            });
            value = req.a.pluck(tiles, "fractionControl");
            sel_text = req.a.pluck(value, "fraction");
            id = req.a.pluck(sel_text, "id");
            config = value[0]._tempFragments;
            c.set({
              ids: id,
              newFragments: config && s.value === config.length ? config : s.value,
            });
            _this.f.dispatchEvent(c);
          }
        });
      };
      /**
       * @param {string} layer
       * @return {undefined}
       */
      utils.addToLayer = function (layer) {
        p.addToParent(layer);
        /** @type {string} */
        p.bindingContainer = layer;
        e.addToParent(layer);
        /** @type {string} */
        e.bindingContainer = layer;
        item.addToParent(layer);
        /** @type {string} */
        item.bindingContainer = layer;
      };
      /**
       * @return {?}
       */
      utils.getTargetEntity = function () {
        return bounds;
      };
      /**
       * @return {?}
       */
      utils.anyOpen = function () {
        /** @type {boolean} */
        var visible = false;
        return (visible =
          (visible =
            (visible = (visible = (visible = visible || e.display.visible) || item.display.visible) || p.display.visible) || obj.display.visible) ||
          c.display.visible);
      };
      /**
       * @return {?}
       */
      utils.anyTextlikeOpen = function () {
        return e.display.visible || item.display.visible;
      };
      /**
       * @return {?}
       */
      utils.isEquationToolsVisible = function () {
        return e.display.visible;
      };
      /**
       * @return {?}
       */
      utils.isTextToolsVisible = function () {
        return item.display.visible;
      };
      /**
       * @return {?}
       */
      utils.isDrawToolsVisible = function () {
        return p.display.visible;
      };
      /**
       * @return {?}
       */
      utils.isFractionPickerVisible = function () {
        return c.display.visible;
      };
      /**
       * @return {?}
       */
      utils.isEditClockPaletteVisible = function () {
        return obj.display.visible;
      };
      /**
       * @param {!Function} selection
       * @return {?}
       */
      utils.isTargetEntity = function (selection) {
        return bounds instanceof selection;
      };
      var props = $("3127");
      var wrapper = $("zD+5");
      var srcNodeId = $("n8Jy");
      var node = $("GWf8");
      var researcher = $("quX5");
      var config = $("zNve");
      var themeSrc = $("oaRK");
      var linkCont = $("dmk2");
      var fakeSrc = $("iMrr");
      var self = {};
      var root = self;
      /** @type {!Array} */
      var topShowDialog = [
        {
          src: props,
        },
        {
          src: wrapper,
        },
        {
          src: srcNodeId,
        },
        {
          src: node,
        },
        {
          src: researcher,
        },
        {
          src: config,
        },
        {
          src: themeSrc,
        },
        {
          src: linkCont,
        },
        {
          src: fakeSrc,
        },
      ];
      _this.n.defineManifest("entities", topShowDialog, data.CACHEBUST_BASEPATH);
      var prevState;
      var marketID;
      /** @type {!Array} */
      var colorList = ["#ffffff", "#f0f0f0"];
      var me = {};
      /**
       * @return {undefined}
       */
      self.init = function () {
        var timeOverlaySize;
        me = new _this.p(
          _this.u,
          ((timeOverlaySize = {
            width: data.WORKSPACE_WIDTH,
            height: data.WORKSPACE_HEIGHT,
          }),
          {
            dimensions: {
              width: data.WORKSPACE_WIDTH,
              height: data.WORKSPACE_HEIGHT,
            },
            workspaceDimensions: timeOverlaySize,
            workspaceColor: colorList,
            drawOnTop: true,
            zoomLevels: [_this.p.ZoomModes.SHRINK],
            callbacks: {
              mouseCallbacks: {
                paletteDismiss: {
                  check: function () {
                    return ctx.anyOpen();
                  },
                  pressup: function (event) {
                    var value = me._findFirstObject(event.target);
                    if (value && value.js && (value = me._findFirstObject(value.js.topmostParent.t)) && value.js) {
                      value = value.js;
                    }
                    var def2 = ctx.getTargetEntity();
                    /** @type {boolean} */
                    var returningPromisesWorks = value === def2;
                    /** @type {boolean} */
                    var isType = value instanceof _this.p;
                    if (!(returningPromisesWorks || isType)) {
                      if (ctx.isTargetEntity(_this.h)) {
                        _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
                      } else {
                        if (ctx.isTargetEntity(_this.w)) {
                          _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
                        }
                      }
                      if (ctx.isTargetEntity(selection)) {
                        _this.f.dispatchEvent(data.Events.EDIT_CLOCK_PALETTE_HIDE);
                        _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
                      }
                    }
                  },
                },
                fillDismiss: {
                  check: function () {
                    return args.State.activeColor;
                  },
                  mousedown: function (event) {
                    var entry = _this.c.getFirstParentEntity(event.target);
                    if (entry instanceof _this.p) {
                      _this.f.dispatchEvent(data.Events.FRACTION_FILL_PALETTE_HIDE);
                    }
                  },
                },
              },
            },
          })
        );
        (function () {
          _this.f.on(_this.d.SPAWN_EQUATION_EVENT, tick, this);
          _this.f.on(_this.d.SPAWN_TEXT_EVENT, loop, this);
          _this.f.on(_this.d.SPAWN_SHADE_EVENT, callback, this);
          _this.f.on(_this.d.START_OVER_EVENT, function () {
            self.resetState(false);
          });
          _this.f.on(_this.d.START_OVER_SAVESTATE_EVENT, function () {
            self.resetState(true);
          });
        })();
        _this.f.on(data.Events.SPAWN_CLOCK_REQUEST, setColor);
        _this.f.on(data.Events.SPAWN_GEARED_CLOCK_REQUEST, onLoadGlyphSet);
        _this.f.on(data.Events.SPAWN_UNGEARED_CLOCK_REQUEST, userPointsUpdate);
        _this.f.on(data.Events.SPAWN_FRACTION_CLOCK_REQUEST, rubricAdvance);
        _this.f.on(data.Events.TOGGLE_DIGITAL_READOUT_MODE, flush);
        _this.f.on(data.Events.TOGGLE_RUN_JUMP_MODE, decode);
        _this.f.on(data.Events.TOGGLE_ELAPSED_TIME_MODE, _init);
        _this.f.on(data.Events.TOGGLE_TELL_TIME_MODE, tellTimeHandler);
        _this.f.on(_this.d.EQUATION_TOOLS_HIDE, onPause);
        _this.f.on(_this.d.EQUATION_TOOLS_SHOW, pause);
        _this.f.on(_this.d.TEXT_TOOLS_HIDE, onPause);
        _this.f.on(_this.d.TEXT_TOOLS_SHOW, pause);
        _this.f.on(data.Events.EDIT_CLOCK_PALETTE_HIDE, onPause);
        _this.f.on(data.Events.EDIT_CLOCK_PALETTE_SHOW, pause);
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_HIDE, onPause);
        _this.f.on(data.Events.FRACTION_PICK_PALETTE_SHOW, pause);
        _this.f.on(_this.d.SELECT_ENTITY_EVENT, onRefreshRateChanged);
        _this.f.on(_this.d.DESELECT_ENTITY_EVENT, onRefreshRateChanged);
        document.querySelector("#canvas").addEventListener("contextmenu", function (event) {
          event.preventDefault();
        });
      };
      /**
       * @param {boolean} table
       * @return {undefined}
       */
      self.resetState = function (table) {
        if (table && prevState) {
          self.loadState(prevState);
        }
      };
      /**
       * @param {string} state
       * @return {undefined}
       */
      self.loadState = function (state) {
        var stacked;
        if ((me.resetPage(), (prevState = state), state)) {
          cb()((stacked = state.workspaces)).call(stacked, self.loadStateWorkspace);
        }
      };
      /**
       * @param {!Object} data
       * @return {undefined}
       */
      self.loadStateWorkspace = function (data) {
        var placeMidpointLine;
        var ffmpegArguments;
        var imports;
        if (
          (me.updateWorkspaceDimensions(data.dimensions),
          (me.workspace.x = -data.visibleRect.x * me.getZoom()),
          (me.workspace.y = -data.visibleRect.y),
          me.drawing.loadDataUri(data.drawLayer),
          req.a.isArray(data.shades))
        ) {
          cb()((placeMidpointLine = data.shades)).call(placeMidpointLine, self.loadStateShade);
        }
        if (req.a.isArray(data.texts)) {
          cb()((ffmpegArguments = data.texts)).call(ffmpegArguments, self.loadStateText);
        }
        if (req.a.isArray(data.entities)) {
          cb()((imports = data.entities)).call(imports, self.loadStateClock);
        }
      };
      /**
       * @param {!Object} options
       * @return {undefined}
       */
      self.loadStateShade = function (options) {
        var url_params_def = {
          closeImage: _this.n.getResult("entities", researcher),
          revealImage: _this.n.getResult("entities", config),
          concealImage: _this.n.getResult("entities", themeSrc),
          cornerResizeImage: _this.n.getResult("entities", linkCont),
          fillImage: _this.n.getResult("entities", fakeSrc),
        };
        var init = new _this.t(null, req.a.defaults(options.data, url_params_def));
        self.addShade(init);
      };
      /**
       * @param {!Object} me
       * @return {undefined}
       */
      self.loadStateText = function (me) {
        var item;
        var option = {
          zoom: 1,
          selectedBackingColor: data.TEXT_SELECTED_BACKING_COLOR,
          incDefault: _this.n.getResult("entities", props),
          incActive: _this.n.getResult("entities", wrapper),
          decDefault: _this.n.getResult("entities", srcNodeId),
          decActive: _this.n.getResult("entities", node),
        };
        var range = _this.h.PRESET_FONT_SIZES;
        var i = _this.h.DEFAULT_FONT_SIZE_INDEX;
        cb()(range).call(range, function (elementSize, maxAtomIndex) {
          if (Math.abs(elementSize - me.data.size) < Math.abs(range[i] - me.data.size)) {
            i = maxAtomIndex;
          }
        });
        var obj = {
          position: {
            x: me.data.position.x,
            y: me.data.position.y,
          },
          fontSizeIndex: i,
          startingText: me.data.text,
          textColor: me.data.color,
        };
        if ("equation" === me.type) {
          item = new _this.h(null, req.a.defaults(obj, option));
        } else {
          if ("text" === me.type) {
            obj.dimensions = {
              width: me.data.lineWidth,
              height: me.data.height,
            };
            item = new _this.w(null, req.a.defaults(obj, option));
          }
        }
        self.addText(item);
      };
      /**
       * @param {!Object} feature
       * @return {undefined}
       */
      self.loadStateClock = function (feature) {
        var mbhour = {};
        if (feature.data.gearedMode) {
          /** @type {number} */
          mbhour.hour = ((feature.data.time.hourAngle * data.RADIANS_TO_DEGREES) / 720) * 24;
          /** @type {number} */
          mbhour.minute = (((feature.data.time.minuteAngle * data.RADIANS_TO_DEGREES) / 360) * 60) % 60;
          if (mbhour.minute < 0 && mbhour.hour >= 0) {
            mbhour.minute += 60;
          }
        } else {
          /** @type {number} */
          mbhour.hour = ((feature.data.time.hourAngle * data.RADIANS_TO_DEGREES) / 360) * 12;
          /** @type {number} */
          mbhour.minute = (((feature.data.time.minuteAngle * data.RADIANS_TO_DEGREES) / 360) * 60) % 60;
        }
        /** @type {number} */
        mbhour.second = feature.data.time.secondAngle * data.RADIANS_TO_DEGREES;
        /** @type {number} */
        var n = feature.data.elapsedTimeDisplay.startTime.minuteAngle * data.RADIANS_TO_DEGREES;
        /** @type {number} */
        var i = feature.data.elapsedTimeDisplay.endTime.minuteAngle * data.RADIANS_TO_DEGREES;
        /** @type {string} */
        var modifiers = selection.MajorControls.None;
        if (feature.data.elapsedTimeDisplay.shown) {
          /** @type {string} */
          modifiers = selection.MajorControls.ElapsedTime;
        } else {
          if (feature.data.fractionDisplay.shown) {
            /** @type {string} */
            modifiers = selection.MajorControls.FractionControl;
          }
        }
        var type = new selection(null, {
          position: {
            x: feature.data.center.x - feature.data.radius + selection.CONSTRAINT_PADDING,
            y: feature.data.center.y - feature.data.radius + selection.CONSTRAINT_PADDING,
          },
          radius: feature.data.radius - 2 * selection.CONSTRAINT_PADDING,
          activeMajorControl: modifiers,
          clockType: feature.data.clockFace,
          minuteHandOn: feature.data.showMinuteHand,
          hourHandOn: feature.data.showHourHand,
          handLabelsOn: feature.data.showHandLabels,
          gearedHands: feature.data.gearedMode,
          digitalReadoutMode: feature.data.showDigitalDisplay,
          runJumpMode: feature.data.runJumpDisplay.shown,
          runJumpActiveTab: feature.data.runJumpDisplay.activeTab,
          initialJumpStep: feature.data.runJumpDisplay.jumpStep,
          elapsedTimeMode: feature.data.elapsedTimeDisplay.shown,
          elapsedTimeActive: feature.data.elapsedTimeDisplay.active,
          elapsedTimeStart: n,
          elapsedTimeEnd: i,
          fractionMode: feature.data.fractionDisplay.shown,
          fractionInitialAngle: feature.data.fractionDisplay.angle * data.RADIANS_TO_DEGREES,
          initialFragments: feature.data.fractionDisplay.fragments,
          initialTime: mbhour,
          readoutDisplayMode: DirSearchPathEntry.ReadoutModes.hr12,
        });
        self.addEntity(type);
      };
      /**
       * @param {?} noteDatas
       * @return {undefined}
       */
      self.resizePage = function (noteDatas) {
        //console.log("resize page...");//NNO
        me.updateWorkspaceDimensions(noteDatas);
        var t = new doc.a.Event(_this.d.RESIZE_EVENT);
        t.set({
          x: 0,
          y: 0,
          width: _this.u.canvas.width,
          height: _this.u.canvas.height,
          workspaceDimensions: {
            height: data.WORKSPACE_HEIGHT,
            width: data.WORKSPACE_WIDTH,
          },
        });
        _this.f.dispatchEvent(t);
        _this.f.dispatchEvent(_this.d.STAGE_UPDATE);
      };
      /**
       * @param {!Object} obj
       * @return {undefined}
       */
      self.addShade = function (obj) {
        me.addToWorkspace(obj, _this.p.LayerNames.SHADE);
      };
      /**
       * @param {!Object} params
       * @return {undefined}
       */
      self.addText = function (params) {
        me.addToWorkspace(params, _this.p.LayerNames.TEXT);
      };
      /**
       * @param {!Object} data
       * @return {undefined}
       */
      self.addEntity = function (data) {
        me.addToWorkspace(data, _this.p.LayerNames.ENTITY);
      };
      /**
       * @param {!Object} item
       * @return {undefined}
       */
      self.addDefault = function (item) {
        if (item instanceof _this.t) {
          this.addShade(item);
        } else {
          if (item instanceof _this.h || item instanceof _this.w) {
            this.addText(item);
          } else {
            this.addEntity(item);
          }
        }
      };
      /**
       * @return {?}
       */
      self.getShades = function () {
        return me.shades;
      };
      /**
       * @return {?}
       */
      self.getTexts = function () {
        return me.texts;
      };
      /**
       * @return {?}
       */
      self.getEntities = function () {
        return me.entities;
      };
      /**
       * @return {?}
       */
      self.getSelectedEntities = function () {
        return require()(req.a).call(req.a, me.entities, function (cbCollection) {
          return cbCollection.selected;
        });
      };
      /**
       * @return {?}
       */
      self.getSelectedTexts = function () {
        return require()(req.a).call(req.a, me.texts, function (cbCollection) {
          return cbCollection.selected;
        });
      };
      /**
       * @return {?}
       */
      self.getAllEntities = function () {
        return req.a.union(this.getShades(), this.getTexts(), this.getEntities());
      };
      /**
       * @return {?}
       */
      self.isDrawingUsed = function () {
        return me.drawing.isDrawingUsed;
      };
      /**
       * @return {?}
       */
      self.getPageDataURL = function () {
        var e;
        var bounds = me._pageViewportDimensions();
        return (
          me.display.cache(bounds.x, bounds.y, bounds.width, bounds.height), (e = me.display.bitmapCache.getCacheDataURL()), me.display.uncache(), e
        );
      };
      /**
       * @param {number} dg
       * @return {?}
       */
      self.tooManyTexts = function (dg) {
        var g = me.texts.length;
        return dg && (g = g + dg), g > _this.d.TEXT_LIMIT;
      };
      /**
       * @param {number} n
       * @return {?}
       */
      self.tooManyShades = function (n) {
        var nCatCount = t()(req.a).call(
          req.a,
          me.shades,
          function (cind, entry) {
            /** @type {number} */
            var i = cind;
            return entry instanceof _this.t && (i = cind + 1), i;
          },
          0
        );
        return n && (nCatCount = nCatCount + n), nCatCount > _this.d.SHADE_LIMIT;
      };
      /**
       * @param {undefined} action
       * @return {?}
       */
      self.tooManyEntities = function (action) {
        return onChange(action);
      };
      /**
       * @param {!Array} id
       * @return {undefined}
       */
      self.setBackgroundColor = function (id) {
        if (id) {
          /** @type {!Array} */
          me.workspaceColor = id;
          me.draw();
        }
      };
      /**
       * @return {?}
       */
      self.getSelectionBounds = function () {
        return me._getSelectionBounds();
      };
      /**
       * @return {?}
       */
      self.isEdited = function () {
        return this.checkForBasicEdits() || this.checkForSpecificEdits();
      };
      /**
       * @return {?}
       */
      self.hasConfig = function () {
        return !req.a.isEqual(prevState, data.FALLBACK_CONFIG);
      };
      /**
       * @return {?}
       */
      self.getConfig = function () {
        return prevState;
      };
      /**
       * @return {?}
       */
      self.checkForBasicEdits = function () {
        var e = me.drawing.isDrawingUsed;
        /** @type {boolean} */
        var minus = me.shades.length > 0;
        /** @type {boolean} */
        var zero = me.texts.length > 0;
        return minus || zero || e;
      };
      /**
       * @return {?}
       */
      self.checkForSpecificEdits = function () {
        return me.entities.length > 0;
      };
      /**
       * @return {?}
       */
      self.getSaveData = function () {
        var config = me.getSaveData();
        return {
          dimensions: config.dimensions,
          drawLayer: config.drawing.dataUri,
          shades: config.shades,
          texts: config.texts,
          entities: config.entities,
          visibleRect: {
            x: -config.offset.x / me.workspace.scaleX,
            y: -config.offset.y / me.workspace.scaleY,
            width: (me.width - me.verticalScrollbar.width) / me.workspace.scaleX,
            height: (me.height - me.horizontalScrollbar.height) / me.workspace.scaleY,
          },
          zoomLevel: config.zoomLevel,
        };
      };
      /**
       * @return {?}
       */
      self.isFractionClockSelected = function () {
        var selected = me.getSelection(selection);
        return req.a.any(selected, function (canCreateDiscussions) {
          return (
            canCreateDiscussions.fractionControl.getFragmentCount() > 0 &&
            canCreateDiscussions.activeMajorControl === selection.MajorControls.FractionControl
          );
        });
      };
      var $scope = {};
      var ctrl = $scope;
      var info = {
        msgBox: "msgBox_scope",
        ACTIVITY_CODE: "activity_code_scope",
        DEFAULT: "default_scope",
        DISPLAY_CODE: "display_code_scope",
        INFO: "info_scope",
        IPAD_CHECK: "ipad_check_scope",
        SHARE_WORK: "share_work_scope",
        TEXT_EDIT: "text_edit_scope",
        ADD_CLOCK: "add_clock_scope",
        EDIT_FACE: "edit_face_scope",
        FRACTION_PICKER: "fraction_picker_scope",
        DIGITAL_READOUT: "digital_readout_input_scope",
        JUMP_CONTROL: "jump_control_input_scope",
      };
      $scope.Scopes = info;
      /**
       * @return {undefined}
       */
      $scope.init = function () {
        /**
         * @return {?}
         */
        global.a.filter = function () {
          return true;
        };
        document.addEventListener("keydown", function (event) {
          /** @type {boolean} */
          var k = 8 === event.keyCode;
          /** @type {boolean} */
          var d = "INPUT" !== event.target.nodeName && "TEXTAREA" !== event.target.nodeName;
          if (k && d) {
            event.preventDefault();
          }
        });
        add("esc", run(_this.d.START_OVER_PROMPT_EVENT));
        add("esc, enter", run(_this.d.EQUATION_TOOLS_HIDE), {
          scope: info.TEXT_EDIT,
          enableEvent: [_this.d.EQUATION_TOOLS_SHOW],
          disableEvent: [_this.d.EQUATION_TOOLS_HIDE],
        });
        add("esc", run(_this.d.TEXT_TOOLS_HIDE), {
          scope: info.TEXT_EDIT,
          enableEvent: [_this.d.TEXT_TOOLS_SHOW],
          disableEvent: [_this.d.TEXT_TOOLS_HIDE],
        });
        add("esc", run(_this.d.INFO_HIDE_EVENT), {
          scope: info.INFO,
        });
        add(
          "enter",
          function () {
            var s = root.getSelectedTexts();
            var list = require()(s).call(s, function (entry) {
              return entry instanceof _this.h || entry instanceof _this.w;
            });
            var entry = req.a.max(list, function (event) {
              return event.display.parent.getChildIndex(event.display);
            });
            /** @type {string} */
            var i = "";
            if (entry instanceof _this.h) {
              i = new doc.a.Event(_this.d.EQUATION_TOOLS_SHOW);
            }
            if (entry instanceof _this.w) {
              i = new doc.a.Event(_this.d.TEXT_TOOLS_SHOW);
            }
            if (i) {
              i.set({
                targetEntity: entry,
              });
              _this.f.dispatchEvent(i);
            }
          },
          {
            enableEvent: [_this.d.TEXT_TOOLS_HIDE],
            disableEvent: [_this.d.TEXT_TOOLS_SHOW],
          }
        );
        add("h", run(_this.d.SPAWN_SHADE_EVENT));
        add("e", run(_this.d.SPAWN_EQUATION_EVENT));
        add("t", run(_this.d.SPAWN_TEXT_EVENT));
        add("w", run(_this.d.DRAW_TOOLS_TOGGLE_EVENT));
        add("d", run(_this.d.DUPLICATE_SELECTION_EVENT), {
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (type) {
                return type.ids && type.ids.length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (type) {
                return type.ids && 0 === type.ids.length;
              },
            },
          ],
        });
        add("backspace, delete", run(_this.d.DELETE_SELECTION_REQUEST_EVENT), {
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (type) {
                return type.ids && type.ids.length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (type) {
                return type.ids && 0 === type.ids.length;
              },
            },
          ],
        });
        add("k", run(_this.d.ACTIVITY_CODE_OPEN_EVENT));
        add("enter", run(_this.d.LOAD_ACTIVITY_CODE_REQUEST_EVENT), {
          scope: info.ACTIVITY_CODE,
        });
        add("esc", run(_this.d.ACTIVITY_CODE_CLOSE_EVENT), {
          scope: info.ACTIVITY_CODE,
        });
        add("s", run(_this.d.SAVE_POPUP_SHOW_EVENT));
        add("esc", run(_this.d.SAVE_POPUP_HIDE_EVENT), {
          scope: info.SHARE_WORK,
        });
        add("d", run(_this.d.ACTIVITY_CODE_DISPLAY_OPEN_EVENT), {
          scope: info.SHARE_WORK,
        });
        add("esc", run(_this.d.ACTIVITY_CODE_DISPLAY_CLOSE_EVENT), {
          scope: info.DISPLAY_CODE,
        });
        add("i", run(_this.d.INFO_TOGGLE_EVENT));
        add("i", run(_this.d.INFO_TOGGLE_EVENT), {
          scope: info.INFO,
        });
        add("a", run(data.Events.NEW_CLOCK_base_OPEN));
        add("esc", run(data.Events.NEW_CLOCK_base_CLOSE), {
          scope: info.ADD_CLOCK,
        });
        add("c", run(data.Events.TOGGLE_EDIT_MODE), {
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (val) {
                return fn(val).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (val) {
                return fn(val).length <= 0;
              },
            },
          ],
        });
        add("c, esc, enter", run(data.Events.EDIT_CLOCK_PALETTE_HIDE), {
          scope: info.EDIT_FACE,
        });
        add("g", run(data.Events.TOGGLE_DIGITAL_READOUT_MODE));
        add("j", run(data.Events.TOGGLE_RUN_JUMP_MODE));
        add("l", run(data.Events.TOGGLE_ELAPSED_TIME_MODE));
        add("z", function () {
          var _Visitor;
          var t = require()((_Visitor = root.getSelectedEntities())).call(_Visitor, function (bounds) {
            return bounds instanceof selection;
          });
          if (t.length > 0) {
            var target = req.a.max(t, function (event) {
              return event.display.parent.getChildIndex(event.display);
            });
            var beat = new doc.a.Event(data.Events.FRACTION_PICK_PALETTE_TOGGLE);
            beat.set({
              targetEntity: target,
            });
            _this.f.dispatchEvent(beat);
          }
        });
        add("z, esc, enter", run(data.Events.FRACTION_PICK_PALETTE_HIDE), {
          scope: info.FRACTION_PICKER,
        });
        add("f", run(data.Events.FRACTION_FILL_PALETTE_TOGGLE), {
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (name) {
                return call(name);
              },
            },
            {
              event: data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
              condition: function (val) {
                return read(val);
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (name) {
                return !call(name);
              },
            },
            {
              event: data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
              condition: function (val) {
                return !read(val);
              },
            },
          ],
        });
        log(info.IPAD_CHECK, _this.k.OPEN_EVENT, _this.k.CLOSE_EVENT);
        log(info.TEXT_EDIT, [_this.d.EQUATION_TOOLS_SHOW, _this.d.TEXT_TOOLS_SHOW], [_this.d.EQUATION_TOOLS_HIDE, _this.d.TEXT_TOOLS_HIDE]);
        log(info.INFO, _this.d.INFO_SHOW_EVENT, _this.d.INFO_HIDE_EVENT);
        log(
          info.msgBox,
          [
            _this.d.DELETE_SELECTION_PROMPT_EVENT,
            _this.d.START_OVER_ALL_PROMPT_EVENT,
            _this.d.START_OVER_SAVESTATE_PROMPT_EVENT,
            _this.d.SPAWN_ITEM_FAILURE_PROMPT_EVENT,
            _this.d.DUPLICATE_ITEM_FAILURE_PROMPT_EVENT,
            _this.d.DRAW_TOOLS_CLEAR_DRAWING_PROMPT_EVENT,
          ],
          [
            _this.d.DELETE_SELECTION_PROMPT_CLOSE_EVENT,
            _this.d.START_OVER_ALL_PROMPT_CLOSE_EVENT,
            _this.d.START_OVER_SAVESTATE_PROMPT_CLOSE_EVENT,
            _this.d.SPAWN_ITEM_FAILURE_PROMPT_CLOSE_EVENT,
            _this.d.DUPLICATE_ITEM_FAILURE_PROMPT_CLOSE_EVENT,
            _this.d.DRAW_TOOLS_CLEAR_DRAWING_PROMPT_CLOSE_EVENT,
          ]
        );
        log(info.SHARE_WORK, _this.d.SAVE_POPUP_SHOW_EVENT, _this.d.SAVE_POPUP_HIDE_EVENT);
        log(info.ACTIVITY_CODE, _this.d.ACTIVITY_CODE_OPEN_EVENT, _this.d.ACTIVITY_CODE_CLOSE_EVENT);
        log(info.DISPLAY_CODE, _this.d.ACTIVITY_CODE_DISPLAY_OPEN_EVENT, info.SHARE_WORK, _this.d.ACTIVITY_CODE_DISPLAY_CLOSE_EVENT);
        log(info.ADD_CLOCK, data.Events.NEW_CLOCK_base_OPEN, data.Events.NEW_CLOCK_base_CLOSE);
        log(info.EDIT_FACE, data.Events.EDIT_CLOCK_PALETTE_SHOW, data.Events.EDIT_CLOCK_PALETTE_HIDE);
        log(info.FRACTION_PICKER, data.Events.FRACTION_PICK_PALETTE_SHOW, data.Events.FRACTION_PICK_PALETTE_HIDE);
        log(info.DIGITAL_READOUT, data.Events.DIGITAL_READOUT_INPUT_FOCUS, data.Events.DIGITAL_READOUT_INPUT_BLUR);
        log(info.JUMP_CONTROL, data.Events.JUMP_INPUT_FOCUS, data.Events.JUMP_INPUT_BLUR);
      };
      $scope.bind = $scope.on;
      /**
       * @return {?}
       */
      $scope.getScope = function () {
        return global.a.getScope();
      };
      /**
       * @param {?} scope
       * @return {undefined}
       */
      $scope.setScope = function (scope) {
        global.a.setScope(scope);
      };
      /**
       * @return {?}
       */
      window.isDigitalReadoutInputActive = function () {
        var placeMidpointLine;
        var path = require()((placeMidpointLine = root.getEntities())).call(placeMidpointLine, function (bounds) {
          return bounds instanceof selection;
        });
        return match()(path).call(path, function (canCreateDiscussions) {
          var t = canCreateDiscussions.digitalReadout.hoursInput.htmlElement.querySelector("input").matches(":focus");
          var types = canCreateDiscussions.digitalReadout.minutesInput.htmlElement.querySelector("input").matches(":focus");
          return t || types;
        });
      };
      /**
       * @return {?}
       */
      window.isJumpInputActive = function () {
        var placeMidpointLine;
        var path = require()((placeMidpointLine = root.getEntities())).call(placeMidpointLine, function (bounds) {
          return bounds instanceof selection;
        });
        return match()(path).call(path, function (canCreateDiscussions) {
          canCreateDiscussions.runJumpControl.jumpControl.input.htmlElement;
          return canCreateDiscussions.runJumpControl.jumpControl.input.htmlElement.querySelector("input").matches(":focus");
        });
      };
      var content_panes = $("RnbG");
      var params = {
        id: "loading-spinner",
        spinner: {},
        opts: {
          lines: 13,
          length: 20,
          width: 10,
          radius: 30,
          corners: 1,
          rotate: 0,
          direction: 1,
          color: "#000",
          speed: 1,
          trail: 60,
          shadow: false,
          hwaccel: false,
          className: "spinner",
          zIndex: 2e9,
          top: "auto",
          left: "auto",
        },
        start: function () {
          /** @type {(Element|null)} */
          var target = document.getElementById(this.id);
          this.spinner = new content_panes.a(this.opts).spin(target);
        },
        stop: function () {
          this.spinner.stop();
        },
      };
      var pi = new _this.o("#activity-display", {
        openEvent: _this.d.ACTIVITY_CODE_DISPLAY_OPEN_EVENT,
        closeEvent: _this.d.ACTIVITY_CODE_DISPLAY_CLOSE_EVENT,
        closeSelector: ".close-button",
        id: "activity-display-base",
        classes: "winBox gray-background",
        backgroundClose: true,
        appendTo: "body",
      });
      var exports = {};
      var _ = exports;
      exports.SAVE_KEY = _this.r.SAVE_KEY;
      /**
       * @return {undefined}
       */
      exports.init = function () {
        _this.r.init({
          appName: "clock",
          schemaVersion: 0,
          apiVersion: 1,
        });
      };
      /**
       * @param {?} name
       * @return {?}
       */
      exports.fetch = function (name) {
        return _this.r.fetchSaveData(name);
      };
      /**
       * @param {?} e
       * @return {?}
       */
      exports.send = function (e) {
        var t = _this.r.sendSaveData(e);
        return (
          t.then(
            function (canCreateDiscussions) {
              var beat = new doc.a.Event(_this.d.SAVE_STATE_RESPONSE);
              var n = (function (value) {
                /** @type {string} */
                var output = "";
                output = value.length >= 4 ? write()(value).call(value, 0, 4) + "-" + write()(value).call(value, 4, 8) : value;
                return (output = output.toUpperCase());
              })(canCreateDiscussions.save_state_id);
              /** @type {string} */
              var picKey = window.location.host + window.location.pathname;
              /** @type {string} */
              var a = window.location.protocol + "//" + picKey + "?" + canCreateDiscussions.save_state_id;
              if (Data.isCPA()) {
                /** @type {string} */
                a = "https://apps.mathlearningcenter.org/clock/?" + canCreateDiscussions.save_state_id;
              }
              beat.set({
                formattedSaveStateId: n,
                stateLink: a,
              });
              _this.f.dispatchEvent(beat);
            },
            function (range) {
              console.error("Error while sending save data.");
              cb()(range).call(range, function (err) {
                console.error("%s:\n(%s)", err.message, err.dataPath);
              });
            }
          ),
          t
        );
      };
      /**
       * @return {?}
       */
      exports.getSaveStateName = function () {
        var e;
        var t;
        /** @type {string} */
        var s = "";
        /** @type {string} */
        var fileExtension = window.location.hash;
        /** @type {string} */
        var ax = window.location.search;
        /** @type {string} */
        var extension = fileExtension || ax;
        return (
          extension && "/" === (s = extension.toLowerCase().substring(1))[s.length - 1] && (s = s.substring(0, s.length - 1)),
          (e = s),
          (s = write()((t = e.replace(/[^a-z0-9]/gi, ""))).call(t, 0, 8))
        );
      };
      var _i = new _this.o("#submit-activity-submit-box", {
        openEvent: _this.d.ACTIVITY_CODE_OPEN_EVENT,
        closeEvent: _this.d.ACTIVITY_CODE_CLOSE_EVENT,
        defaultButton: "#submit-activity-submit",
        closeSelector: ".close-button",
        id: "activity-submit-base",
        classes: "winBox gray-background",
        backgroundClose: true,
        appendTo: "body",
      });
      var Radiocheck = {};
      var rule = {};
      Radiocheck.codeOpen = new _this.e(data.ACTIVITY_CODE_OPEN_SELECTOR, {
        clickEvent: _this.d.LOAD_ACTIVITY_CODE_REQUEST_EVENT,
        disabled: true,
      });
      _this.f.on(_this.d.ACTIVITY_CODE_OPEN_EVENT, testAppearance);
      _this.f.on(_this.d.ACTIVITY_CODE_CLOSE_EVENT, clear);
      _this.f.on(_this.d.LOAD_ACTIVITY_CODE_REQUEST_EVENT, init);
      document.querySelector(data.ACTIVITY_CODE_TARGET_SELECTOR).addEventListener("input", refresh);
      var oMultiSelect = new _this.o("#copy-image-box", {
        openEvent: _this.d.COPY_IMAGE_OPEN_EVENT,
        closeEvent: _this.d.COPY_IMAGE_CLOSE_EVENT,
        closeSelector: ".close-button",
        id: "copy-image-base",
        classes: "winBox gray-background",
        backgroundClose: true,
        appendTo: "body",
      });
      var Ii = new _this.o("#new-clock-box", {
        openEvent: data.Events.NEW_CLOCK_base_OPEN,
        closeEvent: data.Events.NEW_CLOCK_base_CLOSE,
        id: "new-clock-base",
        classes: "popup",
        backgroundClose: true,
        appendTo: document.querySelector(data.ADD_CLOCK_SELECTOR).parentElement,
      });
      var bubbled_sets__3363;
      var wi = new _this.o("#save-popup-box", {
        openEvent: _this.d.SAVE_POPUP_SHOW_EVENT,
        closeEvent: _this.d.SAVE_POPUP_HIDE_EVENT,
        closeSelector: ".close-button",
        id: "save-popup",
        classes: "popup",
        backgroundClose: true,
      });
      var authReqCmd = {};
      authReqCmd.saveImageCopy = new _this.e(data.SAVE_IMAGE_COPY_SELECTOR, {
        clickEvent: _this.d.EXPORT_CANVAS_TO_IMAGE_EVENT,
      });
      authReqCmd.saveLinkCopy = new _this.e(data.SAVE_LINK_COPY_SELECTOR, {
        clickEvent: _this.d.COPY_SAVE_LINK_EVENT,
        disabled: true,
        disableEvent: _this.d.SAVE_STATE_EVENT,
      });
      authReqCmd.saveLinkDisplay = new _this.e(data.SAVE_LINK_DISPLAY_SELECTOR, {
        clickEvent: _this.d.DISPLAY_SAVE_LINK_EVENT,
        disabled: true,
        disableEvent: _this.d.SAVE_STATE_EVENT,
      });
      authReqCmd.saveImageDownload = new _this.e(data.SAVE_IMAGE_DOWNLOAD_SELECTOR, {
        clickEvent: _this.d.EXPORT_CANVAS_TO_DESKTOP_EVENT,
      });
      _this.f.on(_this.d.SAVE_STATE_RESPONSE, onSuccess);
      _this.f.on(_this.d.SAVE_POPUP_TOGGLE_EVENT, Menu);
      _this.f.on(_this.d.SAVE_POPUP_HIDE_EVENT, _getCroppedText);
      _this.f.on(_this.d.SAVE_POPUP_SHOW_EVENT, request);
      _this.f.on(_this.d.EXPORT_CANVAS_TO_DESKTOP_EVENT, download);
      _this.f.on(_this.d.EXPORT_CANVAS_TO_IMAGE_EVENT, done);
      _this.f.on(_this.d.COPY_SAVE_LINK_EVENT, notify);
      _this.f.on(_this.d.DISPLAY_SAVE_LINK_EVENT, function () {
        _this.f.dispatchEvent(_this.d.ACTIVITY_CODE_DISPLAY_OPEN_EVENT);
      });
      document
        .querySelector(data.SHARE_POPUP_URL_INPUT_SELECTOR + ", " + data.SHARE_POPUP_CODE_INPUT_SELECTOR)
        .addEventListener("focus", function (e) {
          e.target.select();
        });
      var popMsgbox = {};
      var Pianotiles = popMsgbox;
      /**
       * @return {undefined}
       */
      popMsgbox.init = function () {
        bubbled_sets__3363 = {
          activityCodeSubmitwinBox: _i,
          activityCodeDisplaywinBox: pi,
          copyImagewinBox: oMultiSelect,
          editClockwinBox: CC1P,
          fractionFillwinBox: koyomi,
          newClockwinBox: Ii,
          savePopup: wi,
        };
      };
      /**
       * @return {?}
       */
      popMsgbox.anyActive = function () {
        return match()(req.a).call(req.a, bubbled_sets__3363, function (FileModal) {
          return FileModal.isOpen;
        });
      };
      var Container = {};
      var targets = Container;
      Container.addClock = {
        selector: data.ADD_CLOCK_SELECTOR,
        options: {
          clickEvent: data.Events.NEW_CLOCK_base_OPEN,
        },
      };
      Container.addGearedClock = {
        selector: data.ADD_GEARED_CLOCK_SELECTOR,
        options: {
          clickEvent: data.Events.SPAWN_GEARED_CLOCK_REQUEST,
        },
      };
      Container.addUngearedClock = {
        selector: data.ADD_UNGEARED_CLOCK_SELECTOR,
        options: {
          clickEvent: data.Events.SPAWN_UNGEARED_CLOCK_REQUEST,
        },
      };
      Container.addFractionClock = {
        selector: data.ADD_FRACTION_CLOCK_SELECTOR,
        options: {
          clickEvent: data.Events.SPAWN_FRACTION_CLOCK_REQUEST,
        },
      };
      Container.editClock = {
        selector: data.EDIT_CLOCK_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_EDIT_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                //console.log("EDIT ON: ", value); //Vikas editclock
                return resolve(value).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                //console.log("EDIT OFFFF: ", Container); //Vikas editclock
                return resolve(value).length <= 0;
              },
            },
          ],
          addClassOn: [
            {
              eventID: data.Events.EDIT_CLOCK_PALETTE_SHOW,
              cssClass: "on",
            },
          ],
          removeClassOn: [
            {
              eventID: data.Events.EDIT_CLOCK_PALETTE_HIDE,
              cssClass: "on",
            },
          ],
        },
      };
      Container.fractionFill = {
        selector: data.FRACTION_FILL_SELECTOR,
        options: {
          clickEvent: data.Events.FRACTION_FILL_PALETTE_TOGGLE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                return getType(value);
              },
            },
            {
              event: data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
              condition: function (name) {
                return next(name);
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                return !getType(value);
              },
            },
            {
              event: data.Events.FRACTION_PICK_PALETTE_SET_FRAGMENT_COUNT,
              condition: function (name) {
                return !next(name);
              },
            },
          ],
          addClassOn: [
            {
              eventID: data.Events.FRACTION_FILL_PALETTE_SHOW,
              cssClass: "on",
            },
          ],
          removeClassOn: [
            {
              eventID: data.Events.FRACTION_FILL_PALETTE_HIDE,
              cssClass: "on",
            },
          ],
        },
      };
      Container.toggleDigitalReadoutOption = {
        selector: data.TOGGLE_DIGITAL_READOUT_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_DIGITAL_READOUT_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length > 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length <= 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return !(search(o).length > 0);
              },
            },
          ],
          addClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (value) {
                var results;
                var t = require()((results = resolve(value))).call(results, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.digitalReadoutMode;
                });
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (o) {
                var t = search(o);
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.digitalReadoutMode;
                });
              },
            },
            {
              eventID: data.Events.TOGGLE_DIGITAL_READOUT_MODE,
              cssClass: "on",
              condition: function () {
                var x;
                var path = require()((x = resolve())).call(x, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return match()(path).call(path, function (canCreateDiscussions) {
                  return !canCreateDiscussions.digitalReadoutMode;
                });
              },
            },
          ],
          removeClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (name) {
                var pkg;
                var url = require()((pkg = resolve(name))).call(pkg, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return (
                  match()(url).call(url, function (canCreateDiscussions) {
                    return !canCreateDiscussions.digitalReadoutMode;
                  }) || !(url.length > 0)
                );
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (type) {
                var selector = search(type);
                return (
                  match()(selector).call(selector, function (canCreateDiscussions) {
                    return !canCreateDiscussions.digitalReadoutMode;
                  }) || !(selector.length > 0)
                );
              },
            },
            {
              eventID: data.Events.TOGGLE_DIGITAL_READOUT_MODE,
              cssClass: "on",
              condition: function () {
                var expr;
                var value = require()((expr = resolve())).call(expr, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(value).call(value, function (canCreateDiscussions) {
                  return canCreateDiscussions.digitalReadoutMode;
                });
              },
            },
          ],
        },
      };
      Container.toggleRunJump = {
        selector: data.TOGGLE_RUN_JUMP_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_RUN_JUMP_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length > 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length <= 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length <= 0;
              },
            },
          ],
          addClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function () {
                var expr;
                var value = require()((expr = resolve())).call(expr, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(value).call(value, function (canCreateDiscussions) {
                  return canCreateDiscussions.runJumpMode;
                });
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (o) {
                var t = search(o);
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.runJumpMode;
                });
              },
            },
            {
              eventID: data.Events.TOGGLE_RUN_JUMP_MODE,
              cssClass: "on",
              condition: function () {
                var x;
                var path = require()((x = resolve())).call(x, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return match()(path).call(path, function (canCreateDiscussions) {
                  return !canCreateDiscussions.runJumpMode;
                });
              },
            },
          ],
          removeClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (name) {
                var pkg;
                var url = require()((pkg = resolve(name))).call(pkg, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return (
                  match()(url).call(url, function (canCreateDiscussions) {
                    return !canCreateDiscussions.runJumpMode;
                  }) || !(url.length > 0)
                );
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (type) {
                var selector = search(type);
                return (
                  match()(selector).call(selector, function (canCreateDiscussions) {
                    return !canCreateDiscussions.runJumpMode;
                  }) || !(selector.length > 0)
                );
              },
            },
            {
              eventID: data.Events.TOGGLE_RUN_JUMP_MODE,
              cssClass: "on",
              condition: function () {
                var expr;
                var value = require()((expr = resolve())).call(expr, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(value).call(value, function (canCreateDiscussions) {
                  return canCreateDiscussions.runJumpMode;
                });
              },
            },
          ],
        },
      };
      Container.toggleElapsedTimeMode = {
        selector: data.TOGGLE_ELAPSED_TIME_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_ELAPSED_TIME_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length > 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length <= 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length <= 0;
              },
            },
          ],
          addClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (value) {
                var results;
                var t = require()((results = resolve(value))).call(results, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime;
                });
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (o) {
                var t = search(o);
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime;
                });
              },
            },
            {
              eventID: data.Events.TOGGLE_ELAPSED_TIME_MODE,
              cssClass: "on",
              condition: function () {
                var x;
                var path = require()((x = resolve())).call(x, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return match()(path).call(path, function (canCreateDiscussions) {
                  return !canCreateDiscussions.elapsedTimeMode;
                });
              },
            },
          ],
          removeClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (name) {
                var pkg;
                var url = require()((pkg = resolve(name))).call(pkg, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return (
                  match()(url).call(url, function (canCreateDiscussions) {
                    return !(canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime);
                  }) || !(url.length > 0)
                );
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (type) {
                var selector = search(type);
                return (
                  match()(selector).call(selector, function (canCreateDiscussions) {
                    return !(canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime);
                  }) || !(selector.length > 0)
                );
              },
            },
            {
              eventID: data.Events.TOGGLE_ELAPSED_TIME_MODE,
              cssClass: "on",
              condition: function () {
                var expr;
                var value = require()((expr = resolve())).call(expr, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(value).call(value, function (canCreateDiscussions) {
                  return canCreateDiscussions.elapsedTimeMode;
                });
              },
            },
            {
              eventID: data.Events.FRACTION_PICK_PALETTE_SHOW,
              cssClass: "on",
            },
          ],
        },
      };

      Container.toggleTellTimeMode = {
        selector: data.TOGGLE_TELL_TIME_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_TELL_TIME_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length > 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length <= 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return !(search(o).length > 0);
              },
            },
          ],
          addClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (value) {
                var results;
                var t = require()((results = resolve(value))).call(results, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.tellTimeMode;
                });
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (o) {
                var t = search(o);
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.tellTimeMode;
                });
              },
            },
            {
              eventID: data.Events.TOGGLE_TELL_TIME_MODE,
              cssClass: "on",
              condition: function () {
                var x;
                var path = require()((x = resolve())).call(x, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return match()(path).call(path, function (canCreateDiscussions) {
                  return !canCreateDiscussions.tellTimeMode;
                });
              },
            },
          ],
          removeClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (name) {
                var pkg;
                var url = require()((pkg = resolve(name))).call(pkg, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return (
                  match()(url).call(url, function (canCreateDiscussions) {
                    return !canCreateDiscussions.tellTimeMode;
                  }) || !(url.length > 0)
                );
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (type) {
                var selector = search(type);
                return (
                  match()(selector).call(selector, function (canCreateDiscussions) {
                    return !canCreateDiscussions.tellTimeMode;
                  }) || !(selector.length > 0)
                );
              },
            },
            {
              eventID: data.Events.TOGGLE_TELL_TIME_MODE,
              cssClass: "on",
              condition: function () {
                var expr;
                var value = require()((expr = resolve())).call(expr, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(value).call(value, function (canCreateDiscussions) {
                  return canCreateDiscussions.tellTimeMode;
                });
              },
            },
          ],
        },
      };

      Container.toggleTellAngleMode = {
        selector: data.TOGGLE_TELL_ANGLE_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_TELL_ANGLE_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length > 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                var expr;
                return (
                  require()((expr = resolve(value))).call(expr, function (canCreateDiscussions) {
                    return canCreateDiscussions.isGeared();
                  }).length <= 0
                );
              },
            },
            {
              event: data.Events.SET_CLOCK_HAND_VISIBILITY,
              condition: function (o) {
                return search(o).length <= 0;
              },
            },
          ],
          addClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (value) {
                var results;
                var t = require()((results = resolve(value))).call(results, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime;
                });
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (o) {
                var t = search(o);
                return i()(t).call(t, function (canCreateDiscussions) {
                  return canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime;
                });
              },
            },
            {
              eventID: data.Events.TOGGLE_TELL_ANGLE_MODE,
              cssClass: "on",
              condition: function () {
                var x;
                var path = require()((x = resolve())).call(x, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return match()(path).call(path, function (canCreateDiscussions) {
                  return !canCreateDiscussions.elapsedTimeMode;
                });
              },
            },
          ],
          removeClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (name) {
                var pkg;
                var url = require()((pkg = resolve(name))).call(pkg, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return (
                  match()(url).call(url, function (canCreateDiscussions) {
                    return !(canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime);
                  }) || !(url.length > 0)
                );
              },
            },
            {
              eventID: data.Events.SET_CLOCK_HAND_VISIBILITY,
              cssClass: "on",
              condition: function (type) {
                var selector = search(type);
                return (
                  match()(selector).call(selector, function (canCreateDiscussions) {
                    return !(canCreateDiscussions.elapsedTimeMode && canCreateDiscussions.activeMajorControl === selection.MajorControls.ElapsedTime);
                  }) || !(selector.length > 0)
                );
              },
            },
            {
              eventID: data.Events.TOGGLE_TELL_ANGLE_MODE,
              cssClass: "on",
              condition: function () {
                var expr;
                var value = require()((expr = resolve())).call(expr, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return i()(value).call(value, function (canCreateDiscussions) {
                  return canCreateDiscussions.elapsedTimeMode;
                });
              },
            },
            {
              eventID: data.Events.FRACTION_PICK_PALETTE_SHOW,
              cssClass: "on",
            },
          ],
        },
      };

      Container.toggleFraction = {
        selector: data.TOGGLE_FRACTION_SELECTOR,
        options: {
          clickEvent: data.Events.TOGGLE_FRACTION_MODE,
          disabled: true,
          enableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                return resolve(value).length > 0;
              },
            },
          ],
          disableEvent: [
            {
              event: _this.d.SELECT_ENTITY_EVENT,
              condition: function (value) {
                return resolve(value).length <= 0;
              },
            },
          ],
          addClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (value) {
                return getType(value);
              },
            },
            {
              eventID: data.Events.FRACTION_PICK_PALETTE_SHOW,
              cssClass: "on",
            },
          ],
          removeClassOn: [
            {
              eventID: _this.d.SELECT_ENTITY_EVENT,
              cssClass: "on",
              condition: function (value) {
                return !getType(value);
              },
            },
            {
              eventID: data.Events.FRACTION_PICK_PALETTE_HIDE,
              cssClass: "on",
              condition: function () {
                return !getType();
              },
            },
            {
              eventID: data.Events.TOGGLE_ELAPSED_TIME_MODE,
              cssClass: "on",
              condition: function () {
                var x;
                var path = require()((x = resolve())).call(x, function (canCreateDiscussions) {
                  return canCreateDiscussions.isGeared();
                });
                return match()(path).call(path, function (canCreateDiscussions) {
                  return !canCreateDiscussions.elapsedTimeMode;
                });
              },
            },
          ],
        },
      };
      Container.fractionFillPalette = {
        selector: data.FRACTION_FILL_PALETTE_SELECTOR,
        options: {
          clickEvent: data.Events.SET_FRACTION_FILL_COLOR,
        },
      };
      var FloatingMenu;
      var currentRelations = {};
      var addedRelations = currentRelations;
      /**
       * @return {undefined}
       */
      currentRelations.init = function () {
        var result;
        var resetButton;
        var removeButton;
        var alignRightButton;
        var insertButtonFC;
        var alignLeftButton;
        var decPadding;
        var incPadding;
        var insertButton;
        var service;
        FloatingMenu = new _this.y({
          parent: {
            selector: data.TOOLBAR_SELECTOR,
            clickEvent: data.Events.TOOLBAR_CLICKED,
          },
        });
        resetButton = _this.y.defaultDuplicateOptions;
        removeButton = _this.y.defaultDeleteOptions;
        alignRightButton = _this.y.defaultEquationToolsOptions;
        insertButtonFC = _this.y.defaultTextToolsOptions;
        alignLeftButton = _this.y.defaultShadeOptions;
        decPadding = _this.y.defaultDrawToolsOptions;
        incPadding = _this.y.defaultStartOverOptions;
        insertButton = _this.y.defaultActivityCodeOptions;
        service = _this.y.defaultSavePopupOptions;
        /** @type {boolean} */
        resetButton.disabled = true;
        FloatingMenu.addButton(data.DUPLICATE_SELECTOR, resetButton);
        /** @type {boolean} */
        removeButton.disabled = true;
        FloatingMenu.addButton(data.DELETE_SELECTOR, removeButton);
        FloatingMenu.addButton(data.DRAW_TOOLS_SELECTOR, decPadding);
        /** @type {string} */
        alignRightButton.clickEvent = data.Events.SPAWN_EQUATION_REQUEST;
        FloatingMenu.addButton(data.EQUATION_TOOLS_SELECTOR, alignRightButton);
        /** @type {string} */
        insertButtonFC.clickEvent = data.Events.SPAWN_TEXT_REQUEST;
        FloatingMenu.addButton(data.TEXT_TOOLS_SELECTOR, insertButtonFC);
        FloatingMenu.addButton(data.SHADE_SELECTOR, alignLeftButton);
        FloatingMenu.addButton(data.START_OVER_SELECTOR, incPadding);
        FloatingMenu.addButton(data.INFO_SELECTOR, {
          clickEvent: _this.d.INFO_TOGGLE_EVENT,
        });
        FloatingMenu.addButton(data.ACTIVITY_CODE_SELECTOR, insertButton);
        service.enableEvent.push(data.Events.BEAD_MOVE);
        cb()((result = parseTemplate()(targets))).call(result, function (i) {
          FloatingMenu.addButton(targets[i].selector, targets[i].options);
        });
        _this.f.on(data.Events.TOOLBAR_CLICKED, function (name) {
          var deviceOrientationEvent;
          var docLoadedEvent;
          /** @type {!Array} */
          var level = [data.DRAW_TOOLS_SELECTOR];
          var targetPath = Data.inExclusionList(level, name);
          /** @type {!Array} */
          var animationMap = [data.EQUATION_TOOLS_SELECTOR, data.TEXT_TOOLS_SELECTOR, data.DELETE_SELECTOR];
          var inverseModels = Data.inExclusionList(animationMap, name);
          /** @type {!Array} */
          var owner = [
            data.ADD_CLOCK_SELECTOR,
            data.ADD_GEARED_CLOCK_SELECTOR,
            data.ADD_UNGEARED_CLOCK_SELECTOR,
            data.ADD_FRACTION_CLOCK_SELECTOR,
            data.EDIT_CLOCK_SELECTOR,
            data.DUPLICATE_SELECTOR,
            data.DELETE_SELECTOR,
            data.TOGGLE_DIGITAL_READOUT_SELECTOR,
            data.TOGGLE_RUN_JUMP_SELECTOR,
            data.TOGGLE_ELAPSED_TIME_SELECTOR,
            data.TOGGLE_TELL_TIME_SELECTOR,
            data.TOGGLE_TELL_ANGLE_SELECTOR,
            data.TOGGLE_FRACTION_SELECTOR,
            data.FRACTION_FILL_SELECTOR,
            data.FRACTION_FILL_PALETTE_SELECTOR,
            data.EQUATION_TOOLS_SELECTOR,
            data.TEXT_TOOLS_SELECTOR,
          ];
          var components = Data.inExclusionList(owner, name);
          /** @type {!Array} */
          var index = [data.ADD_FRACTION_CLOCK_SELECTOR, data.EDIT_CLOCK_SELECTOR, data.TOGGLE_FRACTION_SELECTOR];
          var property = Data.inExclusionList(index, name);
          /** @type {!Array} */
          var event = [data.EDIT_CLOCK_SELECTOR, data.TOGGLE_FRACTION_SELECTOR];
          var distance = Data.inExclusionList(event, name);
          if (!targetPath) {
            (deviceOrientationEvent = new doc.a.Event(_this.d.DRAW_TOOLS_MODE_CHANGE_EVENT)).set({
              newMode: _this.g.DrawMode.NONE,
            });
            _this.f.dispatchEvent(deviceOrientationEvent);
          }
          if (!inverseModels) {
            if (ctx.isEquationToolsVisible()) {
              _this.f.dispatchEvent(_this.d.EQUATION_TOOLS_HIDE);
            }
            if (ctx.isTextToolsVisible()) {
              _this.f.dispatchEvent(_this.d.TEXT_TOOLS_HIDE);
            }
          }
          if (!components) {
            (docLoadedEvent = new doc.a.Event(_this.d.SELECT_ENTITY_EVENT)).set({
              ids: [],
            });
            _this.f.dispatchEvent(docLoadedEvent);
          }
          if (!property) {
            if (ctx.isFractionPickerVisible()) {
              _this.f.dispatchEvent(data.Events.FRACTION_PICK_PALETTE_HIDE);
            }
          }
          if (!distance) {
            if (ctx.isEditClockPaletteVisible()) {
              _this.f.dispatchEvent(data.Events.EDIT_CLOCK_PALETTE_HIDE);
            }
          }
        });
      };
      var PWWWService;
      var view;
      var a = {};
      var args = a;
      a.State = {
        activeColor: "red",
      };
      /**
       * @return {undefined}
       */
      a.init = function () {
        if (Data.isChromeOS()) {
          document.querySelector("html").classList.add("chrome-os");
        }
        if (Data.isCPA() && !Data.isChromeOS()) {
          document.querySelector("html").classList.add("disable-copy-image");
        }
        _this.n.loadAll().then(function () {
          var e;
          e = req.a.debounce(function () {
            get();
            animate();
          }, 250);
          debug()(window).resize(e);
          doc.a.Ticker.on("tick", submitForm);
          /** @type {number} */
          doc.a.Ticker.framerate = 60;
          get();
          (view = new doc.a.Container()).setBounds(0, 0, _this.u.canvas.width, _this.u.canvas.height);
          new _this.l("#infopage");
          PWWWService = new _this.k({
            appName: data.APP_FULL_NAME,
            appURL: data.IOS_APP_URL,
            parent: "body",
          });
          ret.init();
          ctrl.init();
          Pianotiles.init();
          _.init();
          addedRelations.init();
          ctx.init(view);
          root.init();
          animate();
          _this.u.addChild(view);
          _this.f.on(_this.d.START_OVER_PROMPT_EVENT, replicantDeclared);
          _this.f.on(_this.d.START_OVER_EVENT, function () {
            update(false);
          });
          _this.f.on(_this.d.START_OVER_SAVESTATE_EVENT, function () {
            update(true);
          });
          _this.f.on(_this.d.DUPLICATE_SELECTION_EVENT, remove);
          _this.f.on(_this.d.DELETE_SELECTION_REQUEST_EVENT, Matrix2D);
          _this.f.on(_this.d.SAVE_STATE, onMasterMessage);
          _this.f.on(_this.d.LOAD_ACTIVITY_CODE_EVENT, render);
          document.querySelector("#canvas").addEventListener("contextmenu", function () {
            return false;
          });
          document.querySelector("#canvas").addEventListener("mousedown", function () {
            document.querySelector("#canvas").focus();
          });
          if (PWWWService.check()) {
            _this.f.dispatchEvent(_this.k.OPEN_EVENT);
          }
          (function () {
            var text;
            debug()("body").addClass("loading");
            params.start();
            var name = _.getSaveStateName();
            text = name
              ? _.fetch(name)
              : new __WEBPACK_IMPORTED_MODULE_20_date_fns_min___default.a(function (saveNotifs) {
                  saveNotifs(Object(schema.a)({}, _.SAVE_KEY, data.FALLBACK_CONFIG));
                });
            text
              .then(
                function (document) {
                  var state = document[_.SAVE_KEY];
                  if (state.appState.booleanFlags.drawToolsActive) {
                    var beat = new doc.a.Event(_this.d.DRAW_TOOLS_SHOW_EVENT);
                    beat.set({
                      newMode: _this.g.DrawMode.NONE,
                    });
                    _this.f.dispatchEvent(beat);
                  }
                  return root.loadState(state), document;
                },
                function (_errorThrown) {
                  return (
                    console.error("Something went wrong."), console.error(_errorThrown), root.loadState(data.FALLBACK_CONFIG), data.FALLBACK_CONFIG
                  );
                }
              )
              .then(function () {
                params.stop();
                debug()("body").removeClass("loading");
                get();
                animate();
              });
          })();
        });
      };
      document.addEventListener("DOMContentLoaded", args.init);
    },
    Myji: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    N69d: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-faceselect-arabic.13989310ba9a3d2046ee3b33f8c72c5c.png";
    },
    NVI9: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-icon-stop-on.0df59b8f5d983de4e039061e3b8d6af9.png";
    },
    O6Lu: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-faceselect-roman.9c690239be0735ea8b7b56b8e3ef33ce.png";
    },
    OX93: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen-green.c5e004eb01f73bf9abce1c317e3b3688.cur";
    },
    OnMd: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/erase-all-active.f5a426a5a81d31b49c1f7376a32f9765.png";
    },
    Q6Sk: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-faceselect-increment.05424bca4d372b1c3828aa0e2f067db6.png";
    },
    "RC+S": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    "Rah+": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-300italic.4df32891a5f2f98a363314f595482e08.woff";
    },
    Rh6l: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/widget-elapsed-confirm-icon.0821c52d11e926ef602f54ff6fd72954.png";
    },
    RjO5: function (module, id, require) {
      var content = require("FN4q");
      if ("string" == typeof content) {
        /** @type {!Array} */
        content = [[module.i, content, ""]];
      }
      var definition = {
        hmr: true,
        transform: void 0,
        insertInto: void 0,
      };
      require("aET+")(content, definition);
      if (content.locals) {
        module.exports = content.locals;
      }
    },
    SL7T: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAtCAYAAADcMyneAAAACXBIWXMAAAsSAAALEgHS3X78AAABzklEQVRYhe2ZwZGCMBSGf1OBJawnrpy4qh1sCbsVsB04dgAVuCXYgXj1xNXTWoIl7IT9wzIkRASE54zfDBdC5JuX5CU8Z+hAEKVvAFYAlgBCXi5yXkcA2fkUXxzPeLlLMIhSLRUDeLca27EHkJ5PcTaoIMU2jNoQaMFtG1GvYBClc4p9WY3DkFD02vRrjYKUO3jm11DoObpuknQKBlEaUm5uNT6GKyXzm4KM3M+IcgYtuahHUjnkxoxcleLddHALckE8es75COlQUg4xU8nB03lM1iYFVSO4mVzrn9KlEGT0hkrCQ7CiUxnBWJCcoXCaceP/sZplsFDChrbOSvHIJJWlmjjv3SJ8CkHRvAT78hLsi+KRWyr5UwgerdtyOCp+o0olUyxH7AUK7rWbWcWp1Tw9hVMhyPO/pKHOXN8kW+ux6ShdSkEaJwLkkmpRqb6TbCfOi3l9JJ+r9IG/oS4KOewwppyzwmVF0CCl/GZF0FCJ5CMXTuKTgy+CVcSWgOuILaI7RD8A7O7s9nk+xd/W3Rt0EqSkjuKuRTq6Uq7TgaSzINrVshtrz21pXMVt4Iv1Snf9g3TpK4e+ETQ4cqY3t40uqKGkWTh6zvXfiQD8AhsQqwvDnByJAAAAAElFTkSuQmCC";
    },
    V6Ve: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen-red.cur";
    },
    Va4Y: function (l, it, p) {
      l.exports = p.p;
    },
    VikQ: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-green.41a1d196ac6c3e14030e3a30361fc2b9.png";
    },
    WAVf: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-300.ef7c6637c68f269a882e73bcb57a7f6a.woff2";
    },
    X750: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-tab-jump-off.ce6a8a4c837ff0d20c6764b6ea0bde85.png";
    },
    XVer: function (blob, name, universe) {
      /** @type {string} */
      //images/close.3e8b95950617a2758cc85710aaf1d19d.png
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    Xp3h: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-700italic.81f57861ed4ac74741f5671e1dff2fd9.woff";
    },
    Y9ik: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/eraser-transparent.7aff2caa355213dd627839573ffe82e1.cur";
    },
    YLpD: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/fill-color-palette-bg.e41fea142bae704676d894984f168c49.png";
    },
    YiJN: function (l, it, p) {
      l.exports = p.p;
    },
    ZgxC: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-icon-play-on.5e9b488f0504bd6188b07b95ecb73017.png";
    },
    aJT6: function (l, it, p) {
      l.exports = p.p;
    },
    aLGr: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen-orange.77277ae6663d9772b915cb04e31068e0.cur";
    },
    cJUU: function (l, it, p) {
      l.exports = p.p;
    },
    d6Hy: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    dBWY: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    dCLE: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-red.55d4900bef2fa1a7b9ed3bc65bc799ef.png";
    },
    "dCq+": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen-yellow.7c462ec7d4bd923adc5921866b92dd9c.cur";
    },
    dXac: function (l, it, p) {
      l.exports = p.p;
    },
    dmk2: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAABj0lEQVRoge2YPW4CMRBGJ6k4wBYcIeWWSL5ASsqU3MTaW6TMESgpaVZKyTEofADKaMGIKOOf8aztnQg/CQl58DJPgtlvDY3Gk/MS0++GcWvfHoxWF/SBhXklfH1vX7tuGFeo+g8E7qwlSqQIgESJVAGQJsERAEkSFIETWrkhQiI6RuExSntUuHEGgK+lRixJAARLkAUgLnGxEmdUKUiSgESJZAEQJsESAEES0TE6NdoN4/vfdaPVPjBiV3bErlElM9Qwt/mVSkVJpNyJe4kSqVFCnAQnC82ReEOVmXDDHFfioxtG3+RiMSfMcSQmtjklcoS5k206Zc/E3mgVEiWRK8wtJpEzzC0ikTvMVZcoEeaqSpQKc1yJ6fDsG60GoJzMXYOc0ergqIUa4ko49/mg3Ac2zDDHvU849/koHeaKS9QIc0UlaoW5YhI1w1wRCYqA76zHeeFIQ9klKAKhuey8cKShrBJRAaPV0Z68+egZD/2cPc59pP+A0eoTAI6Bn5PzgJfQEIKzp9FoNBpPCgD8AChdIF7AVN8sAAAAAElFTkSuQmCC";
    },
    emzk: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-run.png";
    },
    fGIB: function (l, it, p) {
      l.exports = p.p;
    },
    gmkO: function (l, it, p) {
      l.exports = p.p;
    },
    iMqz: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-active.0250074ed1b4986fb1468516d26a7af6.png";
    },
    iMrr: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAAoElEQVRoge3WQQqEUBAD0djCeP+reBRvM4Kj4NZkN/BbqF3zyLroad3OU5K+x0/7cZ/6zJOWufQGL4dp3NHLYRp39HKYxh29HKZxRy+HadzRy2Ead3QqNNqp0GinQqOdClEhKmQwjTs6FaJCVMhgGlMhfqGnUyEqRIUMpnFHp0JUiAoZTGMqxC/0dCpEhaiQwTTu6FSIClEhg2lMhf7tki41SgRdE7y8WwAAAABJRU5ErkJggg==";
    },
    iY4r: function (l, it, p) {
      l.exports = p.p;
    },
    /* iapb: function (blob, name, universe) {
      
      blob.exports =
        // run jump base
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASYAAAC5CAYAAACFg5L4AAAFIUlEQVR4nO3csVJc5x3G4f93SNwiKkdje2ZDLiCLmYlMJUp3Vu4AX0FUJp0vQW2q0KYKLtPhisgzEpsLCKKQRkoFbp1wvhT2WojBipSxOG9mn6dizzksb/Wb3eVAq7e0ub29Po7vzYfWd6tq1nrNXrmgtd23fU7g/1zvh688bHVaVadjb4fD8O3i5NGjb97m6dqbXLS5vb1eFz/bqzbstVbzt/kBAL3Xovq4X2v/3n+TSL02TJvb2+vV3/uieu21Vrd+upnAKuq9zqvVfrVvv3hdoH40TLP5nc+GNuwLEvBT673Oxz7unS4efnnd+WvDtPnxJ39q1fbe6TJg5fXq+yeP//b51eNrVw+IEnBTWrX5xu0PZ2fPn77yyumVMG3O7/yuteH3NzsNWGWt2nzj/Q/Oz148e/jy2Pd+ufWbXw9tbTHNNGDVjf1i/uT4679XVQ3Lg0MND6abBKy6yw0aqqpmWzt33RgJTKq13dnWzt2q78M0tL436SCAetmioarKb+GABMsWtdn8zmdrw3Aw7RyA71yM471hGJq/fQNiDEObD63X7tRDAJZar92h15V/WwIwoV41G1prs6mHACy11mbDf78M4GYJExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiCNMQBxhAuIIExBHmIA4wgTEESYgjjABcYQJiDP0XoupRwAs9V6LoVU/n3oIwFKrfj701rxiAmL01hZDjePp1EMAfjCOp0Nv/XDqHQBLvfXDVlW1ubVz1lrdmnoQsNp6r/OT46ON724XaP1g4j0AP7RoqKoae9ufdAxAvWzRUFV1enz0VXWfNQET6v3w9Pjoq6pLd36PNd6fbhGw6i43aG35xfmLZ//ceP+D89bap9PMAlZVH8f7TxZff7l8vHb55NmLZw83bn84a9XmNz8NWEW9+v7J8cM/XD7WrrvwVx/v/KWq7t3IKmCVHfzj8dFvrx5cu+7Ks+dP/7xx+6NbreqTd78LWEW96sHJ46PPrzt3bZiqqs6eP/3r+i8+Ohyqz6q12bsaB6yY3g8vqu09OT76449dcu1buatmWzt311rdL2/vgP/dwUWvB8tbAl7njcK0tLm9vd4ufn6vD7Vbvc1bKx+SA9fqvRbV+qKNddjX/nVw8ujRN2/6vf8BS8bltRCBvCsAAAAASUVORK5CYII=";
    }, */
     iapb: function (blob, name, universe) {      
      blob.exports =
        // run jump base
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASYAAAC5CAYAAACFg5L4AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABDBJREFUeNrs3LFOW2cYx+H3/VxlTZhSlEQ6pRdQk0glTDB2S3oHzhWUsd1yCayd6rVTYezmTJRIAfcCCh5ApJPdNSrn69AQERJSUAq22ueZ4HDw8Ef66TtgkXFJCw8e3GzbG92SdTUimqzRvHVD5moA/y+1Dt76NGMUEaO25qCUV8O9Fy/+uMzL5UVjFMef9CJLLzO6fgrA5boVw6htPzp/9i8SqfzHINUbT6NGLzNumRf4yEBNIqMf+erphwJ1bpia7tKjkqUvSMBVBKqtbW803N68cJgW7j/8ISN75gOuNFBR+3s7vzw5e70jSsC0ZGR3bv5uMz462Dw3TAvdpW8yy7fmAq41TrfvTMYvD7ffeZT7bPHLL0p2hmYCpqGtx9393ee/RkSUk4slyrppgGk53aASEdEsLq94YyQw3We6XG0Wl1fehKlk7VkFmPqp6XWLSkSEv8IBM3Foet2ibLpLjzqlbJgEmAXHbfu4lJJdUwAz8zhXsluyxqopgJl5nKuxWmqc+bclAFNUI5qSmcIEzM6JKbMpZgBmjTABwgQgTIAwAQgTIEwAwgQIE4AwAQgTIEwAwgQIE4AwAcIEIEyAMAEIE4AwAcIEIEyAMAEIEyBMAMIEIEyAMAEIEyBMAMIECBOAMAHCBCBMAMIECBOAMAHCBCBMgDABCBOAMAHCBCBMgDABCBMgTADCBAgTgDABCBMgTADCBAgTgDABwgQgTADCBAgTgDABwgQgTIAwAQgTIEwAwgQgTIAwAQgTIEwAwgQIE4AwAQgTIEwAwgQIE4AwAcIEIEyAMAEIE4AwAcIEIEyAMAEIEyBMAMIEIEyAMAEIEyBMAMIECBOAMAHCBCBMAMIECBOAMAHCBCBMgDABCBOAMAHCBCBMgDABCBMgTADCBAgTgDABCBMgTADCBAgTgDABwgQgTADCBAgTgDABwgQgTIAwAQgTIEwAwgQgTIAwAQgTIEwAwgQIE4AwAcJkAkCYAIQJECYAYQKECUCYAGECECYAYQKECUCYAGECECbgvx6mWmNoBmBW1BrDklEnpgBmRUadlJrpxATMzokpc1iibUemAGZG245KzTqwBDA7J6Y6yIiIhcXlcWbcMgkw1SjVmOztbs39/XaBrBsmAabudYtKRERbs28RYNpOWlQiIka7W8+i+l0TMNXnuMFod+vZmzBFRLTRrlkGmNpp6VSDOicfTF4e/j53+84kM78yEXCth6W2XdsfPt98J0wREeOXh9tz83ebjOyaCriWKEXt7+1uf3f6Wr7vxs/vL/8UEY9NBlyxjd92tr4+e7HzvjvHRwc/zs3fu5URD+0GXM1JKdb3draevO9rnfO+aXx08PPNT+8NStQmMhszAv9OkergOLK3v7v1/Xm35EVep1lcXulkrHm8Az7mse24xvrJWwI+5C8AAAD//wMAbSLUtoDEFH0AAAAASUVORK5CYII=";
    }, 

    jbH8: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-tab-jump-on.02e36fd0cc1598a6c9004fb23da71e8d.png";
    },
    jhPy: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-orange.afbf4c8079ecbef902a8c0f451c9f94f.png";
    },
    lD3G: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-icon-play-off.f90315b242875f7670c937270d9f9dc5.png";
    },
    lILe: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-700italic.da0e717829e033a69dec97f1e155ae42.woff2";
    },
    m79l: function (eta, lmbda, n) {},
    mLyz: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-italic.fe65b8335ee19dd944289f9ed3178c78.woff";
    },
    mVJv: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen.0b17119d63b2cfbafc7dbf35237eb0ac.cur";
    },
    mpcN: function (l, it, p) {
      l.exports = p.p;
    },
    n8Jy: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAAoElEQVRoge3WQQqEUBAD0djCeP+reBRvM4Kj4NZkN/BbqF3zyLroad3OU5K+x0/7cZ/6zJOWufQGL4dp3NHLYRp39HKYxh29HKZxRy+HadzRy2Ead3QqNNqp0GinQqOdClEhKmQwjTs6FaJCVMhgGlMhfqGnUyEqRIUMpnFHp0JUiAoZTGMqxC/0dCpEhaiQwTTu6FSIClEhg2lMhf7tki41SgRdE7y8WwAAAABJRU5ErkJggg==";
    },
    o0vD: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/checkbox-on.0127fdd5bcfbb786d85993e6ae1aca91.png";
    },
    oaRK: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAB4UlEQVRoge2Yy1HDMBCGf6ggBxeQdABnHwIdJBVgd0Aq8KgC00FMBXYHJAedoQNcgA+UwChsZhw9LMnJABnvd4mtXXn3t1YPBwzDMAzDMBPm5pLSEyEfADwBUL9zzdwC2AF47Yp0Z3QeyUUEUOJbS9IulJj8EkLOEpAIOaPEV4YxjIaEfI3NYbSARMg7AG8AZoYxDpX8Y1ekH78mIBEyA1A6klcJVQD2dA3yWwLIBvpsuiKtDIuHaAGU/NYw/FBRItaSoJIrSYiNPFZElIBESFXrtWGIDO55CeuuSBuj1UGwAE/NV12R5kbrAImQSoBtJKLmRJAAGvp3xzKpAi76ZUMjVfb8WyqtRnvmp+OFKP97Vyn2uTVa7Ayt8ZUl+VrzV9c12Q5QH1fJzQdKLE5AIuSzZ53fa/el4eG26X37rCj2ICEjUBgtp+jD7Bopm81XIr7YwSX0bwkRIIyWU/RJ2BoebpttAsfE9gvoivSFziwullr7xuFns+l9+zQUe5DQEsotb+9IRkviAVoq15p/q29Q1Me2Dxz9g/aVq9/IgicxPdCVZEbHgyDI1+Wfx5xMp3WY6yVyvcfpI545EcNZHzSjNzIKuPAssT4aOgiOSh6T/6jX+Yu/VRiGYRiGYSYLgG8IlMaSlIbrfgAAAABJRU5ErkJggg==";
    },
    qBZb: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/widget-elapsed-cancel.2356ab67625eaff13469382c3a5e5c43.png";
    },
    "qN/d": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-icon-jump-forward.48cbdee8c76297a03b2689b58ae7be94.png";
    },
    qPnO: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "fonts/roboto-v19-latin-italic.51521a2a8da71e50d871ac6fd2187e87.woff2";
    },
    quX5: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAAoElEQVRoge3WQQqEUBAD0djCeP+reBRvM4Kj4NZkN/BbqF3zyLroad3OU5K+x0/7cZ/6zJOWufQGL4dp3NHLYRp39HKYxh29HKZxRy+HadzRy2Ead3QqNNqp0GinQqOdClEhKmQwjTs6FaJCVMhgGlMhfqGnUyEqRIUMpnFHp0JUiAoZTGMqxC/0dCpEhaiQwTTu6FSIClEhg2lMhf7tki41SgRdE7y8WwAAAABJRU5ErkJggg==";
    },
    sMyz: function (l, it, p) {
      l.exports = p.p;
    },
    "sb+R": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-activity-code.fdd47fce846d62c566f0224b0a799629.png";
    },
    ulOs: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/cursor-pen-black.e2a62b3eab508f7a335e32422f732bab.cur";
    },
    "v+RB": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAAoElEQVRoge3WQQqEUBAD0djCeP+reBRvM4Kj4NZkN/BbqF3zyLroad3OU5K+x0/7cZ/6zJOWufQGL4dp3NHLYRp39HKYxh29HKZxRy+HadzRy2Ead3QqNNqp0GinQqOdClEhKmQwjTs6FaJCVMhgGlMhfqGnUyEqRIUMpnFHp0JUiAoZTGMqxC/0dCpEhaiQwTTu6FSIClEhg2lMhf7tki41SgRdE7y8WwAAAABJRU5ErkJggg==";
    },
    vDVt: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-yellow.1b86c9080e3e7cd2b1a565b69d20170f.png";
    },
    wBlU: function (l, it, p) {
      l.exports = p.p;
    },
    wSdw: function (l, it, p) {
      l.exports = p.p;
    },
    xfvv: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-fill-purple.26c45ce39bdc49e1e0ebf5c4adc05daa.png";
    },
    xp4H: function (l, it, p) {
      l.exports = p.p;
    },
    "y45+": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-icon-jump-back.7054014e9b4d331815d5d5450a5e5640.png";
    },
    yqsS: function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/icon-trash.099e66becd1ec4ce16d512ae75a44f7d.png";
    },
    "z6m/": function (blob, name, universe) {
      /** @type {string} */
      blob.exports = universe.p + "images/runjump-tab-run-off.3dabb85cef632117519ffe90ec5df066.png";
    },
    "zD+5": function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAAoElEQVRoge3WQQqEUBAD0djCeP+reBRvM4Kj4NZkN/BbqF3zyLroad3OU5K+x0/7cZ/6zJOWufQGL4dp3NHLYRp39HKYxh29HKZxRy+HadzRy2Ead3QqNNqp0GinQqOdClEhKmQwjTs6FaJCVMhgGlMhfqGnUyEqRIUMpnFHp0JUiAoZTGMqxC/0dCpEhaiQwTTu6FSIClEhg2lMhf7tki41SgRdE7y8WwAAAABJRU5ErkJggg==";
    },
    zNve: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAB4UlEQVRoge2Yy1HDMBCGf6ggBxeQdABnHwIdJBVgd0Aq8KgC00FMBXYHJAedoQNcgA+UwChsZhw9LMnJABnvd4mtXXn3t1YPBwzDMAzDMBPm5pLSEyEfADwBUL9zzdwC2AF47Yp0Z3QeyUUEUOJbS9IulJj8EkLOEpAIOaPEV4YxjIaEfI3NYbSARMg7AG8AZoYxDpX8Y1ekH78mIBEyA1A6klcJVQD2dA3yWwLIBvpsuiKtDIuHaAGU/NYw/FBRItaSoJIrSYiNPFZElIBESFXrtWGIDO55CeuuSBuj1UGwAE/NV12R5kbrAImQSoBtJKLmRJAAGvp3xzKpAi76ZUMjVfb8WyqtRnvmp+OFKP97Vyn2uTVa7Ayt8ZUl+VrzV9c12Q5QH1fJzQdKLE5AIuSzZ53fa/el4eG26X37rCj2ICEjUBgtp+jD7Bopm81XIr7YwSX0bwkRIIyWU/RJ2BoebpttAsfE9gvoivSFziwullr7xuFns+l9+zQUe5DQEsotb+9IRkviAVoq15p/q29Q1Me2Dxz9g/aVq9/IgicxPdCVZEbHgyDI1+Wfx5xMp3WY6yVyvcfpI545EcNZHzSjNzIKuPAssT4aOgiOSh6T/6jX+Yu/VRiGYRiGYSYLgG8IlMaSlIbrfgAAAABJRU5ErkJggg==";
    },
    zyPW: function (blob, name, universe) {
      /** @type {string} */
      blob.exports =
        universe.p +
        "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsSAAALEgHS3X78AAAAoElEQVRoge3WQQqEUBAD0djCeP+reBRvM4Kj4NZkN/BbqF3zyLroad3OU5K+x0/7cZ/6zJOWufQGL4dp3NHLYRp39HKYxh29HKZxRy+HadzRy2Ead3QqNNqp0GinQqOdClEhKmQwjTs6FaJCVMhgGlMhfqGnUyEqRIUMpnFHp0JUiAoZTGMqxC/0dCpEhaiQwTTu6FSIClEhg2lMhf7tki41SgRdE7y8WwAAAABJRU5ErkJggg==";
    },
  },
  [["MuzD", 1, 2]],
]);
